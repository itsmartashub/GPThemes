// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"anGFI":[function(require,module,exports) {
var global = arguments[3];
var HMR_HOST = "localhost";
var HMR_PORT = 1234;
var HMR_SECURE = false;
var HMR_ENV_HASH = "ddf6e0724bd358bd";
var HMR_USE_SSE = false;
module.bundle.HMR_BUNDLE_ID = "59c9887d12730647";
"use strict";
/* global HMR_HOST, HMR_PORT, HMR_ENV_HASH, HMR_SECURE, HMR_USE_SSE, chrome, browser, __parcel__import__, __parcel__importScripts__, ServiceWorkerGlobalScope */ /*::
import type {
  HMRAsset,
  HMRMessage,
} from '@parcel/reporter-dev-server/src/HMRServer.js';
interface ParcelRequire {
  (string): mixed;
  cache: {|[string]: ParcelModule|};
  hotData: {|[string]: mixed|};
  Module: any;
  parent: ?ParcelRequire;
  isParcelRequire: true;
  modules: {|[string]: [Function, {|[string]: string|}]|};
  HMR_BUNDLE_ID: string;
  root: ParcelRequire;
}
interface ParcelModule {
  hot: {|
    data: mixed,
    accept(cb: (Function) => void): void,
    dispose(cb: (mixed) => void): void,
    // accept(deps: Array<string> | string, cb: (Function) => void): void,
    // decline(): void,
    _acceptCallbacks: Array<(Function) => void>,
    _disposeCallbacks: Array<(mixed) => void>,
  |};
}
interface ExtensionContext {
  runtime: {|
    reload(): void,
    getURL(url: string): string;
    getManifest(): {manifest_version: number, ...};
  |};
}
declare var module: {bundle: ParcelRequire, ...};
declare var HMR_HOST: string;
declare var HMR_PORT: string;
declare var HMR_ENV_HASH: string;
declare var HMR_SECURE: boolean;
declare var HMR_USE_SSE: boolean;
declare var chrome: ExtensionContext;
declare var browser: ExtensionContext;
declare var __parcel__import__: (string) => Promise<void>;
declare var __parcel__importScripts__: (string) => Promise<void>;
declare var globalThis: typeof self;
declare var ServiceWorkerGlobalScope: Object;
*/ var OVERLAY_ID = "__parcel__error__overlay__";
var OldModule = module.bundle.Module;
function Module(moduleName) {
    OldModule.call(this, moduleName);
    this.hot = {
        data: module.bundle.hotData[moduleName],
        _acceptCallbacks: [],
        _disposeCallbacks: [],
        accept: function(fn) {
            this._acceptCallbacks.push(fn || function() {});
        },
        dispose: function(fn) {
            this._disposeCallbacks.push(fn);
        }
    };
    module.bundle.hotData[moduleName] = undefined;
}
module.bundle.Module = Module;
module.bundle.hotData = {};
var checkedAssets /*: {|[string]: boolean|} */ , assetsToDispose /*: Array<[ParcelRequire, string]> */ , assetsToAccept /*: Array<[ParcelRequire, string]> */ ;
function getHostname() {
    return HMR_HOST || (location.protocol.indexOf("http") === 0 ? location.hostname : "localhost");
}
function getPort() {
    return HMR_PORT || location.port;
}
// eslint-disable-next-line no-redeclare
var parent = module.bundle.parent;
if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== "undefined") {
    var hostname = getHostname();
    var port = getPort();
    var protocol = HMR_SECURE || location.protocol == "https:" && ![
        "localhost",
        "127.0.0.1",
        "0.0.0.0"
    ].includes(hostname) ? "wss" : "ws";
    var ws;
    if (HMR_USE_SSE) ws = new EventSource("/__parcel_hmr");
    else try {
        ws = new WebSocket(protocol + "://" + hostname + (port ? ":" + port : "") + "/");
    } catch (err) {
        if (err.message) console.error(err.message);
        ws = {};
    }
    // Web extension context
    var extCtx = typeof browser === "undefined" ? typeof chrome === "undefined" ? null : chrome : browser;
    // Safari doesn't support sourceURL in error stacks.
    // eval may also be disabled via CSP, so do a quick check.
    var supportsSourceURL = false;
    try {
        (0, eval)('throw new Error("test"); //# sourceURL=test.js');
    } catch (err) {
        supportsSourceURL = err.stack.includes("test.js");
    }
    // $FlowFixMe
    ws.onmessage = async function(event /*: {data: string, ...} */ ) {
        checkedAssets = {} /*: {|[string]: boolean|} */ ;
        assetsToAccept = [];
        assetsToDispose = [];
        var data /*: HMRMessage */  = JSON.parse(event.data);
        if (data.type === "update") {
            // Remove error overlay if there is one
            if (typeof document !== "undefined") removeErrorOverlay();
            let assets = data.assets.filter((asset)=>asset.envHash === HMR_ENV_HASH);
            // Handle HMR Update
            let handled = assets.every((asset)=>{
                return asset.type === "css" || asset.type === "js" && hmrAcceptCheck(module.bundle.root, asset.id, asset.depsByBundle);
            });
            if (handled) {
                console.clear();
                // Dispatch custom event so other runtimes (e.g React Refresh) are aware.
                if (typeof window !== "undefined" && typeof CustomEvent !== "undefined") window.dispatchEvent(new CustomEvent("parcelhmraccept"));
                await hmrApplyUpdates(assets);
                // Dispose all old assets.
                let processedAssets = {} /*: {|[string]: boolean|} */ ;
                for(let i = 0; i < assetsToDispose.length; i++){
                    let id = assetsToDispose[i][1];
                    if (!processedAssets[id]) {
                        hmrDispose(assetsToDispose[i][0], id);
                        processedAssets[id] = true;
                    }
                }
                // Run accept callbacks. This will also re-execute other disposed assets in topological order.
                processedAssets = {};
                for(let i = 0; i < assetsToAccept.length; i++){
                    let id = assetsToAccept[i][1];
                    if (!processedAssets[id]) {
                        hmrAccept(assetsToAccept[i][0], id);
                        processedAssets[id] = true;
                    }
                }
            } else fullReload();
        }
        if (data.type === "error") {
            // Log parcel errors to console
            for (let ansiDiagnostic of data.diagnostics.ansi){
                let stack = ansiDiagnostic.codeframe ? ansiDiagnostic.codeframe : ansiDiagnostic.stack;
                console.error("\uD83D\uDEA8 [parcel]: " + ansiDiagnostic.message + "\n" + stack + "\n\n" + ansiDiagnostic.hints.join("\n"));
            }
            if (typeof document !== "undefined") {
                // Render the fancy html overlay
                removeErrorOverlay();
                var overlay = createErrorOverlay(data.diagnostics.html);
                // $FlowFixMe
                document.body.appendChild(overlay);
            }
        }
    };
    if (ws instanceof WebSocket) {
        ws.onerror = function(e) {
            if (e.message) console.error(e.message);
        };
        ws.onclose = function() {
            console.warn("[parcel] \uD83D\uDEA8 Connection to the HMR server was lost");
        };
    }
}
function removeErrorOverlay() {
    var overlay = document.getElementById(OVERLAY_ID);
    if (overlay) {
        overlay.remove();
        console.log("[parcel] \u2728 Error resolved");
    }
}
function createErrorOverlay(diagnostics) {
    var overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    let errorHTML = '<div style="background: black; opacity: 0.85; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; font-family: Menlo, Consolas, monospace; z-index: 9999;">';
    for (let diagnostic of diagnostics){
        let stack = diagnostic.frames.length ? diagnostic.frames.reduce((p, frame)=>{
            return `${p}
<a href="/__parcel_launch_editor?file=${encodeURIComponent(frame.location)}" style="text-decoration: underline; color: #888" onclick="fetch(this.href); return false">${frame.location}</a>
${frame.code}`;
        }, "") : diagnostic.stack;
        errorHTML += `
      <div>
        <div style="font-size: 18px; font-weight: bold; margin-top: 20px;">
          \u{1F6A8} ${diagnostic.message}
        </div>
        <pre>${stack}</pre>
        <div>
          ${diagnostic.hints.map((hint)=>"<div>\uD83D\uDCA1 " + hint + "</div>").join("")}
        </div>
        ${diagnostic.documentation ? `<div>\u{1F4DD} <a style="color: violet" href="${diagnostic.documentation}" target="_blank">Learn more</a></div>` : ""}
      </div>
    `;
    }
    errorHTML += "</div>";
    overlay.innerHTML = errorHTML;
    return overlay;
}
function fullReload() {
    if ("reload" in location) location.reload();
    else if (extCtx && extCtx.runtime && extCtx.runtime.reload) extCtx.runtime.reload();
}
function getParents(bundle, id) /*: Array<[ParcelRequire, string]> */ {
    var modules = bundle.modules;
    if (!modules) return [];
    var parents = [];
    var k, d, dep;
    for(k in modules)for(d in modules[k][1]){
        dep = modules[k][1][d];
        if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) parents.push([
            bundle,
            k
        ]);
    }
    if (bundle.parent) parents = parents.concat(getParents(bundle.parent, id));
    return parents;
}
function updateLink(link) {
    var href = link.getAttribute("href");
    if (!href) return;
    var newLink = link.cloneNode();
    newLink.onload = function() {
        if (link.parentNode !== null) // $FlowFixMe
        link.parentNode.removeChild(link);
    };
    newLink.setAttribute("href", // $FlowFixMe
    href.split("?")[0] + "?" + Date.now());
    // $FlowFixMe
    link.parentNode.insertBefore(newLink, link.nextSibling);
}
var cssTimeout = null;
function reloadCSS() {
    if (cssTimeout) return;
    cssTimeout = setTimeout(function() {
        var links = document.querySelectorAll('link[rel="stylesheet"]');
        for(var i = 0; i < links.length; i++){
            // $FlowFixMe[incompatible-type]
            var href /*: string */  = links[i].getAttribute("href");
            var hostname = getHostname();
            var servedFromHMRServer = hostname === "localhost" ? new RegExp("^(https?:\\/\\/(0.0.0.0|127.0.0.1)|localhost):" + getPort()).test(href) : href.indexOf(hostname + ":" + getPort());
            var absolute = /^https?:\/\//i.test(href) && href.indexOf(location.origin) !== 0 && !servedFromHMRServer;
            if (!absolute) updateLink(links[i]);
        }
        cssTimeout = null;
    }, 50);
}
function hmrDownload(asset) {
    if (asset.type === "js") {
        if (typeof document !== "undefined") {
            let script = document.createElement("script");
            script.src = asset.url + "?t=" + Date.now();
            if (asset.outputFormat === "esmodule") script.type = "module";
            return new Promise((resolve, reject)=>{
                var _document$head;
                script.onload = ()=>resolve(script);
                script.onerror = reject;
                (_document$head = document.head) === null || _document$head === void 0 || _document$head.appendChild(script);
            });
        } else if (typeof importScripts === "function") {
            // Worker scripts
            if (asset.outputFormat === "esmodule") return import(asset.url + "?t=" + Date.now());
            else return new Promise((resolve, reject)=>{
                try {
                    importScripts(asset.url + "?t=" + Date.now());
                    resolve();
                } catch (err) {
                    reject(err);
                }
            });
        }
    }
}
async function hmrApplyUpdates(assets) {
    global.parcelHotUpdate = Object.create(null);
    let scriptsToRemove;
    try {
        // If sourceURL comments aren't supported in eval, we need to load
        // the update from the dev server over HTTP so that stack traces
        // are correct in errors/logs. This is much slower than eval, so
        // we only do it if needed (currently just Safari).
        // https://bugs.webkit.org/show_bug.cgi?id=137297
        // This path is also taken if a CSP disallows eval.
        if (!supportsSourceURL) {
            let promises = assets.map((asset)=>{
                var _hmrDownload;
                return (_hmrDownload = hmrDownload(asset)) === null || _hmrDownload === void 0 ? void 0 : _hmrDownload.catch((err)=>{
                    // Web extension fix
                    if (extCtx && extCtx.runtime && extCtx.runtime.getManifest().manifest_version == 3 && typeof ServiceWorkerGlobalScope != "undefined" && global instanceof ServiceWorkerGlobalScope) {
                        extCtx.runtime.reload();
                        return;
                    }
                    throw err;
                });
            });
            scriptsToRemove = await Promise.all(promises);
        }
        assets.forEach(function(asset) {
            hmrApply(module.bundle.root, asset);
        });
    } finally{
        delete global.parcelHotUpdate;
        if (scriptsToRemove) scriptsToRemove.forEach((script)=>{
            if (script) {
                var _document$head2;
                (_document$head2 = document.head) === null || _document$head2 === void 0 || _document$head2.removeChild(script);
            }
        });
    }
}
function hmrApply(bundle /*: ParcelRequire */ , asset /*:  HMRAsset */ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (asset.type === "css") reloadCSS();
    else if (asset.type === "js") {
        let deps = asset.depsByBundle[bundle.HMR_BUNDLE_ID];
        if (deps) {
            if (modules[asset.id]) {
                // Remove dependencies that are removed and will become orphaned.
                // This is necessary so that if the asset is added back again, the cache is gone, and we prevent a full page reload.
                let oldDeps = modules[asset.id][1];
                for(let dep in oldDeps)if (!deps[dep] || deps[dep] !== oldDeps[dep]) {
                    let id = oldDeps[dep];
                    let parents = getParents(module.bundle.root, id);
                    if (parents.length === 1) hmrDelete(module.bundle.root, id);
                }
            }
            if (supportsSourceURL) // Global eval. We would use `new Function` here but browser
            // support for source maps is better with eval.
            (0, eval)(asset.output);
            // $FlowFixMe
            let fn = global.parcelHotUpdate[asset.id];
            modules[asset.id] = [
                fn,
                deps
            ];
        } else if (bundle.parent) hmrApply(bundle.parent, asset);
    }
}
function hmrDelete(bundle, id) {
    let modules = bundle.modules;
    if (!modules) return;
    if (modules[id]) {
        // Collect dependencies that will become orphaned when this module is deleted.
        let deps = modules[id][1];
        let orphans = [];
        for(let dep in deps){
            let parents = getParents(module.bundle.root, deps[dep]);
            if (parents.length === 1) orphans.push(deps[dep]);
        }
        // Delete the module. This must be done before deleting dependencies in case of circular dependencies.
        delete modules[id];
        delete bundle.cache[id];
        // Now delete the orphans.
        orphans.forEach((id)=>{
            hmrDelete(module.bundle.root, id);
        });
    } else if (bundle.parent) hmrDelete(bundle.parent, id);
}
function hmrAcceptCheck(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    if (hmrAcceptCheckOne(bundle, id, depsByBundle)) return true;
    // Traverse parents breadth first. All possible ancestries must accept the HMR update, or we'll reload.
    let parents = getParents(module.bundle.root, id);
    let accepted = false;
    while(parents.length > 0){
        let v = parents.shift();
        let a = hmrAcceptCheckOne(v[0], v[1], null);
        if (a) // If this parent accepts, stop traversing upward, but still consider siblings.
        accepted = true;
        else {
            // Otherwise, queue the parents in the next level upward.
            let p = getParents(module.bundle.root, v[1]);
            if (p.length === 0) {
                // If there are no parents, then we've reached an entry without accepting. Reload.
                accepted = false;
                break;
            }
            parents.push(...p);
        }
    }
    return accepted;
}
function hmrAcceptCheckOne(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (depsByBundle && !depsByBundle[bundle.HMR_BUNDLE_ID]) {
        // If we reached the root bundle without finding where the asset should go,
        // there's nothing to do. Mark as "accepted" so we don't reload the page.
        if (!bundle.parent) return true;
        return hmrAcceptCheck(bundle.parent, id, depsByBundle);
    }
    if (checkedAssets[id]) return true;
    checkedAssets[id] = true;
    var cached = bundle.cache[id];
    assetsToDispose.push([
        bundle,
        id
    ]);
    if (!cached || cached.hot && cached.hot._acceptCallbacks.length) {
        assetsToAccept.push([
            bundle,
            id
        ]);
        return true;
    }
}
function hmrDispose(bundle /*: ParcelRequire */ , id /*: string */ ) {
    var cached = bundle.cache[id];
    bundle.hotData[id] = {};
    if (cached && cached.hot) cached.hot.data = bundle.hotData[id];
    if (cached && cached.hot && cached.hot._disposeCallbacks.length) cached.hot._disposeCallbacks.forEach(function(cb) {
        cb(bundle.hotData[id]);
    });
    delete bundle.cache[id];
}
function hmrAccept(bundle /*: ParcelRequire */ , id /*: string */ ) {
    // Execute the module.
    bundle(id);
    // Run the accept callbacks in the new version of the module.
    var cached = bundle.cache[id];
    if (cached && cached.hot && cached.hot._acceptCallbacks.length) cached.hot._acceptCallbacks.forEach(function(cb) {
        var assetsToAlsoAccept = cb(function() {
            return getParents(module.bundle.root, id);
        });
        if (assetsToAlsoAccept && assetsToAccept.length) {
            assetsToAlsoAccept.forEach(function(a) {
                hmrDispose(a[0], a[1]);
            });
            // $FlowFixMe[method-unbinding]
            assetsToAccept.push.apply(assetsToAccept, assetsToAlsoAccept);
        }
    });
}

},{}],"3q87D":[function(require,module,exports) {
var _floatingBtn = require("./app/floatingBtn");
// import './app/customFonts'
var _mainFonts = require("./app/mainFonts");

},{"./app/floatingBtn":"dYzZC","./app/mainFonts":"gynjN"}],"dYzZC":[function(require,module,exports) {
// Use a cross-browser storage API:
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _webextensionPolyfill = require("webextension-polyfill");
var _webextensionPolyfillDefault = parcelHelpers.interopDefault(_webextensionPolyfill);
var _iconsJs = require("./components/icons.js");
var _hexToHSL = require("../utils/hexToHSL");
// import { fontHtmlCode, addFontsEventHandlers } from './customFonts'
var _mainFonts = require("./mainFonts");
// console.log(fontHtmlCode)
// let isOptionsShown = false
// Global Variables
let isOptionsShown = false;
let $htmlTag;
let $floatingBtn;
let $floatingOptions;
let $floatingBtnsContainer;
let $settings // @ Accent Theme
;
let $resetAllBtn;
// let isSettingsOpen = false
let styleElement = null // Declare the styleElement variable
;
let defaultColorLight = "#6b4dfe";
let defaultColorDark = "#ca93fb";
// let isDisabledResetAll = true
const renderColorsTab = `
	<section>
		<div class="colorpicker-container">
			<div class="colorpicker">
				<input type="color" id="accentLight" value="#6b4dfe" />
				<label for="accentLight">Accent <span>Light</span></label>
			</div>
			<div class="colorpicker">
				<input type="color" id="accentDark" value="#ca93fb" />
				<label for="accentDark">Accent <span>Dark</span></label>
			</div>
		</div>
		<footer class="grid mt-10">
			<button id="resetAllSettings" class="btn block relative btn-primary text-center" as="button">Reset Accents</button>
		</footer>
	</section>
`;
// Initialization
init();
function tabsSwitching() {
    const tabs = document.querySelectorAll(".gpth-settings .tab-button");
    const panes = document.querySelectorAll(".gpth-settings .tab-pane");
    tabs.forEach((tab, index)=>{
        tab.addEventListener("click", ()=>{
            document.querySelector(".tab-button.active").classList.remove("active");
            document.querySelector(".tab-pane:not(.hidden)").classList.add("hidden");
            tab.classList.add("active");
            panes[index].classList.remove("hidden");
        });
    });
}
async function initTheme() {
    try {
        const { gptheme: storedTheme } = await (0, _webextensionPolyfillDefault.default).storage.sync.get("gptheme");
        const theme = storedTheme || (window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark");
        applyTheme(theme);
    } catch (error) {
        console.error("Error initializing theme:", error);
    }
}
async function setTheme(theme) {
    try {
        await (0, _webextensionPolyfillDefault.default).storage.sync.set({
            gptheme: theme
        });
        applyTheme(theme);
        toggleOptions();
    } catch (error) {
        console.error("Error setting theme:", error);
    }
}
function createAndAppendSVGStickyBtn() {
    const gpthFloatingBtn = document.createElement("div");
    gpthFloatingBtn.className = "gpth__floating";
    // <img src="${gpthToggleImg}" alt="gpth-toggle"/>
    let htmlCode = `
		<div class="gpth__floating-icon">
			${(0, _iconsJs.icon_paint)}
		</div>
		
		<div class="gpth__options">
			<div class="gpth__options-btns">
				<button id="light" data-gpth-theme="light">${(0, _iconsJs.icon_sun)}</button>
				<button id="dark" data-gpth-theme="dark">${(0, _iconsJs.icon_moon)}</button>
				<button id="oled" data-gpth-theme="black">${(0, _iconsJs.icon_moon_full)}</button>
				<button id="gpth-open-settings" data-gpth-theme="more">${(0, _iconsJs.icon_settings)}</button>
			</div>
		</div>
	`;
    // gpthFloatingBtn.innerHTML = htmlCode
    gpthFloatingBtn.insertAdjacentHTML("beforeend", htmlCode);
    document.body.appendChild(gpthFloatingBtn);
    // Cache DOM elements after appending
    $htmlTag = document.documentElement;
    $floatingBtn = document.querySelector(".gpth__floating");
    $floatingOptions = document.querySelector(".gpth__options");
    $floatingBtnsContainer = document.querySelector(".gpth__options-btns");
    // Add event listeners after DOM elements are appended
    $floatingBtn.addEventListener("click", toggleOptions);
    $floatingBtnsContainer.addEventListener("click", handleChangeTheme);
}
function handleChangeTheme(e) {
    const themeButton = e.target.closest("button");
    if (!themeButton) return;
    const theme = themeButton.id;
    if (theme !== "gpth-open-settings") {
        setTheme(theme);
        return;
    }
    /* If clicked on "⚙️ Open Settings" */ if (theme === "gpth-open-settings") openSettings();
}
function applyTheme(theme) {
    $htmlTag.dataset.gptheme = theme;
    $htmlTag.style.colorScheme = theme === "oled" ? "dark" : theme;
    $htmlTag.className = theme === "oled" ? "dark" : theme;
    if (theme !== "oled") $htmlTag.removeAttribute("data-gptheme");
}
function toggleOptions() {
    isOptionsShown = !isOptionsShown;
    $floatingOptions.classList.toggle("gpth__options--shown", isOptionsShown);
    if (isOptionsShown) document.body.addEventListener("click", hideOptions);
    else document.body.removeEventListener("click", hideOptions);
}
function hideOptions(e) {
    const isClickInsideFloatingBtn = $floatingBtn.contains(e.target);
    const isClickInsideFloatingOptions = $floatingOptions.contains(e.target);
    if (!isClickInsideFloatingBtn && !isClickInsideFloatingOptions) toggleOptions();
// if (!$floatingBtn.contains(e.target) && !$floatingThemeOptions.contains(e.target)) toggleOptions()
}
function decreiseFloatingBtnSize() {
    setTimeout(()=>{
        $floatingBtn.classList.add("gpth__floating--small");
    }, 3000);
}
/* ______________ THEME CUSTOMIZATION - ACCENT THEME ______________ */ function renderSettings() {
    const gpthSettings = document.createElement("div");
    gpthSettings.className = `gpth-settings fixed flex flex-col`;
    let htmlCode = `
		<header class="mb-5">
			<h2 class="mt-5 text-center font-medium gpth-settings__title"><span class="font-semibold">GPThemes</span> Customization</h2>

			<button class="text-token-text-tertiary hover:text-token-text-primary absolute top-4 right-4" id="gpth-settings-close">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.34315 6.34338L17.6569 17.6571M17.6569 6.34338L6.34315 17.6571" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
			</button>
		</header>

		<main >
			<div class="tabs">
				<div class="tab-buttons flex items-center rounded-full p-1 font-semibold mb-10">
					<button class="tab-button py-2 px-4 focus:outline-none text-center rounded-full active">
						Color
					</button>
					<button class="tab-button py-2 px-4 focus:outline-none text-center rounded-full">
						Font
					</button>
					<button class="tab-button py-2 px-4 focus:outline-none text-center rounded-full">
						Assets
					</button>
				</div>

				<div class="tab-content">
					<div class="tab-pane active" id="tab-colors">
						${renderColorsTab}
					</div>

					<div class="tab-pane hidden" id="tab-fonts">
						${(0, _mainFonts.fontHtmlCode)}
					</div>

					<div class="tab-pane hidden" id="tab-assets">
						<p class="text-center text-token-text-tertiary text-sm mb-2 font-weight-200">ooops, such empty</p>
						<p class="text-center text-token-text-secondary text-md font-semibold">Coming Soon</p>
					</div>
				</div>
			</div>
		</main>
	`;
    gpthSettings.insertAdjacentHTML("beforeend", htmlCode);
    document.body.appendChild(gpthSettings);
    document.getElementById("gpth-settings-close").addEventListener("click", closeSettings);
    $settings = gpthSettings;
    tabsSwitching();
    $resetAllBtn = $settings.querySelector("#resetAllSettings");
    $resetAllBtn.disabled = true;
    $settings.querySelector("#resetAllSettings").addEventListener("click", resetAllSettings);
    // addFontsEventHandlers()
    (0, _mainFonts.handleFontsListeners)();
}
function openSettings() {
    $settings.classList.add("gpth-settings--open");
    $settings.addEventListener("transitionend", handleSettingsOpened);
    $resetAllBtn.disabled = false;
// isOptionsShown = false
// toggleOptions()
}
function handleSettingsOpened() {
    document.body.addEventListener("click", handleClickOutsideSettings);
    $settings.removeEventListener("transitionend", handleSettingsOpened);
}
function closeSettings() {
    $settings.classList.remove("gpth-settings--open");
    document.body.removeEventListener("click", handleClickOutsideSettings);
    $resetAllBtn.disabled = true;
}
function handleClickOutsideSettings(e) {
    let isOpenSettingsButton = e.target.id === "gpth-settings-open";
    if (!$settings.contains(e.target) && !isOpenSettingsButton) closeSettings();
}
function handleColorInput() {
    $settings.addEventListener("click", (e)=>{
        // console.log(e.target)
        if (e.target.id === "accentLight") {
            e.target.addEventListener("input", (e)=>{
                updateCSSVars(e.target.value, null);
            });
            // Save light accent color to storage
            e.target.addEventListener("change", (e)=>{
                setAccentToStorage("accent_light", e.target.value);
                closeSettings();
            });
        }
        if (e.target.id === "accentDark") {
            e.target.addEventListener("input", (e)=>{
                updateCSSVars(null, e.target.value);
            });
            // Save dark accent color to storage
            e.target.addEventListener("change", (e)=>{
                setAccentToStorage("accent_dark", e.target.value);
                closeSettings();
            });
        }
    });
}
// Function to create and inject the <style> element
function injectStyleElement() {
    styleElement = document.createElement("style");
    styleElement.type = "text/css";
    document.head.appendChild(styleElement);
}
function updateCSSVars(lightColor, darkColor) {
    if (!styleElement) injectStyleElement();
    const lightHSL = lightColor ? (0, _hexToHSL.hexToHSL)(lightColor) : (0, _hexToHSL.hexToHSL)($settings.querySelector(".colorpicker #accentLight").value);
    const darkHSL = darkColor ? (0, _hexToHSL.hexToHSL)(darkColor) : (0, _hexToHSL.hexToHSL)($settings.querySelector(".colorpicker #accentDark").value);
    let cssVars = "";
    cssVars = `
        html.light {
            --accent-h: ${lightHSL[0]} !important;
            --accent-s: ${lightHSL[1]}% !important;
            --accent-l: ${lightHSL[2]}% !important;
        }
        html.dark {
            --accent-h: ${darkHSL[0]} !important;
            --accent-s: ${darkHSL[1]}% !important;
            --accent-l: ${darkHSL[2]}% !important;
        }
    `;
    // console.log(cssVars)
    styleElement.textContent = cssVars;
}
async function setAccentToStorage(storageColorProperty, accentValue) {
    try {
        if (storageColorProperty === "accent_light") await (0, _webextensionPolyfillDefault.default).storage.sync.set({
            accent_light: accentValue
        });
        if (storageColorProperty === "accent_dark") await (0, _webextensionPolyfillDefault.default).storage.sync.set({
            accent_dark: accentValue
        });
    // console.log({ storageColorProperty, accentValue })
    } catch (e) {
        console.error("Error setting the accent colors in storage:", e);
    }
}
function setColorInputValue({ accentLight, accentDark }) {
    // console.log({ accentLight, accentDark })
    $settings.querySelector(".colorpicker #accentLight").value = accentLight;
    $settings.querySelector(".colorpicker #accentDark").value = accentDark;
}
async function handleAccentsStorage() {
    try {
        // Get accent colors from storage
        const { accent_light: accentLight, accent_dark: accentDark } = await (0, _webextensionPolyfillDefault.default).storage.sync.get([
            "accent_light",
            "accent_dark"
        ]);
        // console.log('Retrieved accent colors from storage:', accentLight, accentDark)
        // Set default accent colors if not already set
        if (!accentLight || !accentDark) {
            await (0, _webextensionPolyfillDefault.default).storage.sync.set({
                accent_light: defaultColorLight,
                accent_dark: defaultColorDark
            });
            console.log("Default accent colors set in storage");
        }
        const accentColorLight = accentLight || defaultColorLight;
        const accentColorDark = accentDark || defaultColorDark;
        // Update CSS with retrieved or default accent colors
        updateCSSVars(accentColorLight, accentColorDark);
        setColorInputValue({
            accentLight: accentColorLight,
            accentDark: accentColorDark
        });
    // console.log('Accent colors applied to CSS:', accentColorLight, accentColorDark)
    } catch (error) {
        console.error("Error handling accent colors:", error);
    }
}
async function resetAllSettings() {
    if (!styleElement) injectStyleElement();
    // let accentLight = [250, 99, 65]
    // let accentDark = [272, 93, 78]
    let accentLight = (0, _hexToHSL.hexToHSL)(defaultColorLight);
    let accentDark = (0, _hexToHSL.hexToHSL)(defaultColorDark);
    const cssVars = `
        html.light {
            --accent-h: ${accentLight[0]} !important;
            --accent-s: ${accentLight[1]}% !important;
            --accent-l: ${accentLight[2]}% !important;
        }
        html.dark {
            --accent-h: ${accentDark[0]} !important;
            --accent-s: ${accentDark[1]}% !important;
            --accent-l: ${accentDark[2]}% !important;
        }
    `;
    styleElement.textContent = cssVars;
    setColorInputValue({
        accentLight: defaultColorLight,
        accentDark: defaultColorDark
    });
    await (0, _webextensionPolyfillDefault.default).storage.sync.set({
        accent_light: defaultColorLight,
        accent_dark: defaultColorDark
    });
}
/* === Initialization */ function init() {
    initTheme();
    createAndAppendSVGStickyBtn();
    renderSettings();
    decreiseFloatingBtnSize();
    handleAccentsStorage();
    handleColorInput();
} /* ? Only for debugging - remove later! */  /* debugGetAllStorageItems()
// Get all the items in the storage
function debugGetAllStorageItems() {
	browser.storage.sync.get(null, function (items) {
		console.log(items) // This will log all the items stored in sync storage
	})
}
*/ 

},{"webextension-polyfill":"Zel51","./components/icons.js":"8IOPt","../utils/hexToHSL":"gNsnw","./mainFonts":"gynjN","@parcel/transformer-js/src/esmodule-helpers.js":"4IpBY"}],"Zel51":[function(require,module,exports) {
(function(global, factory) {
    if (typeof define === "function" && define.amd) define("webextension-polyfill", [
        "module"
    ], factory);
    else {
        var mod;
        factory(module);
    }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function(module1) {
    /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */ /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */ /* vim: set sts=2 sw=2 et tw=80: */ /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */ "use strict";
    if (!globalThis.chrome?.runtime?.id) throw new Error("This script should only be loaded in a browser extension.");
    if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
        const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
        // optimization for Firefox. Since Spidermonkey does not fully parse the
        // contents of a function until the first time it's called, and since it will
        // never actually need to be called, this allows the polyfill to be included
        // in Firefox nearly for free.
        const wrapAPIs = (extensionAPIs)=>{
            // NOTE: apiMetadata is associated to the content of the api-metadata.json file
            // at build time by replacing the following "include" with the content of the
            // JSON file.
            const apiMetadata = {
                "alarms": {
                    "clear": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "clearAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "get": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "bookmarks": {
                    "create": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "get": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getChildren": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getRecent": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getSubTree": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getTree": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "move": {
                        "minArgs": 2,
                        "maxArgs": 2
                    },
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeTree": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "search": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "update": {
                        "minArgs": 2,
                        "maxArgs": 2
                    }
                },
                "browserAction": {
                    "disable": {
                        "minArgs": 0,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "enable": {
                        "minArgs": 0,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "getBadgeBackgroundColor": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getBadgeText": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getPopup": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getTitle": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "openPopup": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "setBadgeBackgroundColor": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "setBadgeText": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "setIcon": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "setPopup": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "setTitle": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    }
                },
                "browsingData": {
                    "remove": {
                        "minArgs": 2,
                        "maxArgs": 2
                    },
                    "removeCache": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeCookies": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeDownloads": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeFormData": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeHistory": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeLocalStorage": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removePasswords": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removePluginData": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "settings": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "commands": {
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "contextMenus": {
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "update": {
                        "minArgs": 2,
                        "maxArgs": 2
                    }
                },
                "cookies": {
                    "get": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getAll": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getAllCookieStores": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "set": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "devtools": {
                    "inspectedWindow": {
                        "eval": {
                            "minArgs": 1,
                            "maxArgs": 2,
                            "singleCallbackArg": false
                        }
                    },
                    "panels": {
                        "create": {
                            "minArgs": 3,
                            "maxArgs": 3,
                            "singleCallbackArg": true
                        },
                        "elements": {
                            "createSidebarPane": {
                                "minArgs": 1,
                                "maxArgs": 1
                            }
                        }
                    }
                },
                "downloads": {
                    "cancel": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "download": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "erase": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getFileIcon": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "open": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "pause": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeFile": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "resume": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "search": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "show": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    }
                },
                "extension": {
                    "isAllowedFileSchemeAccess": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "isAllowedIncognitoAccess": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "history": {
                    "addUrl": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "deleteAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "deleteRange": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "deleteUrl": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getVisits": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "search": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "i18n": {
                    "detectLanguage": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getAcceptLanguages": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "identity": {
                    "launchWebAuthFlow": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "idle": {
                    "queryState": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "management": {
                    "get": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "getSelf": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "setEnabled": {
                        "minArgs": 2,
                        "maxArgs": 2
                    },
                    "uninstallSelf": {
                        "minArgs": 0,
                        "maxArgs": 1
                    }
                },
                "notifications": {
                    "clear": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "create": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "getPermissionLevel": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "update": {
                        "minArgs": 2,
                        "maxArgs": 2
                    }
                },
                "pageAction": {
                    "getPopup": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getTitle": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "hide": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "setIcon": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "setPopup": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "setTitle": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    },
                    "show": {
                        "minArgs": 1,
                        "maxArgs": 1,
                        "fallbackToNoCallback": true
                    }
                },
                "permissions": {
                    "contains": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "request": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "runtime": {
                    "getBackgroundPage": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "getPlatformInfo": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "openOptionsPage": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "requestUpdateCheck": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "sendMessage": {
                        "minArgs": 1,
                        "maxArgs": 3
                    },
                    "sendNativeMessage": {
                        "minArgs": 2,
                        "maxArgs": 2
                    },
                    "setUninstallURL": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "sessions": {
                    "getDevices": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "getRecentlyClosed": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "restore": {
                        "minArgs": 0,
                        "maxArgs": 1
                    }
                },
                "storage": {
                    "local": {
                        "clear": {
                            "minArgs": 0,
                            "maxArgs": 0
                        },
                        "get": {
                            "minArgs": 0,
                            "maxArgs": 1
                        },
                        "getBytesInUse": {
                            "minArgs": 0,
                            "maxArgs": 1
                        },
                        "remove": {
                            "minArgs": 1,
                            "maxArgs": 1
                        },
                        "set": {
                            "minArgs": 1,
                            "maxArgs": 1
                        }
                    },
                    "managed": {
                        "get": {
                            "minArgs": 0,
                            "maxArgs": 1
                        },
                        "getBytesInUse": {
                            "minArgs": 0,
                            "maxArgs": 1
                        }
                    },
                    "sync": {
                        "clear": {
                            "minArgs": 0,
                            "maxArgs": 0
                        },
                        "get": {
                            "minArgs": 0,
                            "maxArgs": 1
                        },
                        "getBytesInUse": {
                            "minArgs": 0,
                            "maxArgs": 1
                        },
                        "remove": {
                            "minArgs": 1,
                            "maxArgs": 1
                        },
                        "set": {
                            "minArgs": 1,
                            "maxArgs": 1
                        }
                    }
                },
                "tabs": {
                    "captureVisibleTab": {
                        "minArgs": 0,
                        "maxArgs": 2
                    },
                    "create": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "detectLanguage": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "discard": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "duplicate": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "executeScript": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "get": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getCurrent": {
                        "minArgs": 0,
                        "maxArgs": 0
                    },
                    "getZoom": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "getZoomSettings": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "goBack": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "goForward": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "highlight": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "insertCSS": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "move": {
                        "minArgs": 2,
                        "maxArgs": 2
                    },
                    "query": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "reload": {
                        "minArgs": 0,
                        "maxArgs": 2
                    },
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "removeCSS": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "sendMessage": {
                        "minArgs": 2,
                        "maxArgs": 3
                    },
                    "setZoom": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "setZoomSettings": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "update": {
                        "minArgs": 1,
                        "maxArgs": 2
                    }
                },
                "topSites": {
                    "get": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "webNavigation": {
                    "getAllFrames": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "getFrame": {
                        "minArgs": 1,
                        "maxArgs": 1
                    }
                },
                "webRequest": {
                    "handlerBehaviorChanged": {
                        "minArgs": 0,
                        "maxArgs": 0
                    }
                },
                "windows": {
                    "create": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "get": {
                        "minArgs": 1,
                        "maxArgs": 2
                    },
                    "getAll": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "getCurrent": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "getLastFocused": {
                        "minArgs": 0,
                        "maxArgs": 1
                    },
                    "remove": {
                        "minArgs": 1,
                        "maxArgs": 1
                    },
                    "update": {
                        "minArgs": 2,
                        "maxArgs": 2
                    }
                }
            };
            if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
            /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */ class DefaultWeakMap extends WeakMap {
                constructor(createItem, items){
                    super(items);
                    this.createItem = createItem;
                }
                get(key) {
                    if (!this.has(key)) this.set(key, this.createItem(key));
                    return super.get(key);
                }
            }
            /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */ const isThenable = (value)=>{
                return value && typeof value === "object" && typeof value.then === "function";
            };
            /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */ const makeCallback = (promise, metadata)=>{
                return (...callbackArgs)=>{
                    if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                    else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
                    else promise.resolve(callbackArgs);
                };
            };
            const pluralizeArguments = (numArgs)=>numArgs == 1 ? "argument" : "arguments";
            /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */ const wrapAsyncFunction = (name, metadata)=>{
                return function asyncFunctionWrapper(target, ...args) {
                    if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                    if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                    return new Promise((resolve, reject)=>{
                        if (metadata.fallbackToNoCallback) // This API method has currently no callback on Chrome, but it return a promise on Firefox,
                        // and so the polyfill will try to call it with a callback first, and it will fallback
                        // to not passing the callback if the first call fails.
                        try {
                            target[name](...args, makeCallback({
                                resolve,
                                reject
                            }, metadata));
                        } catch (cbError) {
                            console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                            target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                            // use the unsupported callback anymore.
                            metadata.fallbackToNoCallback = false;
                            metadata.noCallback = true;
                            resolve();
                        }
                        else if (metadata.noCallback) {
                            target[name](...args);
                            resolve();
                        } else target[name](...args, makeCallback({
                            resolve,
                            reject
                        }, metadata));
                    });
                };
            };
            /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */ const wrapMethod = (target, method, wrapper)=>{
                return new Proxy(method, {
                    apply (targetMethod, thisObj, args) {
                        return wrapper.call(thisObj, target, ...args);
                    }
                });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */ const wrapObject = (target, wrappers = {}, metadata = {})=>{
                let cache = Object.create(null);
                let handlers = {
                    has (proxyTarget, prop) {
                        return prop in target || prop in cache;
                    },
                    get (proxyTarget, prop, receiver) {
                        if (prop in cache) return cache[prop];
                        if (!(prop in target)) return undefined;
                        let value = target[prop];
                        if (typeof value === "function") {
                            // This is a method on the underlying object. Check if we need to do
                            // any wrapping.
                            if (typeof wrappers[prop] === "function") // We have a special-case wrapper for this method.
                            value = wrapMethod(target, target[prop], wrappers[prop]);
                            else if (hasOwnProperty(metadata, prop)) {
                                // This is an async method that we have metadata for. Create a
                                // Promise wrapper for it.
                                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                                value = wrapMethod(target, target[prop], wrapper);
                            } else // This is a method that we don't know or care about. Return the
                            // original method, bound to the underlying object.
                            value = value.bind(target);
                        } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) // This is an object that we need to do some wrapping for the children
                        // of. Create a sub-object wrapper for it with the appropriate child
                        // metadata.
                        value = wrapObject(value, wrappers[prop], metadata[prop]);
                        else if (hasOwnProperty(metadata, "*")) // Wrap all properties in * namespace.
                        value = wrapObject(value, wrappers[prop], metadata["*"]);
                        else {
                            // We don't need to do any wrapping for this property,
                            // so just forward all access to the underlying object.
                            Object.defineProperty(cache, prop, {
                                configurable: true,
                                enumerable: true,
                                get () {
                                    return target[prop];
                                },
                                set (value) {
                                    target[prop] = value;
                                }
                            });
                            return value;
                        }
                        cache[prop] = value;
                        return value;
                    },
                    set (proxyTarget, prop, value, receiver) {
                        if (prop in cache) cache[prop] = value;
                        else target[prop] = value;
                        return true;
                    },
                    defineProperty (proxyTarget, prop, desc) {
                        return Reflect.defineProperty(cache, prop, desc);
                    },
                    deleteProperty (proxyTarget, prop) {
                        return Reflect.deleteProperty(cache, prop);
                    }
                }; // Per contract of the Proxy API, the "get" proxy handler must return the
                // original value of the target if that value is declared read-only and
                // non-configurable. For this reason, we create an object with the
                // prototype set to `target` instead of using `target` directly.
                // Otherwise we cannot return a custom object for APIs that
                // are declared read-only and non-configurable, such as `chrome.devtools`.
                //
                // The proxy handlers themselves will still use the original `target`
                // instead of the `proxyTarget`, so that the methods and properties are
                // dereferenced via the original targets.
                let proxyTarget = Object.create(target);
                return new Proxy(proxyTarget, handlers);
            };
            /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */ const wrapEvent = (wrapperMap)=>({
                    addListener (target, listener, ...args) {
                        target.addListener(wrapperMap.get(listener), ...args);
                    },
                    hasListener (target, listener) {
                        return target.hasListener(wrapperMap.get(listener));
                    },
                    removeListener (target, listener) {
                        target.removeListener(wrapperMap.get(listener));
                    }
                });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener)=>{
                if (typeof listener !== "function") return listener;
                /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */ return function onRequestFinished(req) {
                    const wrappedReq = wrapObject(req, {}, {
                        getContent: {
                            minArgs: 0,
                            maxArgs: 0
                        }
                    });
                    listener(wrappedReq);
                };
            });
            const onMessageWrappers = new DefaultWeakMap((listener)=>{
                if (typeof listener !== "function") return listener;
                /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */ return function onMessage(message, sender, sendResponse) {
                    let didCallSendResponse = false;
                    let wrappedSendResponse;
                    let sendResponsePromise = new Promise((resolve)=>{
                        wrappedSendResponse = function(response) {
                            didCallSendResponse = true;
                            resolve(response);
                        };
                    });
                    let result;
                    try {
                        result = listener(message, sender, wrappedSendResponse);
                    } catch (err) {
                        result = Promise.reject(err);
                    }
                    const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
                    // wrappedSendResponse synchronously, we can exit earlier
                    // because there will be no response sent from this listener.
                    if (result !== true && !isResultThenable && !didCallSendResponse) return false;
                     // A small helper to send the message if the promise resolves
                    // and an error if the promise rejects (a wrapped sendMessage has
                    // to translate the message into a resolved promise or a rejected
                    // promise).
                    const sendPromisedResult = (promise)=>{
                        promise.then((msg)=>{
                            // send the message value.
                            sendResponse(msg);
                        }, (error)=>{
                            // Send a JSON representation of the error if the rejected value
                            // is an instance of error, or the object itself otherwise.
                            let message;
                            if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
                            else message = "An unexpected error occurred";
                            sendResponse({
                                __mozWebExtensionPolyfillReject__: true,
                                message
                            });
                        }).catch((err)=>{
                            // Print an error on the console if unable to send the response.
                            console.error("Failed to send onMessage rejected reply", err);
                        });
                    }; // If the listener returned a Promise, send the resolved value as a
                    // result, otherwise wait the promise related to the wrappedSendResponse
                    // callback to resolve and send it as a response.
                    if (isResultThenable) sendPromisedResult(result);
                    else sendPromisedResult(sendResponsePromise);
                     // Let Chrome know that the listener is replying.
                    return true;
                };
            });
            const wrappedSendMessageCallback = ({ reject, resolve }, reply)=>{
                if (extensionAPIs.runtime.lastError) {
                    // Detect when none of the listeners replied to the sendMessage call and resolve
                    // the promise to undefined as in Firefox.
                    // See https://github.com/mozilla/webextension-polyfill/issues/130
                    if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
                    else reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (reply && reply.__mozWebExtensionPolyfillReject__) // Convert back the JSON representation of the error into
                // an Error instance.
                reject(new Error(reply.message));
                else resolve(reply);
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args)=>{
                if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                return new Promise((resolve, reject)=>{
                    const wrappedCb = wrappedSendMessageCallback.bind(null, {
                        resolve,
                        reject
                    });
                    args.push(wrappedCb);
                    apiNamespaceObj.sendMessage(...args);
                });
            };
            const staticWrappers = {
                devtools: {
                    network: {
                        onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                    }
                },
                runtime: {
                    onMessage: wrapEvent(onMessageWrappers),
                    onMessageExternal: wrapEvent(onMessageWrappers),
                    sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                        minArgs: 1,
                        maxArgs: 3
                    })
                },
                tabs: {
                    sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                        minArgs: 2,
                        maxArgs: 3
                    })
                }
            };
            const settingMetadata = {
                clear: {
                    minArgs: 1,
                    maxArgs: 1
                },
                get: {
                    minArgs: 1,
                    maxArgs: 1
                },
                set: {
                    minArgs: 1,
                    maxArgs: 1
                }
            };
            apiMetadata.privacy = {
                network: {
                    "*": settingMetadata
                },
                services: {
                    "*": settingMetadata
                },
                websites: {
                    "*": settingMetadata
                }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
        }; // The build process adds a UMD wrapper around this file, which makes the
        // `module` variable available.
        module1.exports = wrapAPIs(chrome);
    } else module1.exports = globalThis.browser;
});

},{}],"8IOPt":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "icon_sun", ()=>icon_sun);
parcelHelpers.export(exports, "icon_moon", ()=>icon_moon);
parcelHelpers.export(exports, "icon_moon_full", ()=>icon_moon_full);
parcelHelpers.export(exports, "icon_settings", ()=>icon_settings);
parcelHelpers.export(exports, "icon_paint", ()=>icon_paint);
parcelHelpers.export(exports, "icon_palette", ()=>icon_palette);
const icon_sun = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-sun"><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" /><path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7" /></svg>`;
const icon_moon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-moon"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 3c.132 0 .263 0 .393 0a7.5 7.5 0 0 0 7.92 12.446a9 9 0 1 1 -8.313 -12.454z" /></svg>`;
const icon_moon_full = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-moon-2"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.418 4.157a8 8 0 0 0 0 15.686" /><path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" /></svg>`;
const icon_settings = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-settings"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065z" /><path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" /></svg>`;
const icon_paint = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-paint"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 3m0 2a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v2a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2z" /><path d="M19 6h1a2 2 0 0 1 2 2a5 5 0 0 1 -5 5l-5 0v2" /><path d="M10 15m0 1a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1z" /></svg>`;
const icon_palette = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-palette"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 21a9 9 0 0 1 0 -18c4.97 0 9 3.582 9 8c0 1.06 -.474 2.078 -1.318 2.828c-.844 .75 -1.989 1.172 -3.182 1.172h-2.5a2 2 0 0 0 -1 3.75a1.3 1.3 0 0 1 -1 2.25" /><path d="M8.5 10.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M12.5 7.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /><path d="M16.5 10.5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" /></svg>`;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"4IpBY"}],"4IpBY":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"gNsnw":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "hexToHSL", ()=>hexToHSL);
function hexToHSL(hex) {
    // Convert hex to RGB first
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 7) {
        r = parseInt(hex.slice(1, 3), 16);
        g = parseInt(hex.slice(3, 5), 16);
        b = parseInt(hex.slice(5, 7), 16);
    }
    // Then convert RGB to HSL
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h, s, l = (max + min) / 2;
    if (max === min) h = s = 0 // achromatic
    ;
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch(max){
            case r:
                h = (g - b) / d + (g < b ? 6 : 0);
                break;
            case g:
                h = (b - r) / d + 2;
                break;
            case b:
                h = (r - g) / d + 4;
                break;
        }
        h /= 6;
    }
    return [
        Math.round(h * 360),
        Math.round(s * 100),
        Math.round(l * 100)
    ];
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"4IpBY"}],"gynjN":[function(require,module,exports) {
// main.js
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "fontHtmlCode", ()=>fontHtmlCode);
// Function to handle font listeners
parcelHelpers.export(exports, "handleFontsListeners", ()=>handleFontsListeners);
var _webextensionPolyfill = require("webextension-polyfill");
var _webextensionPolyfillDefault = parcelHelpers.interopDefault(_webextensionPolyfill);
var _renderFonts = require("./components/renderFonts");
// Constants
const DEFAULTS = {
    fontFamily: getComputedStyle(document.documentElement).getPropertyValue("--fontFamilyDefault"),
    fontSize: 16,
    letterSpacing: 0,
    lineHeight: 28
};
const FONT_NAMES = [
    "Default",
    "Inter",
    "Roboto",
    "Roboto Mono",
    "DM Sans",
    "Reddit Mono",
    "Poppins",
    "Noto Sans",
    "Lato",
    "Quicksand",
    "Outfit"
];
// const GOOGLE_FONT_WEIGHTS = `:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900`
const GOOGLE_FONT_WEIGHTS = `:ital,wght@0,100;0,300;0,400;0,500;0,600;0,700;1,100;1,300;1,400;1,500;1,600;1,700`;
let onFocusValFontSize = null, onFocusValLineHeight = null, onFocusValLetterSpacing = null;
const fontSizeData = {
    name: "Font Size",
    className: "fonts__size",
    inputId: "fontSize",
    inputType: "number",
    inputValue: DEFAULTS.fontSize,
    inputPlaceholder: DEFAULTS.fontSize,
    unit: "px",
    min: 12,
    max: 24
};
const lineHeightData = {
    name: "Line Height",
    className: "fonts__lineHeight",
    inputId: "lineHeight",
    inputType: "number",
    inputValue: DEFAULTS.lineHeight,
    inputPlaceholder: DEFAULTS.lineHeight,
    unit: "px",
    min: 12,
    max: 60
};
const letterSpacingData = {
    name: "Letter Spacing",
    className: "fonts__letterSpacing",
    inputId: "letterSpacing",
    inputType: "number",
    inputValue: DEFAULTS.letterSpacing,
    inputPlaceholder: DEFAULTS.letterSpacing,
    unit: "px",
    min: -30,
    max: 30
};
let fontHtmlCode = `
  <section id="fontChangerPopover" class="fonts">
    <div class="fonts__props">
      <div class="fonts__family fonts__group card card--big h-full">
        <label for="fontFamily" class="grid gap-1 h-full w-full">
          <div>
            <p class="card__unit card__icon">T</p>
            <p class="card__name uppercase font-semibold">FONT FAMILY</p>
          </div>
          <select id="fontFamily" class="border-none outline-none focus:none font-bold">
            ${FONT_NAMES.map((name)=>`<option value="${name === "Default" ? DEFAULTS.fontFamily : name}">${name}</option>`).join("")}
          </select>
        </label>
      </div>
      ${(0, _renderFonts.renderFontBigCard)(fontSizeData)}
      ${(0, _renderFonts.renderFontSmallCard)(lineHeightData)}
      ${(0, _renderFonts.renderFontSmallCard)(letterSpacingData)}
    </div>
    <footer class="grid mt-10">
      ${(0, _renderFonts.renderButton)({
    id: "resetFont",
    content: "Reset Fonts",
    disabled: false,
    className: "btn-primary"
})}
    </footer>
  </section>
`;
// Function to set input field values
function setInputFieldValue(inputSelector, inputVal) {
    const inputEl = document.querySelector(`.gpth-settings #${inputSelector}`);
    inputEl.value = inputVal;
}
// Function to apply settings
function applySettings(settings) {
    Object.entries(settings).forEach(([key, value])=>{
        document.documentElement.style.setProperty(`--${key}`, value);
        setInputFieldValue(key, value);
    // console.log('getComputedStyle: ', getComputedStyle(document.documentElement).getPropertyValue(`--${key}`))
    });
}
// Function to save settings to Chrome Storage
async function saveSettings(settings) {
    try {
        await (0, _webextensionPolyfillDefault.default).storage.sync.set(settings);
    } catch (error) {
        console.error("Failed to save settings:", error);
    }
}
// Function to load settings from Chrome Storage
async function loadSettings() {
    try {
        const settings = await (0, _webextensionPolyfillDefault.default).storage.sync.get(Object.keys(DEFAULTS));
        if (settings.fontFamily && settings.fontFamily !== DEFAULTS.fontFamily) loadGoogleFont(settings.fontFamily);
        applySettings(settings);
    } catch (error) {
        console.error("Failed to load settings:", error);
    }
}
// Function to dynamically load Google Fonts
function loadGoogleFont(fontFamily) {
    /* 	const href = `https://fonts.googleapis.com/css2?family=${fontFamily.replace(
		' ',
		'+'
	)}${GOOGLE_FONT_WEIGHTS}&display=swap`

	const link = document.createElement('link')
	link.rel = 'stylesheet'
	link.href = href
	document.head.appendChild(link) */ const links = [
        {
            rel: "preconnect",
            href: "https://fonts.googleapis.com"
        },
        {
            rel: "preconnect",
            href: "https://fonts.gstatic.com",
            crossorigin: ""
        },
        {
            rel: "stylesheet",
            href: `https://fonts.googleapis.com/css2?family=${fontFamily.replace(" ", "+")}${GOOGLE_FONT_WEIGHTS}&display=swap`
        }
    ];
    links.forEach(({ rel, href, crossorigin })=>{
        const link = document.createElement("link");
        link.rel = rel;
        link.href = href;
        if (crossorigin !== undefined) link.crossOrigin = crossorigin;
        document.head.appendChild(link);
    });
}
// Function to get all Google Font links
function getAllHeadFontsLinks() {
    // return Array.from(document.querySelectorAll("link[rel='stylesheet'], link[rel='preconnect']"))
    return Array.from(document.querySelectorAll("head link[href*='fonts.']"));
}
// Function to remove all Google Font links
function removeAllGoogleFontsLinks() {
    const links = getAllHeadFontsLinks();
    // console.log('links: ', links)
    links.forEach((link)=>{
        if (link.href.includes("fonts.googleapis.com") || link.href.includes("fonts.gstatic.com")) link.remove();
    });
}
/* function getAllHeadLinks() {
	return Array.from(document.querySelectorAll("link[rel='stylesheet']"))
}
// Function to remove all Google Font links
function removeAllGoogleFontsLinks() {
	const links = getAllHeadLinks()

	links.forEach((link) => {
		if (link.href.includes('googleapis.com')) {
			link.remove()
		}
	})
} */ // Function to validate input fields
function validateInputField(inputValue, min, max = 24) {
    if (isNaN(inputValue)) {
        displayError("Empty or invalid value");
        return false;
    } else if (inputValue < min || inputValue > max) {
        displayError(`Number must be between ${min} and ${max}`);
        return false;
    }
    return true;
}
// Function to display error messages
function displayError(message) {
    // Remove any previous error messages
    const existingError = document.querySelector(".gpth-error-msg");
    if (existingError) existingError.remove();
    // Create and insert the new error message
    const errorMessage = document.createElement("div");
    errorMessage.className = "gpth-error-msg fixed rounded-xl bg-red-500 red-500 p-3 font-semibold text-center";
    errorMessage.textContent = message;
    document.body.appendChild(errorMessage);
    // Remove the error message after 4 seconds
    setTimeout(()=>{
        errorMessage.remove();
    }, 4000);
}
// Function to format numbers
function formatNumber(inputVal, toFixedNum = 2) {
    // Remove leading zeros from the integer part
    inputVal = inputVal.replace(/^0+(?=\d*\.)/, "");
    // Parse the input as a number and return it with 2 decimal places
    let formatted = parseFloat(inputVal).toFixed(toFixedNum);
    // Remove trailing zeros from the decimal part
    formatted = formatted.replace(/\.?0+$/, "");
    // Return the formatted number as a string
    return formatted;
}
// Function to handle font size change
function changeFontSize(e) {
    const newVal = formatNumber(e.target.value);
    onFocusValFontSize = formatNumber(onFocusValFontSize, 4);
    if (onFocusValFontSize === newVal) return;
    if (!validateInputField(newVal, fontSizeData.min, fontSizeData.max)) {
        setInputFieldValue("fontSize", onFocusValFontSize);
        applySettings({
            fontSize: onFocusValFontSize
        });
        saveSettings({
            fontSize: onFocusValFontSize
        });
        // setInputField('fontSize', DEFAULTS.fontSize)
        // applySettings({ fontSize: DEFAULTS.fontSize })
        // saveSettings({ fontSize: DEFAULTS.fontSize })
        return;
    }
    applySettings({
        fontSize: newVal
    });
    saveSettings({
        fontSize: newVal
    });
}
// Function to handle line height change
function changeLineHeight(e) {
    const newVal = formatNumber(e.target.value);
    onFocusValLineHeight = formatNumber(onFocusValLineHeight, 4);
    if (onFocusValLineHeight === newVal) return;
    if (!validateInputField(newVal, lineHeightData.min, lineHeightData.max)) {
        setInputFieldValue("lineHeight", onFocusValLineHeight);
        applySettings({
            lineHeight: onFocusValLineHeight
        });
        saveSettings({
            lineHeight: onFocusValLineHeight
        });
        return;
    }
    applySettings({
        lineHeight: newVal
    });
    saveSettings({
        lineHeight: newVal
    });
}
// Function to handle letter spacing change
function changeLetterSpacing(e) {
    const newVal = formatNumber(e.target.value);
    onFocusValLetterSpacing = formatNumber(onFocusValLetterSpacing, 4);
    if (onFocusValLetterSpacing === newVal) return;
    if (!validateInputField(newVal, letterSpacingData.min, letterSpacingData.max)) {
        setInputFieldValue("letterSpacing", onFocusValLetterSpacing);
        applySettings({
            letterSpacing: onFocusValLetterSpacing
        });
        saveSettings({
            letterSpacing: onFocusValLetterSpacing
        });
        return;
    }
    applySettings({
        letterSpacing: newVal
    });
    saveSettings({
        letterSpacing: newVal
    });
}
// Function to handle font family change
async function changeFontFamily(e) {
    const selectedFont = e.target.value;
    // Remove all existing Google Fonts links
    removeAllGoogleFontsLinks();
    if (selectedFont !== DEFAULTS.fontFamily) {
        // Load the newly selected Google Font
        loadGoogleFont(selectedFont);
        applySettings({
            fontFamily: selectedFont
        });
        try {
            await saveSettings({
                fontFamily: selectedFont
            });
        } catch (error) {
            console.error("Failed to save font family:", error);
        }
    } else {
        // Apply default font family settings
        applySettings({
            fontFamily: selectedFont
        });
        try {
            await saveSettings({
                fontFamily: selectedFont
            });
        } catch (error) {
            console.error("Failed to reset font family:", error);
        }
    }
}
// Function to reset fonts to default
function resetFonts() {
    applySettings(DEFAULTS);
    saveSettings(DEFAULTS);
}
function handleFontsListeners() {
    const selectors = {
        selectFontFamily: document.querySelector(".gpth-settings #fontFamily"),
        inputFontSize: document.querySelector(".gpth-settings #fontSize"),
        inputLineHeight: document.querySelector(".gpth-settings #lineHeight"),
        inputLetterSpacing: document.querySelector(".gpth-settings #letterSpacing"),
        btnResetFont: document.querySelector(".gpth-settings #resetFont")
    };
    selectors.selectFontFamily.addEventListener("change", changeFontFamily);
    selectors.inputFontSize.addEventListener("blur", changeFontSize);
    selectors.inputLineHeight.addEventListener("blur", changeLineHeight);
    selectors.inputLetterSpacing.addEventListener("blur", changeLetterSpacing);
    selectors.inputFontSize.addEventListener("focus", (e)=>{
        onFocusValFontSize = e.target.value;
    });
    selectors.inputLineHeight.addEventListener("focus", (e)=>{
        onFocusValLineHeight = e.target.value;
    });
    selectors.inputLetterSpacing.addEventListener("focus", (e)=>{
        onFocusValLetterSpacing = e.target.value;
    });
    selectors.inputFontSize.addEventListener("keypress", (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            changeFontSize(e);
            e.target.blur();
        }
    });
    selectors.inputLineHeight.addEventListener("keypress", (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            changeLineHeight(e);
            e.target.blur();
        }
    });
    selectors.inputLetterSpacing.addEventListener("keypress", (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            changeLetterSpacing(e);
            e.target.blur();
        }
    });
    selectors.btnResetFont.addEventListener("click", resetFonts);
}
// Function to initialize the settings
function init() {
    // Load settings on page load
    loadSettings();
}
init();

},{"webextension-polyfill":"Zel51","./components/renderFonts":"hOcoo","@parcel/transformer-js/src/esmodule-helpers.js":"4IpBY"}],"hOcoo":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "renderFontSmallCard", ()=>renderFontSmallCard);
parcelHelpers.export(exports, "renderFontBigCard", ()=>renderFontBigCard);
// export function renderFontCard({ data, cardType = 'small', includeFields = [] }) {
// 	const { name, className, inputId, inputType, inputValue, inputPlaceholder, min = 0, max = 24, unit = 'px' } = data
// 	let cardHtml
// 	if (cardType === 'small') {
// 		cardHtml = `
// 			<div class="${className} card card--small" data-gpth-err="${min}${unit} &hArr; ${max}${unit}">
// 				<label for="${inputId}" class="rounded-full flex items-center gap-2 h-full w-full">
// 					${
// 						includeFields.includes('input')
// 							? `<input type="${inputType}" id="${inputId}" value="${inputValue}" placeholder="${inputPlaceholder}" class="rounded-full outline-none border-none font-bold" minlength="${min}" maxlength="${max}">`
// 							: ''
// 					}
// 					<div class="card__unitname-wrapper">
// 					<p class="card__unit rounded-full flex items-center justify-center">${unit}</p>
// 					<p class="card__name uppercase font-semibold">${name}</p>
// 					</div>
// 				</label>
// 			</div>
// 		`
// 	} else if (cardType === 'big') {
// 		cardHtml = `
// 			<div class="${className} fonts__group card card--big h-full" data-gpth-err="${min}${unit} &hArr; ${max}${unit}">
// 				<label for="${inputId}" class="grid gap-1 h-full w-full">
// 					<div>
// 						<p class="card__unit card__icon">${unit.toUpperCase()}</p>
// 						<p class="card__name uppercase font-semibold">${name}</p>
// 					</div>
// 					${
// 						includeFields.includes('input')
// 							? `<input type="${inputType}" id="${inputId}" value="${inputValue}" placeholder="${inputPlaceholder}" class="outline-none border-none focus:outline-none focus:border-none font-bold" minlength="${min}" maxlength="${max}">`
// 							: ''
// 					}
// 				</label>
// 			</div>
// 		`
// 	} else {
// 		throw new Error('Invalid card type specified.')
// 	}
// 	return cardHtml
// }
parcelHelpers.export(exports, "renderButton", ()=>renderButton);
function renderFontSmallCard({ name, className, inputId, inputType, inputValue, inputPlaceholder, min = 16, max = 24, unit = "px" }) {
    return `
        <div class="${className} card card--small" data-gpth-err="${min}${unit} &hArr; ${max}${unit}">
            <label for="${inputId}" class="rounded-full flex items-center gap-2 h-full w-full">
                <input type="${inputType}" id="${inputId}" value="${inputValue}" placeholder="${inputPlaceholder}" class="rounded-full outline-none border-none font-bold" minlength="${min}" maxlength="${max}">

                <div class="card__unitname-wrapper">
                    <p class="card__unit rounded-full flex items-center justify-center">pixels</p>
                    <p class="card__name uppercase font-semibold">${name}</p>
                </div>
            </label>
        </div>`;
}
function renderFontBigCard({ name, className, inputId, inputType, inputValue, inputPlaceholder, min = 0, max = 20, unit = "px" }) {
    return `
        <div class="${className} fonts__group card card--big h-full" data-gpth-err="${min}${unit} &hArr; ${max}${unit}">
            <label for="${inputId}" class="grid gap-1 h-full w-full">
                <div>
                    <p class="card__unit card__icon">PX</p>
                    <p class="card__name uppercase font-semibold">${name}</p>
                </div>

                <input type="${inputType}" id="${inputId}" value="${inputValue}" placeholder="${inputPlaceholder}" class="outline-none border-none focus:outline-none focus:border-none font-bold" minlength="${min}" maxlength="${max}">
            </label>
        </div>`;
}
function renderButton({ name, className, id, content, disabled = false }) {
    return `
        <button id="${id}" class="btn block relative text-center ${className}" ${disabled ? "disabled" : ""}>
            ${content}
        </button>
	`;
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"4IpBY"}]},["anGFI","3q87D"], "3q87D", "parcelRequire2158")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJLFdBQVc7QUFBWSxJQUFJLFdBQVc7QUFBSyxJQUFJLGFBQWE7QUFBTSxJQUFJLGVBQWU7QUFBbUIsSUFBSSxjQUFjO0FBQU0sT0FBTyxNQUFNLENBQUMsYUFBYSxHQUFHO0FBQW1CO0FBRXJMLDhKQUE4SixHQUM5Sjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQThDQSxHQUNBLElBQUksYUFBYTtBQUNqQixJQUFJLFlBQVksT0FBTyxNQUFNLENBQUMsTUFBTTtBQUNwQyxTQUFTLE9BQU8sVUFBVTtJQUN4QixVQUFVLElBQUksQ0FBQyxJQUFJLEVBQUU7SUFDckIsSUFBSSxDQUFDLEdBQUcsR0FBRztRQUNULE1BQU0sT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVc7UUFDdkMsa0JBQWtCLEVBQUU7UUFDcEIsbUJBQW1CLEVBQUU7UUFDckIsUUFBUSxTQUFVLEVBQUU7WUFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLFlBQWE7UUFDaEQ7UUFDQSxTQUFTLFNBQVUsRUFBRTtZQUNuQixJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDO1FBQzlCO0lBQ0Y7SUFDQSxPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsV0FBVyxHQUFHO0FBQ3RDO0FBQ0EsT0FBTyxNQUFNLENBQUMsTUFBTSxHQUFHO0FBQ3ZCLE9BQU8sTUFBTSxDQUFDLE9BQU8sR0FBRyxDQUFDO0FBQ3pCLElBQUksY0FBYywwQkFBMEIsS0FBSSxnQkFBZ0IsbUNBQW1DLEtBQUksZUFBZSxtQ0FBbUM7QUFFekosU0FBUztJQUNQLE9BQU8sWUFBYSxDQUFBLFNBQVMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksU0FBUyxRQUFRLEdBQUcsV0FBVTtBQUM5RjtBQUNBLFNBQVM7SUFDUCxPQUFPLFlBQVksU0FBUyxJQUFJO0FBQ2xDO0FBRUEsd0NBQXdDO0FBQ3hDLElBQUksU0FBUyxPQUFPLE1BQU0sQ0FBQyxNQUFNO0FBQ2pDLElBQUksQUFBQyxDQUFBLENBQUMsVUFBVSxDQUFDLE9BQU8sZUFBZSxBQUFELEtBQU0sT0FBTyxjQUFjLGFBQWE7SUFDNUUsSUFBSSxXQUFXO0lBQ2YsSUFBSSxPQUFPO0lBQ1gsSUFBSSxXQUFXLGNBQWMsU0FBUyxRQUFRLElBQUksWUFBWSxDQUFDO1FBQUM7UUFBYTtRQUFhO0tBQVUsQ0FBQyxRQUFRLENBQUMsWUFBWSxRQUFRO0lBQ2xJLElBQUk7SUFDSixJQUFJLGFBQ0YsS0FBSyxJQUFJLFlBQVk7U0FFckIsSUFBSTtRQUNGLEtBQUssSUFBSSxVQUFVLFdBQVcsUUFBUSxXQUFZLENBQUEsT0FBTyxNQUFNLE9BQU8sRUFBQyxJQUFLO0lBQzlFLEVBQUUsT0FBTyxLQUFLO1FBQ1osSUFBSSxJQUFJLE9BQU8sRUFDYixRQUFRLEtBQUssQ0FBQyxJQUFJLE9BQU87UUFFM0IsS0FBSyxDQUFDO0lBQ1I7SUFHRix3QkFBd0I7SUFDeEIsSUFBSSxTQUFTLE9BQU8sWUFBWSxjQUFjLE9BQU8sV0FBVyxjQUFjLE9BQU8sU0FBUztJQUU5RixvREFBb0Q7SUFDcEQsMERBQTBEO0lBQzFELElBQUksb0JBQW9CO0lBQ3hCLElBQUk7UUFDRCxDQUFBLEdBQUcsSUFBRyxFQUFHO0lBQ1osRUFBRSxPQUFPLEtBQUs7UUFDWixvQkFBb0IsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDO0lBQ3pDO0lBRUEsYUFBYTtJQUNiLEdBQUcsU0FBUyxHQUFHLGVBQWdCLE1BQU0sd0JBQXdCLEdBQXpCO1FBQ2xDLGdCQUFnQixDQUFDLEVBQUUsMEJBQTBCO1FBQzdDLGlCQUFpQixFQUFFO1FBQ25CLGtCQUFrQixFQUFFO1FBQ3BCLElBQUksS0FBSyxlQUFlLE1BQUssS0FBSyxLQUFLLENBQUMsTUFBTSxJQUFJO1FBQ2xELElBQUksS0FBSyxJQUFJLEtBQUssVUFBVTtZQUMxQix1Q0FBdUM7WUFDdkMsSUFBSSxPQUFPLGFBQWEsYUFDdEI7WUFFRixJQUFJLFNBQVMsS0FBSyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUEsUUFBUyxNQUFNLE9BQU8sS0FBSztZQUUzRCxvQkFBb0I7WUFDcEIsSUFBSSxVQUFVLE9BQU8sS0FBSyxDQUFDLENBQUE7Z0JBQ3pCLE9BQU8sTUFBTSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksS0FBSyxRQUFRLGVBQWUsT0FBTyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLE1BQU0sWUFBWTtZQUN2SDtZQUNBLElBQUksU0FBUztnQkFDWCxRQUFRLEtBQUs7Z0JBRWIseUVBQXlFO2dCQUN6RSxJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sZ0JBQWdCLGFBQzFELE9BQU8sYUFBYSxDQUFDLElBQUksWUFBWTtnQkFFdkMsTUFBTSxnQkFBZ0I7Z0JBRXRCLDBCQUEwQjtnQkFDMUIsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLDBCQUEwQjtnQkFDbkQsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLGdCQUFnQixNQUFNLEVBQUUsSUFBSztvQkFDL0MsSUFBSSxLQUFLLGVBQWUsQ0FBQyxFQUFFLENBQUMsRUFBRTtvQkFDOUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEVBQUU7d0JBQ3hCLFdBQVcsZUFBZSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7d0JBQ2xDLGVBQWUsQ0FBQyxHQUFHLEdBQUc7b0JBQ3hCO2dCQUNGO2dCQUVBLDhGQUE4RjtnQkFDOUYsa0JBQWtCLENBQUM7Z0JBQ25CLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLE1BQU0sRUFBRSxJQUFLO29CQUM5QyxJQUFJLEtBQUssY0FBYyxDQUFDLEVBQUUsQ0FBQyxFQUFFO29CQUM3QixJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsRUFBRTt3QkFDeEIsVUFBVSxjQUFjLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDaEMsZUFBZSxDQUFDLEdBQUcsR0FBRztvQkFDeEI7Z0JBQ0Y7WUFDRixPQUFPO1FBQ1Q7UUFDQSxJQUFJLEtBQUssSUFBSSxLQUFLLFNBQVM7WUFDekIsK0JBQStCO1lBQy9CLEtBQUssSUFBSSxrQkFBa0IsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFFO2dCQUNoRCxJQUFJLFFBQVEsZUFBZSxTQUFTLEdBQUcsZUFBZSxTQUFTLEdBQUcsZUFBZSxLQUFLO2dCQUN0RixRQUFRLEtBQUssQ0FBQyw0QkFBa0IsZUFBZSxPQUFPLEdBQUcsT0FBTyxRQUFRLFNBQVMsZUFBZSxLQUFLLENBQUMsSUFBSSxDQUFDO1lBQzdHO1lBQ0EsSUFBSSxPQUFPLGFBQWEsYUFBYTtnQkFDbkMsZ0NBQWdDO2dCQUNoQztnQkFDQSxJQUFJLFVBQVUsbUJBQW1CLEtBQUssV0FBVyxDQUFDLElBQUk7Z0JBQ3RELGFBQWE7Z0JBQ2IsU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBQzVCO1FBQ0Y7SUFDRjtJQUNBLElBQUksY0FBYyxXQUFXO1FBQzNCLEdBQUcsT0FBTyxHQUFHLFNBQVUsQ0FBQztZQUN0QixJQUFJLEVBQUUsT0FBTyxFQUNYLFFBQVEsS0FBSyxDQUFDLEVBQUUsT0FBTztRQUUzQjtRQUNBLEdBQUcsT0FBTyxHQUFHO1lBQ1gsUUFBUSxJQUFJLENBQUM7UUFDZjtJQUNGO0FBQ0Y7QUFDQSxTQUFTO0lBQ1AsSUFBSSxVQUFVLFNBQVMsY0FBYyxDQUFDO0lBQ3RDLElBQUksU0FBUztRQUNYLFFBQVEsTUFBTTtRQUNkLFFBQVEsR0FBRyxDQUFDO0lBQ2Q7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLFdBQVc7SUFDckMsSUFBSSxVQUFVLFNBQVMsYUFBYSxDQUFDO0lBQ3JDLFFBQVEsRUFBRSxHQUFHO0lBQ2IsSUFBSSxZQUFZO0lBQ2hCLEtBQUssSUFBSSxjQUFjLFlBQWE7UUFDbEMsSUFBSSxRQUFRLFdBQVcsTUFBTSxDQUFDLE1BQU0sR0FBRyxXQUFXLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHO1lBQ2xFLE9BQU8sQ0FBQyxFQUFFLEVBQUU7c0NBQ29CLEVBQUUsbUJBQW1CLE1BQU0sUUFBUSxFQUFFLDJGQUEyRixFQUFFLE1BQU0sUUFBUSxDQUFDO0FBQ3ZMLEVBQUUsTUFBTSxJQUFJLENBQUMsQ0FBQztRQUNWLEdBQUcsTUFBTSxXQUFXLEtBQUs7UUFDekIsYUFBYSxDQUFDOzs7b0JBR0wsRUFBRSxXQUFXLE9BQU8sQ0FBQzs7YUFFckIsRUFBRSxNQUFNOztVQUVYLEVBQUUsV0FBVyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUEsT0FBUSx1QkFBYSxPQUFPLFVBQVUsSUFBSSxDQUFDLElBQUk7O1FBRXhFLEVBQUUsV0FBVyxhQUFhLEdBQUcsQ0FBQyw4Q0FBdUMsRUFBRSxXQUFXLGFBQWEsQ0FBQyxzQ0FBc0MsQ0FBQyxHQUFHLEdBQUc7O0lBRWpKLENBQUM7SUFDSDtJQUNBLGFBQWE7SUFDYixRQUFRLFNBQVMsR0FBRztJQUNwQixPQUFPO0FBQ1Q7QUFDQSxTQUFTO0lBQ1AsSUFBSSxZQUFZLFVBQ2QsU0FBUyxNQUFNO1NBQ1YsSUFBSSxVQUFVLE9BQU8sT0FBTyxJQUFJLE9BQU8sT0FBTyxDQUFDLE1BQU0sRUFDMUQsT0FBTyxPQUFPLENBQUMsTUFBTTtBQUV6QjtBQUNBLFNBQVMsV0FBVyxNQUFNLEVBQUUsRUFBRSxFQUFFLG1DQUFtQztJQUNqRSxJQUFJLFVBQVUsT0FBTyxPQUFPO0lBQzVCLElBQUksQ0FBQyxTQUNILE9BQU8sRUFBRTtJQUVYLElBQUksVUFBVSxFQUFFO0lBQ2hCLElBQUksR0FBRyxHQUFHO0lBQ1YsSUFBSyxLQUFLLFFBQ1IsSUFBSyxLQUFLLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFFO1FBQ3ZCLE1BQU0sT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtRQUN0QixJQUFJLFFBQVEsTUFBTSxNQUFNLE9BQU8sQ0FBQyxRQUFRLEdBQUcsQ0FBQyxJQUFJLE1BQU0sR0FBRyxFQUFFLEtBQUssSUFDOUQsUUFBUSxJQUFJLENBQUM7WUFBQztZQUFRO1NBQUU7SUFFNUI7SUFFRixJQUFJLE9BQU8sTUFBTSxFQUNmLFVBQVUsUUFBUSxNQUFNLENBQUMsV0FBVyxPQUFPLE1BQU0sRUFBRTtJQUVyRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsSUFBSTtJQUN0QixJQUFJLE9BQU8sS0FBSyxZQUFZLENBQUM7SUFDN0IsSUFBSSxDQUFDLE1BQ0g7SUFFRixJQUFJLFVBQVUsS0FBSyxTQUFTO0lBQzVCLFFBQVEsTUFBTSxHQUFHO1FBQ2YsSUFBSSxLQUFLLFVBQVUsS0FBSyxNQUN0QixhQUFhO1FBQ2IsS0FBSyxVQUFVLENBQUMsV0FBVyxDQUFDO0lBRWhDO0lBQ0EsUUFBUSxZQUFZLENBQUMsUUFDckIsYUFBYTtJQUNiLEtBQUssS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsTUFBTSxLQUFLLEdBQUc7SUFDbkMsYUFBYTtJQUNiLEtBQUssVUFBVSxDQUFDLFlBQVksQ0FBQyxTQUFTLEtBQUssV0FBVztBQUN4RDtBQUNBLElBQUksYUFBYTtBQUNqQixTQUFTO0lBQ1AsSUFBSSxZQUNGO0lBRUYsYUFBYSxXQUFXO1FBQ3RCLElBQUksUUFBUSxTQUFTLGdCQUFnQixDQUFDO1FBQ3RDLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLE1BQU0sRUFBRSxJQUFLO1lBQ3JDLGdDQUFnQztZQUNoQyxJQUFJLEtBQUssV0FBVyxNQUFLLEtBQUssQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDO1lBQy9DLElBQUksV0FBVztZQUNmLElBQUksc0JBQXNCLGFBQWEsY0FBYyxJQUFJLE9BQU8sbURBQW1ELFdBQVcsSUFBSSxDQUFDLFFBQVEsS0FBSyxPQUFPLENBQUMsV0FBVyxNQUFNO1lBQ3pLLElBQUksV0FBVyxnQkFBZ0IsSUFBSSxDQUFDLFNBQVMsS0FBSyxPQUFPLENBQUMsU0FBUyxNQUFNLE1BQU0sS0FBSyxDQUFDO1lBQ3JGLElBQUksQ0FBQyxVQUNILFdBQVcsS0FBSyxDQUFDLEVBQUU7UUFFdkI7UUFDQSxhQUFhO0lBQ2YsR0FBRztBQUNMO0FBQ0EsU0FBUyxZQUFZLEtBQUs7SUFDeEIsSUFBSSxNQUFNLElBQUksS0FBSyxNQUFNO1FBQ3ZCLElBQUksT0FBTyxhQUFhLGFBQWE7WUFDbkMsSUFBSSxTQUFTLFNBQVMsYUFBYSxDQUFDO1lBQ3BDLE9BQU8sR0FBRyxHQUFHLE1BQU0sR0FBRyxHQUFHLFFBQVEsS0FBSyxHQUFHO1lBQ3pDLElBQUksTUFBTSxZQUFZLEtBQUssWUFDekIsT0FBTyxJQUFJLEdBQUc7WUFFaEIsT0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTO2dCQUMzQixJQUFJO2dCQUNKLE9BQU8sTUFBTSxHQUFHLElBQU0sUUFBUTtnQkFDOUIsT0FBTyxPQUFPLEdBQUc7Z0JBQ2hCLENBQUEsaUJBQWlCLFNBQVMsSUFBSSxBQUFELE1BQU8sUUFBUSxtQkFBbUIsS0FBSyxLQUFLLGVBQWUsV0FBVyxDQUFDO1lBQ3ZHO1FBQ0YsT0FBTyxJQUFJLE9BQU8sa0JBQWtCLFlBQVk7WUFDOUMsaUJBQWlCO1lBQ2pCLElBQUksTUFBTSxZQUFZLEtBQUssWUFDekIsT0FBTyxPQUFtQixNQUFNLEdBQUcsR0FBRyxRQUFRLEtBQUssR0FBRztpQkFFdEQsT0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTO2dCQUMzQixJQUFJO29CQUNGLGNBQTBCLE1BQU0sR0FBRyxHQUFHLFFBQVEsS0FBSyxHQUFHO29CQUN0RDtnQkFDRixFQUFFLE9BQU8sS0FBSztvQkFDWixPQUFPO2dCQUNUO1lBQ0Y7UUFFSjtJQUNGO0FBQ0Y7QUFDQSxlQUFlLGdCQUFnQixNQUFNO0lBQ25DLE9BQU8sZUFBZSxHQUFHLE9BQU8sTUFBTSxDQUFDO0lBQ3ZDLElBQUk7SUFDSixJQUFJO1FBQ0Ysa0VBQWtFO1FBQ2xFLGdFQUFnRTtRQUNoRSxnRUFBZ0U7UUFDaEUsbURBQW1EO1FBQ25ELGlEQUFpRDtRQUNqRCxtREFBbUQ7UUFDbkQsSUFBSSxDQUFDLG1CQUFtQjtZQUN0QixJQUFJLFdBQVcsT0FBTyxHQUFHLENBQUMsQ0FBQTtnQkFDeEIsSUFBSTtnQkFDSixPQUFPLEFBQUMsQ0FBQSxlQUFlLFlBQVksTUFBSyxNQUFPLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxLQUFLLElBQUksYUFBYSxLQUFLLENBQUMsQ0FBQTtvQkFDM0csb0JBQW9CO29CQUNwQixJQUFJLFVBQVUsT0FBTyxPQUFPLElBQUksT0FBTyxPQUFPLENBQUMsV0FBVyxHQUFHLGdCQUFnQixJQUFJLEtBQUssT0FBTyw0QkFBNEIsZUFBZSxrQkFBa0IsMEJBQTBCO3dCQUNsTCxPQUFPLE9BQU8sQ0FBQyxNQUFNO3dCQUNyQjtvQkFDRjtvQkFDQSxNQUFNO2dCQUNSO1lBQ0Y7WUFDQSxrQkFBa0IsTUFBTSxRQUFRLEdBQUcsQ0FBQztRQUN0QztRQUNBLE9BQU8sT0FBTyxDQUFDLFNBQVUsS0FBSztZQUM1QixTQUFTLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRTtRQUMvQjtJQUNGLFNBQVU7UUFDUixPQUFPLE9BQU8sZUFBZTtRQUM3QixJQUFJLGlCQUNGLGdCQUFnQixPQUFPLENBQUMsQ0FBQTtZQUN0QixJQUFJLFFBQVE7Z0JBQ1YsSUFBSTtnQkFDSCxDQUFBLGtCQUFrQixTQUFTLElBQUksQUFBRCxNQUFPLFFBQVEsb0JBQW9CLEtBQUssS0FBSyxnQkFBZ0IsV0FBVyxDQUFDO1lBQzFHO1FBQ0Y7SUFFSjtBQUNGO0FBQ0EsU0FBUyxTQUFTLE9BQU8sa0JBQWtCLEdBQW5CLEVBQXVCLE1BQU0sY0FBYyxHQUFmO0lBQ2xELElBQUksVUFBVSxPQUFPLE9BQU87SUFDNUIsSUFBSSxDQUFDLFNBQ0g7SUFFRixJQUFJLE1BQU0sSUFBSSxLQUFLLE9BQ2pCO1NBQ0ssSUFBSSxNQUFNLElBQUksS0FBSyxNQUFNO1FBQzlCLElBQUksT0FBTyxNQUFNLFlBQVksQ0FBQyxPQUFPLGFBQWEsQ0FBQztRQUNuRCxJQUFJLE1BQU07WUFDUixJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFO2dCQUNyQixpRUFBaUU7Z0JBQ2pFLG9IQUFvSDtnQkFDcEgsSUFBSSxVQUFVLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ2xDLElBQUssSUFBSSxPQUFPLFFBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUM1QyxJQUFJLEtBQUssT0FBTyxDQUFDLElBQUk7b0JBQ3JCLElBQUksVUFBVSxXQUFXLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRTtvQkFDN0MsSUFBSSxRQUFRLE1BQU0sS0FBSyxHQUNyQixVQUFVLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRTtnQkFFbEM7WUFFSjtZQUNBLElBQUksbUJBR0YsQUFGQSw0REFBNEQ7WUFDNUQsK0NBQStDO1lBQzlDLENBQUEsR0FBRyxJQUFHLEVBQUcsTUFBTSxNQUFNO1lBR3hCLGFBQWE7WUFDYixJQUFJLEtBQUssT0FBTyxlQUFlLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDekMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEdBQUc7Z0JBQUM7Z0JBQUk7YUFBSztRQUNoQyxPQUFPLElBQUksT0FBTyxNQUFNLEVBQ3RCLFNBQVMsT0FBTyxNQUFNLEVBQUU7SUFFNUI7QUFDRjtBQUNBLFNBQVMsVUFBVSxNQUFNLEVBQUUsRUFBRTtJQUMzQixJQUFJLFVBQVUsT0FBTyxPQUFPO0lBQzVCLElBQUksQ0FBQyxTQUNIO0lBRUYsSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFO1FBQ2YsOEVBQThFO1FBQzlFLElBQUksT0FBTyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDekIsSUFBSSxVQUFVLEVBQUU7UUFDaEIsSUFBSyxJQUFJLE9BQU8sS0FBTTtZQUNwQixJQUFJLFVBQVUsV0FBVyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDdEQsSUFBSSxRQUFRLE1BQU0sS0FBSyxHQUNyQixRQUFRLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSTtRQUUxQjtRQUVBLHNHQUFzRztRQUN0RyxPQUFPLE9BQU8sQ0FBQyxHQUFHO1FBQ2xCLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FBRztRQUV2QiwwQkFBMEI7UUFDMUIsUUFBUSxPQUFPLENBQUMsQ0FBQTtZQUNkLFVBQVUsT0FBTyxNQUFNLENBQUMsSUFBSSxFQUFFO1FBQ2hDO0lBQ0YsT0FBTyxJQUFJLE9BQU8sTUFBTSxFQUN0QixVQUFVLE9BQU8sTUFBTSxFQUFFO0FBRTdCO0FBQ0EsU0FBUyxlQUFlLE9BQU8sa0JBQWtCLEdBQW5CLEVBQXVCLEdBQUcsV0FBVyxHQUFaLEVBQWdCLGFBQWEsdUNBQXVDLEdBQXhDO0lBQ2pGLElBQUksa0JBQWtCLFFBQVEsSUFBSSxlQUNoQyxPQUFPO0lBR1QsdUdBQXVHO0lBQ3ZHLElBQUksVUFBVSxXQUFXLE9BQU8sTUFBTSxDQUFDLElBQUksRUFBRTtJQUM3QyxJQUFJLFdBQVc7SUFDZixNQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUc7UUFDekIsSUFBSSxJQUFJLFFBQVEsS0FBSztRQUNyQixJQUFJLElBQUksa0JBQWtCLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtRQUN0QyxJQUFJLEdBQ0YsK0VBQStFO1FBQy9FLFdBQVc7YUFDTjtZQUNMLHlEQUF5RDtZQUN6RCxJQUFJLElBQUksV0FBVyxPQUFPLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUU7WUFDM0MsSUFBSSxFQUFFLE1BQU0sS0FBSyxHQUFHO2dCQUNsQixrRkFBa0Y7Z0JBQ2xGLFdBQVc7Z0JBQ1g7WUFDRjtZQUNBLFFBQVEsSUFBSSxJQUFJO1FBQ2xCO0lBQ0Y7SUFDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWixFQUFnQixhQUFhLHVDQUF1QyxHQUF4QztJQUNwRixJQUFJLFVBQVUsT0FBTyxPQUFPO0lBQzVCLElBQUksQ0FBQyxTQUNIO0lBRUYsSUFBSSxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsT0FBTyxhQUFhLENBQUMsRUFBRTtRQUN2RCwyRUFBMkU7UUFDM0UseUVBQXlFO1FBQ3pFLElBQUksQ0FBQyxPQUFPLE1BQU0sRUFDaEIsT0FBTztRQUVULE9BQU8sZUFBZSxPQUFPLE1BQU0sRUFBRSxJQUFJO0lBQzNDO0lBQ0EsSUFBSSxhQUFhLENBQUMsR0FBRyxFQUNuQixPQUFPO0lBRVQsYUFBYSxDQUFDLEdBQUcsR0FBRztJQUNwQixJQUFJLFNBQVMsT0FBTyxLQUFLLENBQUMsR0FBRztJQUM3QixnQkFBZ0IsSUFBSSxDQUFDO1FBQUM7UUFBUTtLQUFHO0lBQ2pDLElBQUksQ0FBQyxVQUFVLE9BQU8sR0FBRyxJQUFJLE9BQU8sR0FBRyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRTtRQUMvRCxlQUFlLElBQUksQ0FBQztZQUFDO1lBQVE7U0FBRztRQUNoQyxPQUFPO0lBQ1Q7QUFDRjtBQUNBLFNBQVMsV0FBVyxPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWjtJQUNqRCxJQUFJLFNBQVMsT0FBTyxLQUFLLENBQUMsR0FBRztJQUM3QixPQUFPLE9BQU8sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN0QixJQUFJLFVBQVUsT0FBTyxHQUFHLEVBQ3RCLE9BQU8sR0FBRyxDQUFDLElBQUksR0FBRyxPQUFPLE9BQU8sQ0FBQyxHQUFHO0lBRXRDLElBQUksVUFBVSxPQUFPLEdBQUcsSUFBSSxPQUFPLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQzdELE9BQU8sR0FBRyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxTQUFVLEVBQUU7UUFDL0MsR0FBRyxPQUFPLE9BQU8sQ0FBQyxHQUFHO0lBQ3ZCO0lBRUYsT0FBTyxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ3pCO0FBQ0EsU0FBUyxVQUFVLE9BQU8sa0JBQWtCLEdBQW5CLEVBQXVCLEdBQUcsV0FBVyxHQUFaO0lBQ2hELHNCQUFzQjtJQUN0QixPQUFPO0lBRVAsNkRBQTZEO0lBQzdELElBQUksU0FBUyxPQUFPLEtBQUssQ0FBQyxHQUFHO0lBQzdCLElBQUksVUFBVSxPQUFPLEdBQUcsSUFBSSxPQUFPLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQzVELE9BQU8sR0FBRyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFVLEVBQUU7UUFDOUMsSUFBSSxxQkFBcUIsR0FBRztZQUMxQixPQUFPLFdBQVcsT0FBTyxNQUFNLENBQUMsSUFBSSxFQUFFO1FBQ3hDO1FBQ0EsSUFBSSxzQkFBc0IsZUFBZSxNQUFNLEVBQUU7WUFDL0MsbUJBQW1CLE9BQU8sQ0FBQyxTQUFVLENBQUM7Z0JBQ3BDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRTtZQUN2QjtZQUVBLCtCQUErQjtZQUMvQixlQUFlLElBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCO1FBQzVDO0lBQ0Y7QUFFSjs7O0FDdmZBO0FBQ0EsNkJBQTZCO0FBQzdCOzs7QUNGQSxtQ0FBbUM7O0FBQ25DOztBQUVBO0FBQ0E7QUFFQSxzRUFBc0U7QUFDdEU7QUFDQSw0QkFBNEI7QUFFNUIsNkJBQTZCO0FBRTdCLG1CQUFtQjtBQUNuQixJQUFJLGlCQUFpQjtBQUNyQixJQUFJO0FBQ0osSUFBSTtBQUNKLElBQUk7QUFDSixJQUFJO0FBRUosSUFBSSxVQUFVLGlCQUFpQjs7QUFDL0IsSUFBSTtBQUNKLDZCQUE2QjtBQUM3QixJQUFJLGVBQWUsS0FBSyxvQ0FBb0M7O0FBRTVELElBQUksb0JBQW9CO0FBQ3hCLElBQUksbUJBQW1CO0FBQ3ZCLGdDQUFnQztBQUVoQyxNQUFNLGtCQUFrQixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0J6QixDQUFDO0FBRUQsaUJBQWlCO0FBQ2pCO0FBRUEsU0FBUztJQUNSLE1BQU0sT0FBTyxTQUFTLGdCQUFnQixDQUFDO0lBQ3ZDLE1BQU0sUUFBUSxTQUFTLGdCQUFnQixDQUFDO0lBRXhDLEtBQUssT0FBTyxDQUFDLENBQUMsS0FBSztRQUNsQixJQUFJLGdCQUFnQixDQUFDLFNBQVM7WUFDN0IsU0FBUyxhQUFhLENBQUMsc0JBQXNCLFNBQVMsQ0FBQyxNQUFNLENBQUM7WUFDOUQsU0FBUyxhQUFhLENBQUMsMEJBQTBCLFNBQVMsQ0FBQyxHQUFHLENBQUM7WUFFL0QsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDO1lBQ2xCLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQjtJQUNEO0FBQ0Q7QUFFQSxlQUFlO0lBQ2QsSUFBSTtRQUNILE1BQU0sRUFBRSxTQUFTLFdBQVcsRUFBRSxHQUFHLE1BQU0sQ0FBQSxHQUFBLG9DQUFPLEFBQUQsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNoRSxNQUFNLFFBQVEsZUFBZ0IsQ0FBQSxPQUFPLFVBQVUsQ0FBQyxpQ0FBaUMsT0FBTyxHQUFHLFVBQVUsTUFBSztRQUMxRyxXQUFXO0lBQ1osRUFBRSxPQUFPLE9BQU87UUFDZixRQUFRLEtBQUssQ0FBQyw2QkFBNkI7SUFDNUM7QUFDRDtBQUVBLGVBQWUsU0FBUyxLQUFLO0lBQzVCLElBQUk7UUFDSCxNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFBRSxTQUFTO1FBQU07UUFDaEQsV0FBVztRQUNYO0lBQ0QsRUFBRSxPQUFPLE9BQU87UUFDZixRQUFRLEtBQUssQ0FBQyx3QkFBd0I7SUFDdkM7QUFDRDtBQUVBLFNBQVM7SUFDUixNQUFNLGtCQUFrQixTQUFTLGFBQWEsQ0FBQztJQUMvQyxnQkFBZ0IsU0FBUyxHQUFHO0lBRTVCLGtEQUFrRDtJQUNsRCxJQUFJLFdBQVcsQ0FBQzs7R0FFZCxFQUFFLENBQUEsR0FBQSxtQkFBVSxBQUFELEVBQUU7Ozs7OytDQUsrQixFQUFFLENBQUEsR0FBQSxpQkFBUSxBQUFELEVBQUU7NkNBQ2IsRUFBRSxDQUFBLEdBQUEsa0JBQVMsQUFBRCxFQUFFOzhDQUNYLEVBQUUsQ0FBQSxHQUFBLHVCQUFjLEFBQUQsRUFBRTsyREFDSixFQUFFLENBQUEsR0FBQSxzQkFBYSxBQUFELEVBQUU7OztDQUcxRSxDQUFDO0lBRUQsdUNBQXVDO0lBQ3ZDLGdCQUFnQixrQkFBa0IsQ0FBQyxhQUFhO0lBQ2hELFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUUxQixxQ0FBcUM7SUFDckMsV0FBVyxTQUFTLGVBQWU7SUFDbkMsZUFBZSxTQUFTLGFBQWEsQ0FBQztJQUN0QyxtQkFBbUIsU0FBUyxhQUFhLENBQUM7SUFDMUMseUJBQXlCLFNBQVMsYUFBYSxDQUFDO0lBRWhELHNEQUFzRDtJQUN0RCxhQUFhLGdCQUFnQixDQUFDLFNBQVM7SUFDdkMsdUJBQXVCLGdCQUFnQixDQUFDLFNBQVM7QUFDbEQ7QUFFQSxTQUFTLGtCQUFrQixDQUFDO0lBQzNCLE1BQU0sY0FBYyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7SUFDckMsSUFBSSxDQUFDLGFBQWE7SUFFbEIsTUFBTSxRQUFRLFlBQVksRUFBRTtJQUU1QixJQUFJLFVBQVUsc0JBQXNCO1FBQ25DLFNBQVM7UUFDVDtJQUNEO0lBRUEsb0NBQW9DLEdBQ3BDLElBQUksVUFBVSxzQkFDYjtBQUdGO0FBRUEsU0FBUyxXQUFXLEtBQUs7SUFDeEIsU0FBUyxPQUFPLENBQUMsT0FBTyxHQUFHO0lBQzNCLFNBQVMsS0FBSyxDQUFDLFdBQVcsR0FBRyxVQUFVLFNBQVMsU0FBUztJQUN6RCxTQUFTLFNBQVMsR0FBRyxVQUFVLFNBQVMsU0FBUztJQUNqRCxJQUFJLFVBQVUsUUFBUSxTQUFTLGVBQWUsQ0FBQztBQUNoRDtBQUVBLFNBQVM7SUFDUixpQkFBaUIsQ0FBQztJQUNsQixpQkFBaUIsU0FBUyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0I7SUFFMUQsSUFBSSxnQkFBZ0IsU0FBUyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUztTQUN2RCxTQUFTLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTO0FBQ2pEO0FBRUEsU0FBUyxZQUFZLENBQUM7SUFDckIsTUFBTSwyQkFBMkIsYUFBYSxRQUFRLENBQUMsRUFBRSxNQUFNO0lBQy9ELE1BQU0sK0JBQStCLGlCQUFpQixRQUFRLENBQUMsRUFBRSxNQUFNO0lBRXZFLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyw4QkFBOEI7QUFFaEUscUdBQXFHO0FBQ3RHO0FBRUEsU0FBUztJQUNSLFdBQVc7UUFDVixhQUFhLFNBQVMsQ0FBQyxHQUFHLENBQUM7SUFDNUIsR0FBRztBQUNKO0FBRUEsb0VBQW9FLEdBQ3BFLFNBQVM7SUFDUixNQUFNLGVBQWUsU0FBUyxhQUFhLENBQUM7SUFDNUMsYUFBYSxTQUFTLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQztJQUU1RCxJQUFJLFdBQVcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztNQXlCWCxFQUFFLGdCQUFnQjs7OztNQUlsQixFQUFFLENBQUEsR0FBQSx1QkFBWSxBQUFELEVBQUU7Ozs7Ozs7Ozs7Q0FVcEIsQ0FBQztJQUVELGFBQWEsa0JBQWtCLENBQUMsYUFBYTtJQUM3QyxTQUFTLElBQUksQ0FBQyxXQUFXLENBQUM7SUFFMUIsU0FBUyxjQUFjLENBQUMsdUJBQXVCLGdCQUFnQixDQUFDLFNBQVM7SUFFekUsWUFBWTtJQUVaO0lBRUEsZUFBZSxVQUFVLGFBQWEsQ0FBQztJQUN2QyxhQUFhLFFBQVEsR0FBRztJQUV4QixVQUFVLGFBQWEsQ0FBQyxxQkFBcUIsZ0JBQWdCLENBQUMsU0FBUztJQUV2RSwwQkFBMEI7SUFDMUIsQ0FBQSxHQUFBLCtCQUFvQixBQUFEO0FBQ3BCO0FBRUEsU0FBUztJQUNSLFVBQVUsU0FBUyxDQUFDLEdBQUcsQ0FBQztJQUN4QixVQUFVLGdCQUFnQixDQUFDLGlCQUFpQjtJQUM1QyxhQUFhLFFBQVEsR0FBRztBQUV4Qix5QkFBeUI7QUFDekIsa0JBQWtCO0FBQ25CO0FBQ0EsU0FBUztJQUNSLFNBQVMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVM7SUFDeEMsVUFBVSxtQkFBbUIsQ0FBQyxpQkFBaUI7QUFDaEQ7QUFDQSxTQUFTO0lBQ1IsVUFBVSxTQUFTLENBQUMsTUFBTSxDQUFDO0lBQzNCLFNBQVMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVM7SUFDM0MsYUFBYSxRQUFRLEdBQUc7QUFDekI7QUFDQSxTQUFTLDJCQUEyQixDQUFDO0lBQ3BDLElBQUksdUJBQXVCLEVBQUUsTUFBTSxDQUFDLEVBQUUsS0FBSztJQUUzQyxJQUFJLENBQUMsVUFBVSxRQUFRLENBQUMsRUFBRSxNQUFNLEtBQUssQ0FBQyxzQkFBc0I7QUFDN0Q7QUFFQSxTQUFTO0lBQ1IsVUFBVSxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7UUFDcEMsd0JBQXdCO1FBRXhCLElBQUksRUFBRSxNQUFNLENBQUMsRUFBRSxLQUFLLGVBQWU7WUFDbEMsRUFBRSxNQUFNLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDO2dCQUNuQyxjQUFjLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRTtZQUMvQjtZQUNBLHFDQUFxQztZQUNyQyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUM7Z0JBQ3BDLG1CQUFtQixnQkFBZ0IsRUFBRSxNQUFNLENBQUMsS0FBSztnQkFDakQ7WUFDRDtRQUNEO1FBRUEsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFLEtBQUssY0FBYztZQUNqQyxFQUFFLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7Z0JBQ25DLGNBQWMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25DO1lBQ0Esb0NBQW9DO1lBQ3BDLEVBQUUsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQztnQkFDcEMsbUJBQW1CLGVBQWUsRUFBRSxNQUFNLENBQUMsS0FBSztnQkFDaEQ7WUFDRDtRQUNEO0lBQ0Q7QUFDRDtBQUNBLG9EQUFvRDtBQUNwRCxTQUFTO0lBQ1IsZUFBZSxTQUFTLGFBQWEsQ0FBQztJQUN0QyxhQUFhLElBQUksR0FBRztJQUNwQixTQUFTLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDM0I7QUFFQSxTQUFTLGNBQWMsVUFBVSxFQUFFLFNBQVM7SUFDM0MsSUFBSSxDQUFDLGNBQWM7SUFFbkIsTUFBTSxXQUFXLGFBQ2QsQ0FBQSxHQUFBLGtCQUFRLEFBQUQsRUFBRSxjQUNULENBQUEsR0FBQSxrQkFBUSxBQUFELEVBQUUsVUFBVSxhQUFhLENBQUMsNkJBQTZCLEtBQUs7SUFDdEUsTUFBTSxVQUFVLFlBQ2IsQ0FBQSxHQUFBLGtCQUFRLEFBQUQsRUFBRSxhQUNULENBQUEsR0FBQSxrQkFBUSxBQUFELEVBQUUsVUFBVSxhQUFhLENBQUMsNEJBQTRCLEtBQUs7SUFFckUsSUFBSSxVQUFVO0lBRWQsVUFBVSxDQUFDOzt3QkFFWSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7d0JBQ2QsRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDO3dCQUNkLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQzs7O3dCQUdkLEVBQUUsT0FBTyxDQUFDLEVBQUUsQ0FBQzt3QkFDYixFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUM7d0JBQ2IsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDOztJQUVqQyxDQUFDO0lBRUosdUJBQXVCO0lBRXZCLGFBQWEsV0FBVyxHQUFHO0FBQzVCO0FBRUEsZUFBZSxtQkFBbUIsb0JBQW9CLEVBQUUsV0FBVztJQUNsRSxJQUFJO1FBQ0gsSUFBSSx5QkFBeUIsZ0JBQzVCLE1BQU0sQ0FBQSxHQUFBLG9DQUFPLEFBQUQsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUFFLGNBQWM7UUFBWTtRQUU1RCxJQUFJLHlCQUF5QixlQUM1QixNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFBRSxhQUFhO1FBQVk7SUFFM0QscURBQXFEO0lBQ3RELEVBQUUsT0FBTyxHQUFHO1FBQ1gsUUFBUSxLQUFLLENBQUMsK0NBQStDO0lBQzlEO0FBQ0Q7QUFFQSxTQUFTLG1CQUFtQixFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUU7SUFDdEQsMkNBQTJDO0lBQzNDLFVBQVUsYUFBYSxDQUFDLDZCQUE2QixLQUFLLEdBQUc7SUFDN0QsVUFBVSxhQUFhLENBQUMsNEJBQTRCLEtBQUssR0FBRztBQUM3RDtBQUVBLGVBQWU7SUFDZCxJQUFJO1FBQ0gsaUNBQWlDO1FBQ2pDLE1BQU0sRUFBRSxjQUFjLFdBQVcsRUFBRSxhQUFhLFVBQVUsRUFBRSxHQUFHLE1BQU0sQ0FBQSxHQUFBLG9DQUFPLEFBQUQsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUM3RjtZQUNBO1NBQ0E7UUFDRCxnRkFBZ0Y7UUFFaEYsK0NBQStDO1FBQy9DLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWTtZQUNoQyxNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQzlCLGNBQWM7Z0JBQ2QsYUFBYTtZQUNkO1lBQ0EsUUFBUSxHQUFHLENBQUM7UUFDYjtRQUVBLE1BQU0sbUJBQW1CLGVBQWU7UUFDeEMsTUFBTSxrQkFBa0IsY0FBYztRQUV0QyxxREFBcUQ7UUFDckQsY0FBYyxrQkFBa0I7UUFFaEMsbUJBQW1CO1lBQUUsYUFBYTtZQUFrQixZQUFZO1FBQWdCO0lBRWhGLGtGQUFrRjtJQUNuRixFQUFFLE9BQU8sT0FBTztRQUNmLFFBQVEsS0FBSyxDQUFDLGlDQUFpQztJQUNoRDtBQUNEO0FBQ0EsZUFBZTtJQUNkLElBQUksQ0FBQyxjQUFjO0lBRW5CLGtDQUFrQztJQUNsQyxpQ0FBaUM7SUFDakMsSUFBSSxjQUFjLENBQUEsR0FBQSxrQkFBUSxBQUFELEVBQUU7SUFDM0IsSUFBSSxhQUFhLENBQUEsR0FBQSxrQkFBUSxBQUFELEVBQUU7SUFFMUIsTUFBTSxVQUFVLENBQUM7O3dCQUVNLEVBQUUsV0FBVyxDQUFDLEVBQUUsQ0FBQzt3QkFDakIsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDO3dCQUNqQixFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUM7Ozt3QkFHakIsRUFBRSxVQUFVLENBQUMsRUFBRSxDQUFDO3dCQUNoQixFQUFFLFVBQVUsQ0FBQyxFQUFFLENBQUM7d0JBQ2hCLEVBQUUsVUFBVSxDQUFDLEVBQUUsQ0FBQzs7SUFFcEMsQ0FBQztJQUVKLGFBQWEsV0FBVyxHQUFHO0lBRTNCLG1CQUFtQjtRQUFFLGFBQWE7UUFBbUIsWUFBWTtJQUFpQjtJQUVsRixNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDOUIsY0FBYztRQUNkLGFBQWE7SUFDZDtBQUNEO0FBRUEsc0JBQXNCLEdBQ3RCLFNBQVM7SUFDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7QUFDRCxFQUVBLHdDQUF3QyxJQUN4Qzs7Ozs7OztBQU9BOzs7QSxDLFMsTSxFLE87SSxJLE8sVyxjLE8sRyxFLE8seUI7UTtLLEU7UztZO1EsUTtJO0EsQyxFLE8sZSxjLGEsTyxTLGMsTyxJLEUsUyxPO0lDbGFBLDhEQUFBLEdBQ0EsMkRBQUEsR0FDQSxpQ0FBQSxHQUNBOzs4REFFQSxHQUNBO0lBRUEsSUFBSSxDQUFDQSxXQUFXQyxNQUFYLEVBQW1CQyxTQUFTQyxJQUMvQixNQUFNLElBQUlDLE1BQU07SUFHbEIsSUFBSSxPQUFPSixXQUFXSyxPQUFsQixLQUE4QixlQUFlQyxPQUFPQyxjQUFQLENBQXNCUCxXQUFXSyxPQUFqQyxNQUE4Q0MsT0FBT0UsU0FBdEcsRUFBaUg7UUFDL0csTUFBTUMsbURBQW1ELDJEQUV6RCwyRUFGQTtRQUdBLHdFQUFBO1FBQ0EsNkVBQUE7UUFDQSw0RUFBQTtRQUNBLDhCQUFBO1FBQ0EsTUFBTUMsV0FBV0MsQ0FBQUE7WUFDZiwrRUFBQTtZQUNBLDZFQUFBO1lBQ0EsYUFBQTtZQUNBLE1BQU1DLGNBQWM7Z0JBQ2xCLFVBQVU7b0JBQ1IsU0FBUzt3QkFDUCxXQUFXO3dCQUNYLFdBQVc7b0JBRko7b0JBSVQsWUFBWTt3QkFDVixXQUFXO3dCQUNYLFdBQVc7b0JBRkQ7b0JBSVosT0FBTzt3QkFDTCxXQUFXO3dCQUNYLFdBQVc7b0JBRk47b0JBSVAsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBYkY7Z0JBa0JWLGFBQWE7b0JBQ1gsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsT0FBTzt3QkFDTCxXQUFXO3dCQUNYLFdBQVc7b0JBRk47b0JBSVAsZUFBZTt3QkFDYixXQUFXO3dCQUNYLFdBQVc7b0JBRkU7b0JBSWYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsY0FBYzt3QkFDWixXQUFXO3dCQUNYLFdBQVc7b0JBRkM7b0JBSWQsV0FBVzt3QkFDVCxXQUFXO3dCQUNYLFdBQVc7b0JBRkY7b0JBSVgsUUFBUTt3QkFDTixXQUFXO3dCQUNYLFdBQVc7b0JBRkw7b0JBSVIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsY0FBYzt3QkFDWixXQUFXO3dCQUNYLFdBQVc7b0JBRkM7b0JBSWQsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBekNDO2dCQThDYixpQkFBaUI7b0JBQ2YsV0FBVzt3QkFDVCxXQUFXO3dCQUNYLFdBQVc7d0JBQ1gsd0JBQXdCO29CQUhmO29CQUtYLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHdCQUF3QjtvQkFIaEI7b0JBS1YsMkJBQTJCO3dCQUN6QixXQUFXO3dCQUNYLFdBQVc7b0JBRmM7b0JBSTNCLGdCQUFnQjt3QkFDZCxXQUFXO3dCQUNYLFdBQVc7b0JBRkc7b0JBSWhCLFlBQVk7d0JBQ1YsV0FBVzt3QkFDWCxXQUFXO29CQUZEO29CQUlaLFlBQVk7d0JBQ1YsV0FBVzt3QkFDWCxXQUFXO29CQUZEO29CQUlaLGFBQWE7d0JBQ1gsV0FBVzt3QkFDWCxXQUFXO29CQUZBO29CQUliLDJCQUEyQjt3QkFDekIsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHdCQUF3QjtvQkFIQztvQkFLM0IsZ0JBQWdCO3dCQUNkLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCx3QkFBd0I7b0JBSFY7b0JBS2hCLFdBQVc7d0JBQ1QsV0FBVzt3QkFDWCxXQUFXO29CQUZGO29CQUlYLFlBQVk7d0JBQ1YsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHdCQUF3QjtvQkFIZDtvQkFLWixZQUFZO3dCQUNWLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCx3QkFBd0I7b0JBSGQ7Z0JBbERHO2dCQXdEakIsZ0JBQWdCO29CQUNkLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO29CQUlWLGVBQWU7d0JBQ2IsV0FBVzt3QkFDWCxXQUFXO29CQUZFO29CQUlmLGlCQUFpQjt3QkFDZixXQUFXO3dCQUNYLFdBQVc7b0JBRkk7b0JBSWpCLG1CQUFtQjt3QkFDakIsV0FBVzt3QkFDWCxXQUFXO29CQUZNO29CQUluQixrQkFBa0I7d0JBQ2hCLFdBQVc7d0JBQ1gsV0FBVztvQkFGSztvQkFJbEIsaUJBQWlCO3dCQUNmLFdBQVc7d0JBQ1gsV0FBVztvQkFGSTtvQkFJakIsc0JBQXNCO3dCQUNwQixXQUFXO3dCQUNYLFdBQVc7b0JBRlM7b0JBSXRCLG1CQUFtQjt3QkFDakIsV0FBVzt3QkFDWCxXQUFXO29CQUZNO29CQUluQixvQkFBb0I7d0JBQ2xCLFdBQVc7d0JBQ1gsV0FBVztvQkFGTztvQkFJcEIsWUFBWTt3QkFDVixXQUFXO3dCQUNYLFdBQVc7b0JBRkQ7Z0JBckNFO2dCQTBDaEIsWUFBWTtvQkFDVixVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtnQkFEQTtnQkFNWixnQkFBZ0I7b0JBQ2QsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBVEk7Z0JBY2hCLFdBQVc7b0JBQ1QsT0FBTzt3QkFDTCxXQUFXO3dCQUNYLFdBQVc7b0JBRk47b0JBSVAsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsc0JBQXNCO3dCQUNwQixXQUFXO3dCQUNYLFdBQVc7b0JBRlM7b0JBSXRCLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO29CQUlWLE9BQU87d0JBQ0wsV0FBVzt3QkFDWCxXQUFXO29CQUZOO2dCQWpCRTtnQkFzQlgsWUFBWTtvQkFDVixtQkFBbUI7d0JBQ2pCLFFBQVE7NEJBQ04sV0FBVzs0QkFDWCxXQUFXOzRCQUNYLHFCQUFxQjt3QkFIZjtvQkFEUztvQkFPbkIsVUFBVTt3QkFDUixVQUFVOzRCQUNSLFdBQVc7NEJBQ1gsV0FBVzs0QkFDWCxxQkFBcUI7d0JBSGI7d0JBS1YsWUFBWTs0QkFDVixxQkFBcUI7Z0NBQ25CLFdBQVc7Z0NBQ1gsV0FBVzs0QkFGUTt3QkFEWDtvQkFOSjtnQkFSQTtnQkFzQlosYUFBYTtvQkFDWCxVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtvQkFJVixZQUFZO3dCQUNWLFdBQVc7d0JBQ1gsV0FBVztvQkFGRDtvQkFJWixTQUFTO3dCQUNQLFdBQVc7d0JBQ1gsV0FBVztvQkFGSjtvQkFJVCxlQUFlO3dCQUNiLFdBQVc7d0JBQ1gsV0FBVztvQkFGRTtvQkFJZixRQUFRO3dCQUNOLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCx3QkFBd0I7b0JBSGxCO29CQUtSLFNBQVM7d0JBQ1AsV0FBVzt3QkFDWCxXQUFXO29CQUZKO29CQUlULGNBQWM7d0JBQ1osV0FBVzt3QkFDWCxXQUFXO29CQUZDO29CQUlkLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO29CQUlWLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO29CQUlWLFFBQVE7d0JBQ04sV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHdCQUF3QjtvQkFIbEI7Z0JBdENHO2dCQTRDYixhQUFhO29CQUNYLDZCQUE2Qjt3QkFDM0IsV0FBVzt3QkFDWCxXQUFXO29CQUZnQjtvQkFJN0IsNEJBQTRCO3dCQUMxQixXQUFXO3dCQUNYLFdBQVc7b0JBRmU7Z0JBTGpCO2dCQVViLFdBQVc7b0JBQ1QsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsZUFBZTt3QkFDYixXQUFXO3dCQUNYLFdBQVc7b0JBRkU7b0JBSWYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBckJEO2dCQTBCWCxRQUFRO29CQUNOLGtCQUFrQjt3QkFDaEIsV0FBVzt3QkFDWCxXQUFXO29CQUZLO29CQUlsQixzQkFBc0I7d0JBQ3BCLFdBQVc7d0JBQ1gsV0FBVztvQkFGUztnQkFMaEI7Z0JBVVIsWUFBWTtvQkFDVixxQkFBcUI7d0JBQ25CLFdBQVc7d0JBQ1gsV0FBVztvQkFGUTtnQkFEWDtnQkFNWixRQUFRO29CQUNOLGNBQWM7d0JBQ1osV0FBVzt3QkFDWCxXQUFXO29CQUZDO2dCQURSO2dCQU1SLGNBQWM7b0JBQ1osT0FBTzt3QkFDTCxXQUFXO3dCQUNYLFdBQVc7b0JBRk47b0JBSVAsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsV0FBVzt3QkFDVCxXQUFXO3dCQUNYLFdBQVc7b0JBRkY7b0JBSVgsY0FBYzt3QkFDWixXQUFXO3dCQUNYLFdBQVc7b0JBRkM7b0JBSWQsaUJBQWlCO3dCQUNmLFdBQVc7d0JBQ1gsV0FBVztvQkFGSTtnQkFqQkw7Z0JBc0JkLGlCQUFpQjtvQkFDZixTQUFTO3dCQUNQLFdBQVc7d0JBQ1gsV0FBVztvQkFGSjtvQkFJVCxVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtvQkFJVixVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtvQkFJVixzQkFBc0I7d0JBQ3BCLFdBQVc7d0JBQ1gsV0FBVztvQkFGUztvQkFJdEIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBakJLO2dCQXNCakIsY0FBYztvQkFDWixZQUFZO3dCQUNWLFdBQVc7d0JBQ1gsV0FBVztvQkFGRDtvQkFJWixZQUFZO3dCQUNWLFdBQVc7d0JBQ1gsV0FBVztvQkFGRDtvQkFJWixRQUFRO3dCQUNOLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCx3QkFBd0I7b0JBSGxCO29CQUtSLFdBQVc7d0JBQ1QsV0FBVzt3QkFDWCxXQUFXO29CQUZGO29CQUlYLFlBQVk7d0JBQ1YsV0FBVzt3QkFDWCxXQUFXO3dCQUNYLHdCQUF3QjtvQkFIZDtvQkFLWixZQUFZO3dCQUNWLFdBQVc7d0JBQ1gsV0FBVzt3QkFDWCx3QkFBd0I7b0JBSGQ7b0JBS1osUUFBUTt3QkFDTixXQUFXO3dCQUNYLFdBQVc7d0JBQ1gsd0JBQXdCO29CQUhsQjtnQkE1Qkk7Z0JBa0NkLGVBQWU7b0JBQ2IsWUFBWTt3QkFDVixXQUFXO3dCQUNYLFdBQVc7b0JBRkQ7b0JBSVosVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsV0FBVzt3QkFDVCxXQUFXO3dCQUNYLFdBQVc7b0JBRkY7Z0JBYkU7Z0JBa0JmLFdBQVc7b0JBQ1QscUJBQXFCO3dCQUNuQixXQUFXO3dCQUNYLFdBQVc7b0JBRlE7b0JBSXJCLG1CQUFtQjt3QkFDakIsV0FBVzt3QkFDWCxXQUFXO29CQUZNO29CQUluQixtQkFBbUI7d0JBQ2pCLFdBQVc7d0JBQ1gsV0FBVztvQkFGTTtvQkFJbkIsc0JBQXNCO3dCQUNwQixXQUFXO3dCQUNYLFdBQVc7b0JBRlM7b0JBSXRCLGVBQWU7d0JBQ2IsV0FBVzt3QkFDWCxXQUFXO29CQUZFO29CQUlmLHFCQUFxQjt3QkFDbkIsV0FBVzt3QkFDWCxXQUFXO29CQUZRO29CQUlyQixtQkFBbUI7d0JBQ2pCLFdBQVc7d0JBQ1gsV0FBVztvQkFGTTtnQkF6QlY7Z0JBOEJYLFlBQVk7b0JBQ1YsY0FBYzt3QkFDWixXQUFXO3dCQUNYLFdBQVc7b0JBRkM7b0JBSWQscUJBQXFCO3dCQUNuQixXQUFXO3dCQUNYLFdBQVc7b0JBRlE7b0JBSXJCLFdBQVc7d0JBQ1QsV0FBVzt3QkFDWCxXQUFXO29CQUZGO2dCQVREO2dCQWNaLFdBQVc7b0JBQ1QsU0FBUzt3QkFDUCxTQUFTOzRCQUNQLFdBQVc7NEJBQ1gsV0FBVzt3QkFGSjt3QkFJVCxPQUFPOzRCQUNMLFdBQVc7NEJBQ1gsV0FBVzt3QkFGTjt3QkFJUCxpQkFBaUI7NEJBQ2YsV0FBVzs0QkFDWCxXQUFXO3dCQUZJO3dCQUlqQixVQUFVOzRCQUNSLFdBQVc7NEJBQ1gsV0FBVzt3QkFGSDt3QkFJVixPQUFPOzRCQUNMLFdBQVc7NEJBQ1gsV0FBVzt3QkFGTjtvQkFqQkE7b0JBc0JULFdBQVc7d0JBQ1QsT0FBTzs0QkFDTCxXQUFXOzRCQUNYLFdBQVc7d0JBRk47d0JBSVAsaUJBQWlCOzRCQUNmLFdBQVc7NEJBQ1gsV0FBVzt3QkFGSTtvQkFMUjtvQkFVWCxRQUFRO3dCQUNOLFNBQVM7NEJBQ1AsV0FBVzs0QkFDWCxXQUFXO3dCQUZKO3dCQUlULE9BQU87NEJBQ0wsV0FBVzs0QkFDWCxXQUFXO3dCQUZOO3dCQUlQLGlCQUFpQjs0QkFDZixXQUFXOzRCQUNYLFdBQVc7d0JBRkk7d0JBSWpCLFVBQVU7NEJBQ1IsV0FBVzs0QkFDWCxXQUFXO3dCQUZIO3dCQUlWLE9BQU87NEJBQ0wsV0FBVzs0QkFDWCxXQUFXO3dCQUZOO29CQWpCRDtnQkFqQ0M7Z0JBd0RYLFFBQVE7b0JBQ04scUJBQXFCO3dCQUNuQixXQUFXO3dCQUNYLFdBQVc7b0JBRlE7b0JBSXJCLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO29CQUlWLGtCQUFrQjt3QkFDaEIsV0FBVzt3QkFDWCxXQUFXO29CQUZLO29CQUlsQixXQUFXO3dCQUNULFdBQVc7d0JBQ1gsV0FBVztvQkFGRjtvQkFJWCxhQUFhO3dCQUNYLFdBQVc7d0JBQ1gsV0FBVztvQkFGQTtvQkFJYixpQkFBaUI7d0JBQ2YsV0FBVzt3QkFDWCxXQUFXO29CQUZJO29CQUlqQixPQUFPO3dCQUNMLFdBQVc7d0JBQ1gsV0FBVztvQkFGTjtvQkFJUCxjQUFjO3dCQUNaLFdBQVc7d0JBQ1gsV0FBVztvQkFGQztvQkFJZCxXQUFXO3dCQUNULFdBQVc7d0JBQ1gsV0FBVztvQkFGRjtvQkFJWCxtQkFBbUI7d0JBQ2pCLFdBQVc7d0JBQ1gsV0FBVztvQkFGTTtvQkFJbkIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsUUFBUTt3QkFDTixXQUFXO3dCQUNYLFdBQVc7b0JBRkw7b0JBSVIsU0FBUzt3QkFDUCxXQUFXO3dCQUNYLFdBQVc7b0JBRko7b0JBSVQsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsYUFBYTt3QkFDWCxXQUFXO3dCQUNYLFdBQVc7b0JBRkE7b0JBSWIsZUFBZTt3QkFDYixXQUFXO3dCQUNYLFdBQVc7b0JBRkU7b0JBSWYsV0FBVzt3QkFDVCxXQUFXO3dCQUNYLFdBQVc7b0JBRkY7b0JBSVgsbUJBQW1CO3dCQUNqQixXQUFXO3dCQUNYLFdBQVc7b0JBRk07b0JBSW5CLFVBQVU7d0JBQ1IsV0FBVzt3QkFDWCxXQUFXO29CQUZIO2dCQXpGSjtnQkE4RlIsWUFBWTtvQkFDVixPQUFPO3dCQUNMLFdBQVc7d0JBQ1gsV0FBVztvQkFGTjtnQkFERztnQkFNWixpQkFBaUI7b0JBQ2YsZ0JBQWdCO3dCQUNkLFdBQVc7d0JBQ1gsV0FBVztvQkFGRztvQkFJaEIsWUFBWTt3QkFDVixXQUFXO3dCQUNYLFdBQVc7b0JBRkQ7Z0JBTEc7Z0JBVWpCLGNBQWM7b0JBQ1osMEJBQTBCO3dCQUN4QixXQUFXO3dCQUNYLFdBQVc7b0JBRmE7Z0JBRGQ7Z0JBTWQsV0FBVztvQkFDVCxVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtvQkFJVixPQUFPO3dCQUNMLFdBQVc7d0JBQ1gsV0FBVztvQkFGTjtvQkFJUCxVQUFVO3dCQUNSLFdBQVc7d0JBQ1gsV0FBVztvQkFGSDtvQkFJVixjQUFjO3dCQUNaLFdBQVc7d0JBQ1gsV0FBVztvQkFGQztvQkFJZCxrQkFBa0I7d0JBQ2hCLFdBQVc7d0JBQ1gsV0FBVztvQkFGSztvQkFJbEIsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7b0JBSVYsVUFBVTt3QkFDUixXQUFXO3dCQUNYLFdBQVc7b0JBRkg7Z0JBekJEO1lBam9CTztZQWlxQnBCLElBQUlOLE9BQU9PLElBQVAsQ0FBWUQsYUFBYUUsTUFBekIsS0FBb0MsR0FDdEMsTUFBTSxJQUFJVixNQUFNO1lBR2xCOzs7Ozs7Ozs7T0FTSixHQUNJLE1BQU1XLHVCQUF1QkM7Z0JBQzNCQyxZQUFZQyxVQUFELEVBQWFDLEtBQWIsQ0FBZ0M7b0JBQ3pDLEtBQUEsQ0FBTUE7b0JBQ04sSUFBQSxDQUFLRCxVQUFMLEdBQWtCQTtnQkFDbkI7Z0JBRURHLElBQUlDLEdBQUQsRUFBTTtvQkFDUCxJQUFJLENBQUMsSUFBQSxDQUFLQyxHQUFMLENBQVNELE1BQ1osSUFBQSxDQUFLRSxHQUFMLENBQVNGLEtBQUssSUFBQSxDQUFLSixVQUFMLENBQWdCSTtvQkFHaEMsT0FBTyxLQUFBLENBQU1ELElBQUlDO2dCQUNsQjtZQVprQztZQWVyQzs7Ozs7O09BTUosR0FDSSxNQUFNRyxhQUFhQyxDQUFBQTtnQkFDakIsT0FBT0EsU0FBUyxPQUFPQSxVQUFVLFlBQVksT0FBT0EsTUFBTUMsSUFBYixLQUFzQjtZQUNwRTtZQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7T0E4QkosR0FDSSxNQUFNQyxlQUFlLENBQUNDLFNBQVNDO2dCQUM3QixPQUFPLENBQUMsR0FBR0M7b0JBQ1QsSUFBSXBCLGNBQWNULE9BQWQsQ0FBc0I4QixTQUExQixFQUNFSCxRQUFRSSxNQUFSLENBQWUsSUFBSTdCLE1BQU1PLGNBQWNULE9BQWQsQ0FBc0I4QixTQUF0QixDQUFnQ0UsT0FBMUM7eUJBQ1YsSUFBSUosU0FBU0ssaUJBQVQsSUFDQ0osYUFBYWpCLE1BQWIsSUFBdUIsS0FBS2dCLFNBQVNLLGlCQUFULEtBQStCLE9BQ3JFTixRQUFRTyxPQUFSLENBQWdCTCxZQUFZLENBQUMsRUFBN0I7eUJBRUFGLFFBQVFPLE9BQVIsQ0FBZ0JMO2dCQUVuQjtZQUNGO1lBRUQsTUFBTU0scUJBQXNCQyxDQUFBQSxVQUFZQSxXQUFXLElBQUksYUFBYTtZQUVwRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztPQXlCSixHQUNJLE1BQU1DLG9CQUFvQixDQUFDQyxNQUFNVjtnQkFDL0IsT0FBTyxTQUFTVyxxQkFBcUJDLE1BQTlCLEVBQXNDLEdBQUdDLElBQXpDO29CQUNMLElBQUlBLEtBQUs3QixNQUFMLEdBQWNnQixTQUFTYyxPQUEzQixFQUNFLE1BQU0sSUFBSXhDLE1BQU8sQ0FBQSxrQkFBQSxFQUFvQjBCLFNBQVNjLE9BQVEsQ0FBQSxDQUFBLEVBQUdQLG1CQUFtQlAsU0FBU2MsT0FBVixFQUFtQixLQUFBLEVBQU9KLEtBQUssUUFBQSxFQUFVRyxLQUFLN0IsTUFBTyxDQUFBLENBQTFIO29CQUdSLElBQUk2QixLQUFLN0IsTUFBTCxHQUFjZ0IsU0FBU2UsT0FBM0IsRUFDRSxNQUFNLElBQUl6QyxNQUFPLENBQUEsaUJBQUEsRUFBbUIwQixTQUFTZSxPQUFRLENBQUEsQ0FBQSxFQUFHUixtQkFBbUJQLFNBQVNlLE9BQVYsRUFBbUIsS0FBQSxFQUFPTCxLQUFLLFFBQUEsRUFBVUcsS0FBSzdCLE1BQU8sQ0FBQSxDQUF6SDtvQkFHUixPQUFPLElBQUlnQyxRQUFRLENBQUNWLFNBQVNIO3dCQUMzQixJQUFJSCxTQUFTaUIsb0JBQWIsRUFDRSwyRkFBQTt3QkFDQSxzRkFBQTt3QkFDQSx1REFBQTt3QkFDQSxJQUFJOzRCQUNGTCxNQUFNLENBQUNGLEtBQVAsSUFBZ0JHLE1BQU1mLGFBQWE7Z0NBQUNRO2dDQUFTSDs0QkFBVixHQUFtQkg7d0JBQ3ZELEVBQUMsT0FBT2tCLFNBQVM7NEJBQ2hCQyxRQUFRQyxJQUFSLENBQWMsQ0FBQSxFQUFFVixLQUFLLDREQUFBLENBQVIsR0FDQSxnREFBZ0RROzRCQUU3RE4sTUFBTSxDQUFDRixLQUFQLElBQWdCRyxPQUVoQiw2RUFGQUQ7NEJBR0Esd0NBQUE7NEJBQ0FaLFNBQVNpQixvQkFBVCxHQUFnQzs0QkFDaENqQixTQUFTcUIsVUFBVCxHQUFzQjs0QkFFdEJmO3dCQUNEOzZCQUNJLElBQUlOLFNBQVNxQixVQUFiLEVBQXlCOzRCQUM5QlQsTUFBTSxDQUFDRixLQUFQLElBQWdCRzs0QkFDaEJQO3dCQUNELE9BQ0NNLE1BQU0sQ0FBQ0YsS0FBUCxJQUFnQkcsTUFBTWYsYUFBYTs0QkFBQ1E7NEJBQVNIO3dCQUFWLEdBQW1CSDtvQkFFekQ7Z0JBQ0Y7WUFDRjtZQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7T0FrQkosR0FDSSxNQUFNc0IsYUFBYSxDQUFDVixRQUFRVyxRQUFRQztnQkFDbEMsT0FBTyxJQUFJQyxNQUFNRixRQUFRO29CQUN2QkcsT0FBTUMsWUFBRCxFQUFlQyxPQUFmLEVBQXdCZixJQUF4Qjt3QkFDSCxPQUFPVyxRQUFRSyxJQUFSLENBQWFELFNBQVNoQixXQUFXQztvQkFDekM7Z0JBSHNCO1lBSzFCO1lBRUQsSUFBSWlCLGlCQUFpQkMsU0FBU0YsSUFBVCxDQUFjRyxJQUFkLENBQW1CeEQsT0FBT0UsU0FBUCxDQUFpQm9ELGNBQXBDO1lBRXJCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O09Bc0JKLEdBQ0ksTUFBTUcsYUFBYSxDQUFDckIsUUFBUXNCLFdBQVcsQ0FBQSxDQUFwQixFQUF3QmxDLFdBQVcsQ0FBQSxDQUFuQztnQkFDakIsSUFBSW1DLFFBQVEzRCxPQUFPNEQsTUFBUCxDQUFjO2dCQUMxQixJQUFJQyxXQUFXO29CQUNiNUMsS0FBSTZDLFdBQUQsRUFBY0MsSUFBZDt3QkFDRCxPQUFPQSxRQUFRM0IsVUFBVTJCLFFBQVFKO29CQUNsQztvQkFFRDVDLEtBQUkrQyxXQUFELEVBQWNDLElBQWQsRUFBb0JDLFFBQXBCO3dCQUNELElBQUlELFFBQVFKLE9BQ1YsT0FBT0EsS0FBSyxDQUFDSSxLQUFiO3dCQUdGLElBQUksQ0FBRUEsQ0FBQUEsUUFBUTNCLE1BQUFBLEdBQ1osT0FBT3RCO3dCQUdULElBQUlNLFFBQVFnQixNQUFNLENBQUMyQixLQUFuQjt3QkFFQSxJQUFJLE9BQU8zQyxVQUFVLFlBQVk7NEJBQy9CLG9FQUFBOzRCQUNBLGdCQUFBOzRCQUVBLElBQUksT0FBT3NDLFFBQVEsQ0FBQ0ssS0FBaEIsS0FBMEIsWUFDNUIsa0RBQUE7NEJBQ0EzQyxRQUFRMEIsV0FBV1YsUUFBUUEsTUFBTSxDQUFDMkIsS0FBaEIsRUFBdUJMLFFBQVEsQ0FBQ0ssS0FBaEM7aUNBQ2IsSUFBSVQsZUFBZTlCLFVBQVV1QyxPQUFPO2dDQUN6Qyw4REFBQTtnQ0FDQSwwQkFBQTtnQ0FDQSxJQUFJZixVQUFVZixrQkFBa0I4QixNQUFNdkMsUUFBUSxDQUFDdUMsS0FBaEI7Z0NBQy9CM0MsUUFBUTBCLFdBQVdWLFFBQVFBLE1BQU0sQ0FBQzJCLEtBQWhCLEVBQXVCZjs0QkFDMUMsT0FDQyxnRUFBQTs0QkFDQSxtREFBQTs0QkFDQTVCLFFBQVFBLE1BQU1vQyxJQUFOLENBQVdwQjt3QkFFdEIsT0FBTSxJQUFJLE9BQU9oQixVQUFVLFlBQVlBLFVBQVUsUUFDdENrQyxDQUFBQSxlQUFlSSxVQUFVSyxTQUN6QlQsZUFBZTlCLFVBQVV1QyxLQUFYLEdBQ3hCLHNFQUFBO3dCQUNBLG9FQUFBO3dCQUNBLFlBQUE7d0JBQ0EzQyxRQUFRcUMsV0FBV3JDLE9BQU9zQyxRQUFRLENBQUNLLEtBQWpCLEVBQXdCdkMsUUFBUSxDQUFDdUMsS0FBakM7NkJBQ2IsSUFBSVQsZUFBZTlCLFVBQVUsTUFDbEMsc0NBQUE7d0JBQ0FKLFFBQVFxQyxXQUFXckMsT0FBT3NDLFFBQVEsQ0FBQ0ssS0FBakIsRUFBd0J2QyxRQUFRLENBQUMsSUFBakM7NkJBQ2I7NEJBQ0wsc0RBQUE7NEJBQ0EsdURBQUE7NEJBQ0F4QixPQUFPaUUsY0FBUCxDQUFzQk4sT0FBT0ksTUFBTTtnQ0FDakNHLGNBQWM7Z0NBQ2RDLFlBQVk7Z0NBQ1pwRDtvQ0FDRSxPQUFPcUIsTUFBTSxDQUFDMkIsS0FBZDtnQ0FDRDtnQ0FDRDdDLEtBQUlFLEtBQUQ7b0NBQ0RnQixNQUFNLENBQUMyQixLQUFQLEdBQWUzQztnQ0FDaEI7NEJBUmdDOzRCQVduQyxPQUFPQTt3QkFDUjt3QkFFRHVDLEtBQUssQ0FBQ0ksS0FBTixHQUFjM0M7d0JBQ2QsT0FBT0E7b0JBQ1I7b0JBRURGLEtBQUk0QyxXQUFELEVBQWNDLElBQWQsRUFBb0IzQyxLQUFwQixFQUEyQjRDLFFBQTNCO3dCQUNELElBQUlELFFBQVFKLE9BQ1ZBLEtBQUssQ0FBQ0ksS0FBTixHQUFjM0M7NkJBRWRnQixNQUFNLENBQUMyQixLQUFQLEdBQWUzQzt3QkFFakIsT0FBTztvQkFDUjtvQkFFRDZDLGdCQUFlSCxXQUFELEVBQWNDLElBQWQsRUFBb0JLLElBQXBCO3dCQUNaLE9BQU9DLFFBQVFKLGNBQVIsQ0FBdUJOLE9BQU9JLE1BQU1LO29CQUM1QztvQkFFREUsZ0JBQWVSLFdBQUQsRUFBY0MsSUFBZDt3QkFDWixPQUFPTSxRQUFRQyxjQUFSLENBQXVCWCxPQUFPSTtvQkFDdEM7Z0JBL0VZLEdBa0ZmLHlFQWxGZTtnQkFtRmYsdUVBQUE7Z0JBQ0Esa0VBQUE7Z0JBQ0EsZ0VBQUE7Z0JBQ0EsMkRBQUE7Z0JBQ0EsMEVBQUE7Z0JBQ0EsRUFBQTtnQkFDQSxxRUFBQTtnQkFDQSx1RUFBQTtnQkFDQSx5Q0FBQTtnQkFDQSxJQUFJRCxjQUFjOUQsT0FBTzRELE1BQVAsQ0FBY3hCO2dCQUNoQyxPQUFPLElBQUlhLE1BQU1hLGFBQWFEO1lBQy9CO1lBRUQ7Ozs7Ozs7Ozs7Ozs7OztPQWVKLEdBQ0ksTUFBTVUsWUFBWUMsQ0FBQUEsYUFBZSxDQUFBO29CQUMvQkMsYUFBWXJDLE1BQUQsRUFBU3NDLFFBQVQsRUFBbUIsR0FBR3JDLElBQXRCO3dCQUNURCxPQUFPcUMsV0FBUCxDQUFtQkQsV0FBV3pELEdBQVgsQ0FBZTJELGNBQWNyQztvQkFDakQ7b0JBRURzQyxhQUFZdkMsTUFBRCxFQUFTc0MsUUFBVDt3QkFDVCxPQUFPdEMsT0FBT3VDLFdBQVAsQ0FBbUJILFdBQVd6RCxHQUFYLENBQWUyRDtvQkFDMUM7b0JBRURFLGdCQUFleEMsTUFBRCxFQUFTc0MsUUFBVDt3QkFDWnRDLE9BQU93QyxjQUFQLENBQXNCSixXQUFXekQsR0FBWCxDQUFlMkQ7b0JBQ3RDO2dCQVg4QixDQUFBO1lBY2pDLE1BQU1HLDRCQUE0QixJQUFJcEUsZUFBZWlFLENBQUFBO2dCQUNuRCxJQUFJLE9BQU9BLGFBQWEsWUFDdEIsT0FBT0E7Z0JBR1Q7Ozs7Ozs7U0FPTixHQUNNLE9BQU8sU0FBU0ksa0JBQWtCQyxHQUEzQjtvQkFDTCxNQUFNQyxhQUFhdkIsV0FBV3NCLEtBQUssQ0FBbkMsR0FBc0Q7d0JBQ3BERSxZQUFZOzRCQUNWM0MsU0FBUzs0QkFDVEMsU0FBUzt3QkFGQztvQkFEd0M7b0JBTXREbUMsU0FBU007Z0JBQ1Y7WUFDRjtZQUVELE1BQU1FLG9CQUFvQixJQUFJekUsZUFBZWlFLENBQUFBO2dCQUMzQyxJQUFJLE9BQU9BLGFBQWEsWUFDdEIsT0FBT0E7Z0JBR1Q7Ozs7Ozs7Ozs7Ozs7Ozs7U0FnQk4sR0FDTSxPQUFPLFNBQVNTLFVBQVV2RCxPQUFuQixFQUE0QndELE1BQTVCLEVBQW9DQyxZQUFwQztvQkFDTCxJQUFJQyxzQkFBc0I7b0JBRTFCLElBQUlDO29CQUNKLElBQUlDLHNCQUFzQixJQUFJaEQsUUFBUVYsQ0FBQUE7d0JBQ3BDeUQsc0JBQXNCLFNBQVNFLFFBQVQ7NEJBQ3BCSCxzQkFBc0I7NEJBQ3RCeEQsUUFBUTJEO3dCQUNUO29CQUNGO29CQUVELElBQUlDO29CQUNKLElBQUk7d0JBQ0ZBLFNBQVNoQixTQUFTOUMsU0FBU3dELFFBQVFHO29CQUNwQyxFQUFDLE9BQU9JLEtBQUs7d0JBQ1pELFNBQVNsRCxRQUFRYixNQUFSLENBQWVnRTtvQkFDekI7b0JBRUQsTUFBTUMsbUJBQW1CRixXQUFXLFFBQVF2RSxXQUFXdUUsU0FFdkQsK0RBRkE7b0JBR0EseURBQUE7b0JBQ0EsNkRBQUE7b0JBQ0EsSUFBSUEsV0FBVyxRQUFRLENBQUNFLG9CQUFvQixDQUFDTixxQkFDM0MsT0FBTztxQkFHVCw2REFGQztvQkFHRCxpRUFBQTtvQkFDQSxpRUFBQTtvQkFDQSxZQUFBO29CQUNBLE1BQU1PLHFCQUFzQnRFLENBQUFBO3dCQUMxQkEsUUFBUUYsSUFBUixDQUFheUUsQ0FBQUE7NEJBQ1gsMEJBQUE7NEJBQ0FULGFBQWFTO3dCQUNkLEdBQUVDLENBQUFBOzRCQUNELGdFQUFBOzRCQUNBLDJEQUFBOzRCQUNBLElBQUluRTs0QkFDSixJQUFJbUUsU0FBVUEsQ0FBQUEsaUJBQWlCakcsU0FDM0IsT0FBT2lHLE1BQU1uRSxPQUFiLEtBQXlCLFFBQUEsR0FDM0JBLFVBQVVtRSxNQUFNbkUsT0FBaEI7aUNBRUFBLFVBQVU7NEJBR1p5RCxhQUFhO2dDQUNYVyxtQ0FBbUM7Z0NBQ25DcEU7NEJBRlc7d0JBSWQsR0FBRXFFLEtBbEJILENBa0JTTixDQUFBQTs0QkFDUCxnRUFBQTs0QkFDQWhELFFBQVFvRCxLQUFSLENBQWMsMkNBQTJDSjt3QkFDMUQ7b0JBQ0YsR0FFRCxtRUFGQztvQkFHRCx3RUFBQTtvQkFDQSxpREFBQTtvQkFDQSxJQUFJQyxrQkFDRkMsbUJBQW1CSDt5QkFFbkJHLG1CQUFtQkw7cUJBR3JCLGlEQUZDO29CQUdELE9BQU87Z0JBQ1I7WUFDRjtZQUVELE1BQU1VLDZCQUE2QixDQUFDLEVBQUN2RSxNQUFELEVBQVNHLE9BQUFBLEVBQVYsRUFBb0JxRTtnQkFDckQsSUFBSTlGLGNBQWNULE9BQWQsQ0FBc0I4QixTQUExQjtvQkFDRSxnRkFBQTtvQkFDQSwwQ0FBQTtvQkFDQSxrRUFBQTtvQkFDQSxJQUFJckIsY0FBY1QsT0FBZCxDQUFzQjhCLFNBQXRCLENBQWdDRSxPQUFoQyxLQUE0Q3pCLGtEQUM5QzJCO3lCQUVBSCxPQUFPLElBQUk3QixNQUFNTyxjQUFjVCxPQUFkLENBQXNCOEIsU0FBdEIsQ0FBZ0NFLE9BQTFDO3VCQUVKLElBQUl1RSxTQUFTQSxNQUFNSCxpQ0FBbkIsRUFDTCx5REFBQTtnQkFDQSxxQkFBQTtnQkFDQXJFLE9BQU8sSUFBSTdCLE1BQU1xRyxNQUFNdkUsT0FBaEI7cUJBRVBFLFFBQVFxRTtZQUVYO1lBRUQsTUFBTUMscUJBQXFCLENBQUNsRSxNQUFNVixVQUFVNkUsaUJBQWlCLEdBQUdoRTtnQkFDOUQsSUFBSUEsS0FBSzdCLE1BQUwsR0FBY2dCLFNBQVNjLE9BQTNCLEVBQ0UsTUFBTSxJQUFJeEMsTUFBTyxDQUFBLGtCQUFBLEVBQW9CMEIsU0FBU2MsT0FBUSxDQUFBLENBQUEsRUFBR1AsbUJBQW1CUCxTQUFTYyxPQUFWLEVBQW1CLEtBQUEsRUFBT0osS0FBSyxRQUFBLEVBQVVHLEtBQUs3QixNQUFPLENBQUEsQ0FBMUg7Z0JBR1IsSUFBSTZCLEtBQUs3QixNQUFMLEdBQWNnQixTQUFTZSxPQUEzQixFQUNFLE1BQU0sSUFBSXpDLE1BQU8sQ0FBQSxpQkFBQSxFQUFtQjBCLFNBQVNlLE9BQVEsQ0FBQSxDQUFBLEVBQUdSLG1CQUFtQlAsU0FBU2UsT0FBVixFQUFtQixLQUFBLEVBQU9MLEtBQUssUUFBQSxFQUFVRyxLQUFLN0IsTUFBTyxDQUFBLENBQXpIO2dCQUdSLE9BQU8sSUFBSWdDLFFBQVEsQ0FBQ1YsU0FBU0g7b0JBQzNCLE1BQU0yRSxZQUFZSiwyQkFBMkIxQyxJQUEzQixDQUFnQyxNQUFNO3dCQUFDMUI7d0JBQVNIO29CQUFWO29CQUN4RFUsS0FBS2tFLElBQUwsQ0FBVUQ7b0JBQ1ZELGdCQUFnQkcsV0FBaEIsSUFBK0JuRTtnQkFDaEM7WUFDRjtZQUVELE1BQU1vRSxpQkFBaUI7Z0JBQ3JCQyxVQUFVO29CQUNSQyxTQUFTO3dCQUNQN0IsbUJBQW1CUCxVQUFVTTtvQkFEdEI7Z0JBREQ7Z0JBS1ZqRixTQUFTO29CQUNQdUYsV0FBV1osVUFBVVc7b0JBQ3JCMEIsbUJBQW1CckMsVUFBVVc7b0JBQzdCc0IsYUFBYUosbUJBQW1CNUMsSUFBbkIsQ0FBd0IsTUFBTSxlQUFlO3dCQUFDbEIsU0FBUzt3QkFBR0MsU0FBUztvQkFBdEI7Z0JBSG5EO2dCQUtUc0UsTUFBTTtvQkFDSkwsYUFBYUosbUJBQW1CNUMsSUFBbkIsQ0FBd0IsTUFBTSxlQUFlO3dCQUFDbEIsU0FBUzt3QkFBR0MsU0FBUztvQkFBdEI7Z0JBRHREO1lBWGU7WUFldkIsTUFBTXVFLGtCQUFrQjtnQkFDdEJDLE9BQU87b0JBQUN6RSxTQUFTO29CQUFHQyxTQUFTO2dCQUF0QjtnQkFDUHhCLEtBQUs7b0JBQUN1QixTQUFTO29CQUFHQyxTQUFTO2dCQUF0QjtnQkFDTHJCLEtBQUs7b0JBQUNvQixTQUFTO29CQUFHQyxTQUFTO2dCQUF0QjtZQUhpQjtZQUt4QmpDLFlBQVkwRyxPQUFaLEdBQXNCO2dCQUNwQkwsU0FBUztvQkFBQyxLQUFLRztnQkFBTjtnQkFDVEcsVUFBVTtvQkFBQyxLQUFLSDtnQkFBTjtnQkFDVkksVUFBVTtvQkFBQyxLQUFLSjtnQkFBTjtZQUhVO1lBTXRCLE9BQU9yRCxXQUFXcEQsZUFBZW9HLGdCQUFnQm5HO1FBQ2xELEdBRUQseUVBRkM7UUFHRCwrQkFBQTtRQUNBNkcsUUFBT0MsT0FBUCxHQUFpQmhILFNBQVNUO0lBQzNCLE9BQ0N3SCxRQUFPQyxPQUFQLEdBQWlCMUgsV0FBV0ssT0FBNUI7QTs7Ozs7OENDN3JDVzsrQ0FFQTtvREFFQTttREFFQTtnREFFQTtrREFFQTtBQVZOLE1BQU0sV0FBVyxDQUFDLHljQUF5YyxDQUFDO0FBRTVkLE1BQU0sWUFBWSxDQUFDLHdZQUF3WSxDQUFDO0FBRTVaLE1BQU0saUJBQWlCLENBQUMsbVpBQW1aLENBQUM7QUFFNWEsTUFBTSxnQkFBZ0IsQ0FBQyx3M0JBQXczQixDQUFDO0FBRWg1QixNQUFNLGFBQWEsQ0FBQyw0aEJBQTRoQixDQUFDO0FBRWpqQixNQUFNLGVBQWUsQ0FBQyxnb0JBQWdvQixDQUFDOzs7QUNWOXBCLFFBQVEsY0FBYyxHQUFHLFNBQVUsQ0FBQztJQUNsQyxPQUFPLEtBQUssRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUFDLFNBQVM7SUFBQztBQUM1QztBQUVBLFFBQVEsaUJBQWlCLEdBQUcsU0FBVSxDQUFDO0lBQ3JDLE9BQU8sY0FBYyxDQUFDLEdBQUcsY0FBYztRQUFDLE9BQU87SUFBSTtBQUNyRDtBQUVBLFFBQVEsU0FBUyxHQUFHLFNBQVUsTUFBTSxFQUFFLElBQUk7SUFDeEMsT0FBTyxJQUFJLENBQUMsUUFBUSxPQUFPLENBQUMsU0FBVSxHQUFHO1FBQ3ZDLElBQ0UsUUFBUSxhQUNSLFFBQVEsZ0JBQ1IsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLE1BRTNDO1FBR0YsT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLO1lBQy9CLFlBQVk7WUFDWixLQUFLO2dCQUNILE9BQU8sTUFBTSxDQUFDLElBQUk7WUFDcEI7UUFDRjtJQUNGO0lBRUEsT0FBTztBQUNUO0FBRUEsUUFBUSxNQUFNLEdBQUcsU0FBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFDNUMsT0FBTyxjQUFjLENBQUMsTUFBTSxVQUFVO1FBQ3BDLFlBQVk7UUFDWixLQUFLO0lBQ1A7QUFDRjs7Ozs7QUNsQ0EsOENBQWdCO0FBQVQsU0FBUyxTQUFTLEdBQUc7SUFDM0IsMkJBQTJCO0lBQzNCLElBQUksSUFBSSxHQUNQLElBQUksR0FDSixJQUFJO0lBQ0wsSUFBSSxJQUFJLE1BQU0sS0FBSyxHQUFHO1FBQ3JCLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEVBQUU7UUFDOUIsSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEVBQUUsRUFBRTtRQUM5QixJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsR0FBRyxHQUFHLENBQUMsRUFBRSxFQUFFO0lBQy9CLE9BQU8sSUFBSSxJQUFJLE1BQU0sS0FBSyxHQUFHO1FBQzVCLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUk7UUFDOUIsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSTtRQUM5QixJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJO0lBQy9CO0lBRUEsMEJBQTBCO0lBQzFCLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSztJQUNMLE1BQU0sTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEdBQUc7SUFDM0IsTUFBTSxNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsR0FBRztJQUMzQixJQUFJLEdBQ0gsR0FDQSxJQUFJLEFBQUMsQ0FBQSxNQUFNLEdBQUUsSUFBSztJQUVuQixJQUFJLFFBQVEsS0FDWCxJQUFJLElBQUksRUFBRSxhQUFhOztTQUNqQjtRQUNOLE1BQU0sSUFBSSxNQUFNO1FBQ2hCLElBQUksSUFBSSxNQUFNLElBQUssQ0FBQSxJQUFJLE1BQU0sR0FBRSxJQUFLLElBQUssQ0FBQSxNQUFNLEdBQUU7UUFDakQsT0FBUTtZQUNQLEtBQUs7Z0JBQ0osSUFBSSxBQUFDLENBQUEsSUFBSSxDQUFBLElBQUssSUFBSyxDQUFBLElBQUksSUFBSSxJQUFJLENBQUE7Z0JBQy9CO1lBQ0QsS0FBSztnQkFDSixJQUFJLEFBQUMsQ0FBQSxJQUFJLENBQUEsSUFBSyxJQUFJO2dCQUNsQjtZQUNELEtBQUs7Z0JBQ0osSUFBSSxBQUFDLENBQUEsSUFBSSxDQUFBLElBQUssSUFBSTtnQkFDbEI7UUFDRjtRQUNBLEtBQUs7SUFDTjtJQUVBLE9BQU87UUFBQyxLQUFLLEtBQUssQ0FBQyxJQUFJO1FBQU0sS0FBSyxLQUFLLENBQUMsSUFBSTtRQUFNLEtBQUssS0FBSyxDQUFDLElBQUk7S0FBSztBQUN2RTs7O0FDN0NBLFVBQVU7OztrREFzRUM7QUFxUVgsb0NBQW9DO0FBQ3BDLDBEQUFnQjtBQTNVaEI7O0FBQ0E7QUFFQSxZQUFZO0FBQ1osTUFBTSxXQUFXO0lBQ2hCLFlBQVksaUJBQWlCLFNBQVMsZUFBZSxFQUFFLGdCQUFnQixDQUFDO0lBQ3hFLFVBQVU7SUFDVixlQUFlO0lBQ2YsWUFBWTtBQUNiO0FBRUEsTUFBTSxhQUFhO0lBQ2xCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7Q0FDQTtBQUVELHVKQUF1SjtBQUN2SixNQUFNLHNCQUFzQixDQUFDLGtGQUFrRixDQUFDO0FBRWhILElBQUkscUJBQXFCLE1BQ3hCLHVCQUF1QixNQUN2QiwwQkFBMEI7QUFFM0IsTUFBTSxlQUFlO0lBQ3BCLE1BQU07SUFDTixXQUFXO0lBQ1gsU0FBUztJQUNULFdBQVc7SUFDWCxZQUFZLFNBQVMsUUFBUTtJQUM3QixrQkFBa0IsU0FBUyxRQUFRO0lBQ25DLE1BQU07SUFDTixLQUFLO0lBQ0wsS0FBSztBQUNOO0FBRUEsTUFBTSxpQkFBaUI7SUFDdEIsTUFBTTtJQUNOLFdBQVc7SUFDWCxTQUFTO0lBQ1QsV0FBVztJQUNYLFlBQVksU0FBUyxVQUFVO0lBQy9CLGtCQUFrQixTQUFTLFVBQVU7SUFDckMsTUFBTTtJQUNOLEtBQUs7SUFDTCxLQUFLO0FBQ047QUFFQSxNQUFNLG9CQUFvQjtJQUN6QixNQUFNO0lBQ04sV0FBVztJQUNYLFNBQVM7SUFDVCxXQUFXO0lBQ1gsWUFBWSxTQUFTLGFBQWE7SUFDbEMsa0JBQWtCLFNBQVMsYUFBYTtJQUN4QyxNQUFNO0lBQ04sS0FBSztJQUNMLEtBQUs7QUFDTjtBQUdPLElBQUksZUFBZSxDQUFDOzs7Ozs7Ozs7O1lBVWYsRUFBRSxXQUFXLEdBQUcsQ0FDeEIsQ0FBQyxPQUFTLENBQUMsZUFBZSxFQUFFLFNBQVMsWUFBWSxTQUFTLFVBQVUsR0FBRyxLQUFLLEVBQUUsRUFBRSxLQUFLLFNBQVMsQ0FBQyxFQUM5RixJQUFJLENBQUMsSUFBSTs7OztNQUlSLEVBQUUsQ0FBQSxHQUFBLDhCQUFpQixBQUFELEVBQUUsY0FBYztNQUNsQyxFQUFFLENBQUEsR0FBQSxnQ0FBbUIsQUFBRCxFQUFFLGdCQUFnQjtNQUN0QyxFQUFFLENBQUEsR0FBQSxnQ0FBbUIsQUFBRCxFQUFFLG1CQUFtQjs7O01BR3pDLEVBQUUsQ0FBQSxHQUFBLHlCQUFZLEFBQUQsRUFBRTtJQUFFLElBQUk7SUFBYSxTQUFTO0lBQWUsVUFBVTtJQUFPLFdBQVc7QUFBYyxHQUFHOzs7QUFHN0csQ0FBQztBQUVELHFDQUFxQztBQUNyQyxTQUFTLG1CQUFtQixhQUFhLEVBQUUsUUFBUTtJQUNsRCxNQUFNLFVBQVUsU0FBUyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUM7SUFFekUsUUFBUSxLQUFLLEdBQUc7QUFDakI7QUFFQSw2QkFBNkI7QUFDN0IsU0FBUyxjQUFjLFFBQVE7SUFDOUIsT0FBTyxPQUFPLENBQUMsVUFBVSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTTtRQUM3QyxTQUFTLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO1FBQ3ZELG1CQUFtQixLQUFLO0lBRXhCLDZHQUE2RztJQUM5RztBQUNEO0FBRUEsOENBQThDO0FBQzlDLGVBQWUsYUFBYSxRQUFRO0lBQ25DLElBQUk7UUFDSCxNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7SUFDaEMsRUFBRSxPQUFPLE9BQU87UUFDZixRQUFRLEtBQUssQ0FBQyw0QkFBNEI7SUFDM0M7QUFDRDtBQUVBLGdEQUFnRDtBQUNoRCxlQUFlO0lBQ2QsSUFBSTtRQUNILE1BQU0sV0FBVyxNQUFNLENBQUEsR0FBQSxvQ0FBTyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUM7UUFFNUQsSUFBSSxTQUFTLFVBQVUsSUFBSSxTQUFTLFVBQVUsS0FBSyxTQUFTLFVBQVUsRUFDckUsZUFBZSxTQUFTLFVBQVU7UUFFbkMsY0FBYztJQUNmLEVBQUUsT0FBTyxPQUFPO1FBQ2YsUUFBUSxLQUFLLENBQUMsNEJBQTRCO0lBQzNDO0FBQ0Q7QUFFQSw0Q0FBNEM7QUFDNUMsU0FBUyxlQUFlLFVBQVU7SUFDakM7Ozs7Ozs7O2lDQVFnQyxHQUNoQyxNQUFNLFFBQVE7UUFDYjtZQUFFLEtBQUs7WUFBYyxNQUFNO1FBQStCO1FBQzFEO1lBQUUsS0FBSztZQUFjLE1BQU07WUFBNkIsYUFBYTtRQUFHO1FBQ3hFO1lBQ0MsS0FBSztZQUNMLE1BQU0sQ0FBQyx5Q0FBeUMsRUFBRSxXQUFXLE9BQU8sQ0FDbkUsS0FDQSxLQUNDLEVBQUUsb0JBQW9CLGFBQWEsQ0FBQztRQUN2QztLQUNBO0lBRUQsTUFBTSxPQUFPLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO1FBQ3hDLE1BQU0sT0FBTyxTQUFTLGFBQWEsQ0FBQztRQUNwQyxLQUFLLEdBQUcsR0FBRztRQUNYLEtBQUssSUFBSSxHQUFHO1FBQ1osSUFBSSxnQkFBZ0IsV0FDbkIsS0FBSyxXQUFXLEdBQUc7UUFFcEIsU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzNCO0FBQ0Q7QUFDQSx3Q0FBd0M7QUFDeEMsU0FBUztJQUNSLGlHQUFpRztJQUNqRyxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsZ0JBQWdCLENBQUM7QUFDN0M7QUFDQSwyQ0FBMkM7QUFDM0MsU0FBUztJQUNSLE1BQU0sUUFBUTtJQUVkLGdDQUFnQztJQUVoQyxNQUFNLE9BQU8sQ0FBQyxDQUFDO1FBQ2QsSUFBSSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsMkJBQTJCLEtBQUssSUFBSSxDQUFDLFFBQVEsQ0FBQyxzQkFDcEUsS0FBSyxNQUFNO0lBRWI7QUFDRDtBQUNBOzs7Ozs7Ozs7Ozs7RUFZRSxHQUVGLG9DQUFvQztBQUNwQyxTQUFTLG1CQUFtQixVQUFVLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRTtJQUNwRCxJQUFJLE1BQU0sYUFBYTtRQUN0QixhQUFhO1FBQ2IsT0FBTztJQUNSLE9BQU8sSUFBSSxhQUFhLE9BQU8sYUFBYSxLQUFLO1FBQ2hELGFBQWEsQ0FBQyx1QkFBdUIsRUFBRSxJQUFJLEtBQUssRUFBRSxJQUFJLENBQUM7UUFDdkQsT0FBTztJQUNSO0lBQ0EsT0FBTztBQUNSO0FBRUEscUNBQXFDO0FBQ3JDLFNBQVMsYUFBYSxPQUFPO0lBQzVCLHFDQUFxQztJQUNyQyxNQUFNLGdCQUFnQixTQUFTLGFBQWEsQ0FBQztJQUM3QyxJQUFJLGVBQWUsY0FBYyxNQUFNO0lBRXZDLDBDQUEwQztJQUMxQyxNQUFNLGVBQWUsU0FBUyxhQUFhLENBQUM7SUFDNUMsYUFBYSxTQUFTLEdBQUc7SUFDekIsYUFBYSxXQUFXLEdBQUc7SUFDM0IsU0FBUyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBRTFCLDJDQUEyQztJQUMzQyxXQUFXO1FBQ1YsYUFBYSxNQUFNO0lBQ3BCLEdBQUc7QUFDSjtBQUVBLDZCQUE2QjtBQUM3QixTQUFTLGFBQWEsUUFBUSxFQUFFLGFBQWEsQ0FBQztJQUM3Qyw2Q0FBNkM7SUFDN0MsV0FBVyxTQUFTLE9BQU8sQ0FBQyxnQkFBZ0I7SUFDNUMsa0VBQWtFO0lBQ2xFLElBQUksWUFBWSxXQUFXLFVBQVUsT0FBTyxDQUFDO0lBQzdDLDhDQUE4QztJQUM5QyxZQUFZLFVBQVUsT0FBTyxDQUFDLFVBQVU7SUFDeEMsMENBQTBDO0lBQzFDLE9BQU87QUFDUjtBQUVBLHNDQUFzQztBQUN0QyxTQUFTLGVBQWUsQ0FBQztJQUN4QixNQUFNLFNBQVMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxLQUFLO0lBQzFDLHFCQUFxQixhQUFhLG9CQUFvQjtJQUV0RCxJQUFJLHVCQUF1QixRQUFRO0lBRW5DLElBQUksQ0FBQyxtQkFBbUIsUUFBUSxhQUFhLEdBQUcsRUFBRSxhQUFhLEdBQUcsR0FBRztRQUNwRSxtQkFBbUIsWUFBWTtRQUMvQixjQUFjO1lBQUUsVUFBVTtRQUFtQjtRQUM3QyxhQUFhO1lBQUUsVUFBVTtRQUFtQjtRQUM1QywrQ0FBK0M7UUFDL0MsaURBQWlEO1FBQ2pELGdEQUFnRDtRQUNoRDtJQUNEO0lBRUEsY0FBYztRQUFFLFVBQVU7SUFBTztJQUNqQyxhQUFhO1FBQUUsVUFBVTtJQUFPO0FBQ2pDO0FBRUEsd0NBQXdDO0FBQ3hDLFNBQVMsaUJBQWlCLENBQUM7SUFDMUIsTUFBTSxTQUFTLGFBQWEsRUFBRSxNQUFNLENBQUMsS0FBSztJQUMxQyx1QkFBdUIsYUFBYSxzQkFBc0I7SUFFMUQsSUFBSSx5QkFBeUIsUUFBUTtJQUVyQyxJQUFJLENBQUMsbUJBQW1CLFFBQVEsZUFBZSxHQUFHLEVBQUUsZUFBZSxHQUFHLEdBQUc7UUFDeEUsbUJBQW1CLGNBQWM7UUFDakMsY0FBYztZQUFFLFlBQVk7UUFBcUI7UUFDakQsYUFBYTtZQUFFLFlBQVk7UUFBcUI7UUFDaEQ7SUFDRDtJQUVBLGNBQWM7UUFBRSxZQUFZO0lBQU87SUFDbkMsYUFBYTtRQUFFLFlBQVk7SUFBTztBQUNuQztBQUVBLDJDQUEyQztBQUMzQyxTQUFTLG9CQUFvQixDQUFDO0lBQzdCLE1BQU0sU0FBUyxhQUFhLEVBQUUsTUFBTSxDQUFDLEtBQUs7SUFDMUMsMEJBQTBCLGFBQWEseUJBQXlCO0lBRWhFLElBQUksNEJBQTRCLFFBQVE7SUFFeEMsSUFBSSxDQUFDLG1CQUFtQixRQUFRLGtCQUFrQixHQUFHLEVBQUUsa0JBQWtCLEdBQUcsR0FBRztRQUM5RSxtQkFBbUIsaUJBQWlCO1FBQ3BDLGNBQWM7WUFBRSxlQUFlO1FBQXdCO1FBQ3ZELGFBQWE7WUFBRSxlQUFlO1FBQXdCO1FBQ3REO0lBQ0Q7SUFFQSxjQUFjO1FBQUUsZUFBZTtJQUFPO0lBQ3RDLGFBQWE7UUFBRSxlQUFlO0lBQU87QUFDdEM7QUFFQSx3Q0FBd0M7QUFDeEMsZUFBZSxpQkFBaUIsQ0FBQztJQUNoQyxNQUFNLGVBQWUsRUFBRSxNQUFNLENBQUMsS0FBSztJQUVuQyx5Q0FBeUM7SUFDekM7SUFDQSxJQUFJLGlCQUFpQixTQUFTLFVBQVUsRUFBRTtRQUN6QyxzQ0FBc0M7UUFDdEMsZUFBZTtRQUNmLGNBQWM7WUFBRSxZQUFZO1FBQWE7UUFDekMsSUFBSTtZQUNILE1BQU0sYUFBYTtnQkFBRSxZQUFZO1lBQWE7UUFDL0MsRUFBRSxPQUFPLE9BQU87WUFDZixRQUFRLEtBQUssQ0FBQywrQkFBK0I7UUFDOUM7SUFDRCxPQUFPO1FBQ04scUNBQXFDO1FBQ3JDLGNBQWM7WUFBRSxZQUFZO1FBQWE7UUFDekMsSUFBSTtZQUNILE1BQU0sYUFBYTtnQkFBRSxZQUFZO1lBQWE7UUFDL0MsRUFBRSxPQUFPLE9BQU87WUFDZixRQUFRLEtBQUssQ0FBQyxnQ0FBZ0M7UUFDL0M7SUFDRDtBQUNEO0FBRUEscUNBQXFDO0FBQ3JDLFNBQVM7SUFDUixjQUFjO0lBQ2QsYUFBYTtBQUNkO0FBR08sU0FBUztJQUNmLE1BQU0sWUFBWTtRQUNqQixrQkFBa0IsU0FBUyxhQUFhLENBQUM7UUFDekMsZUFBZSxTQUFTLGFBQWEsQ0FBQztRQUN0QyxpQkFBaUIsU0FBUyxhQUFhLENBQUM7UUFDeEMsb0JBQW9CLFNBQVMsYUFBYSxDQUFDO1FBQzNDLGNBQWMsU0FBUyxhQUFhLENBQUM7SUFDdEM7SUFFQSxVQUFVLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLFVBQVU7SUFDdEQsVUFBVSxhQUFhLENBQUMsZ0JBQWdCLENBQUMsUUFBUTtJQUNqRCxVQUFVLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRO0lBQ25ELFVBQVUsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsUUFBUTtJQUV0RCxVQUFVLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7UUFDbEQscUJBQXFCLEVBQUUsTUFBTSxDQUFDLEtBQUs7SUFDcEM7SUFDQSxVQUFVLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7UUFDcEQsdUJBQXVCLEVBQUUsTUFBTSxDQUFDLEtBQUs7SUFDdEM7SUFDQSxVQUFVLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQztRQUN2RCwwQkFBMEIsRUFBRSxNQUFNLENBQUMsS0FBSztJQUN6QztJQUVBLFVBQVUsYUFBYSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztRQUNyRCxJQUFJLEVBQUUsR0FBRyxLQUFLLFNBQVM7WUFDdEIsRUFBRSxjQUFjO1lBQ2hCLGVBQWU7WUFDZixFQUFFLE1BQU0sQ0FBQyxJQUFJO1FBQ2Q7SUFDRDtJQUNBLFVBQVUsZUFBZSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztRQUN2RCxJQUFJLEVBQUUsR0FBRyxLQUFLLFNBQVM7WUFDdEIsRUFBRSxjQUFjO1lBQ2hCLGlCQUFpQjtZQUNqQixFQUFFLE1BQU0sQ0FBQyxJQUFJO1FBQ2Q7SUFDRDtJQUNBLFVBQVUsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDO1FBQzFELElBQUksRUFBRSxHQUFHLEtBQUssU0FBUztZQUN0QixFQUFFLGNBQWM7WUFDaEIsb0JBQW9CO1lBQ3BCLEVBQUUsTUFBTSxDQUFDLElBQUk7UUFDZDtJQUNEO0lBRUEsVUFBVSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsU0FBUztBQUNsRDtBQUVBLHNDQUFzQztBQUN0QyxTQUFTO0lBQ1IsNkJBQTZCO0lBQzdCO0FBQ0Q7QUFDQTs7Ozs7QUNsWUEseURBQWdCO0FBd0JoQix1REFBZ0I7QUF3QmhCLHFGQUFxRjtBQUNyRixzSEFBc0g7QUFFdEgsZ0JBQWdCO0FBRWhCLCtCQUErQjtBQUMvQixpQkFBaUI7QUFDakIsb0dBQW9HO0FBQ3BHLDBGQUEwRjtBQUMxRixVQUFVO0FBQ1Ysd0NBQXdDO0FBQ3hDLCtNQUErTTtBQUMvTSxjQUFjO0FBQ2QsU0FBUztBQUVULDRDQUE0QztBQUM1Qyx1RkFBdUY7QUFDdkYsaUVBQWlFO0FBQ2pFLGNBQWM7QUFDZCxlQUFlO0FBQ2YsWUFBWTtBQUNaLE1BQU07QUFDTixvQ0FBb0M7QUFDcEMsaUJBQWlCO0FBQ2pCLHNIQUFzSDtBQUN0SCxnRUFBZ0U7QUFDaEUsYUFBYTtBQUNiLG1FQUFtRTtBQUNuRSxrRUFBa0U7QUFDbEUsY0FBYztBQUVkLFVBQVU7QUFDVix3Q0FBd0M7QUFDeEMsdU9BQXVPO0FBQ3ZPLGNBQWM7QUFDZCxTQUFTO0FBQ1QsZUFBZTtBQUNmLFlBQVk7QUFDWixNQUFNO0FBQ04sWUFBWTtBQUNaLG9EQUFvRDtBQUNwRCxLQUFLO0FBRUwsbUJBQW1CO0FBQ25CLElBQUk7QUFFSixrREFBZ0I7QUE5RlQsU0FBUyxvQkFBb0IsRUFDbkMsSUFBSSxFQUNKLFNBQVMsRUFDVCxPQUFPLEVBQ1AsU0FBUyxFQUNULFVBQVUsRUFDVixnQkFBZ0IsRUFDaEIsTUFBTSxFQUFFLEVBQ1IsTUFBTSxFQUFFLEVBQ1IsT0FBTyxJQUFJLEVBQ1g7SUFDQSxPQUFPLENBQUM7b0JBQ1csRUFBRSxVQUFVLGtDQUFrQyxFQUFFLElBQUksRUFBRSxLQUFLLFFBQVEsRUFBRSxJQUFJLEVBQUUsS0FBSzt3QkFDNUUsRUFBRSxRQUFROzZCQUNMLEVBQUUsVUFBVSxNQUFNLEVBQUUsUUFBUSxTQUFTLEVBQUUsV0FBVyxlQUFlLEVBQUUsaUJBQWlCLHFFQUFxRSxFQUFFLElBQUksYUFBYSxFQUFFLElBQUk7Ozs7a0VBSTdJLEVBQUUsS0FBSzs7O2NBRzNELENBQUM7QUFDZjtBQUVPLFNBQVMsa0JBQWtCLEVBQ2pDLElBQUksRUFDSixTQUFTLEVBQ1QsT0FBTyxFQUNQLFNBQVMsRUFDVCxVQUFVLEVBQ1YsZ0JBQWdCLEVBQ2hCLE1BQU0sQ0FBQyxFQUNQLE1BQU0sRUFBRSxFQUNSLE9BQU8sSUFBSSxFQUNYO0lBQ0EsT0FBTyxDQUFDO29CQUNXLEVBQUUsVUFBVSxvREFBb0QsRUFBRSxJQUFJLEVBQUUsS0FBSyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUs7d0JBQzlGLEVBQUUsUUFBUTs7O2tFQUdnQyxFQUFFLEtBQUs7Ozs2QkFHNUMsRUFBRSxVQUFVLE1BQU0sRUFBRSxRQUFRLFNBQVMsRUFBRSxXQUFXLGVBQWUsRUFBRSxpQkFBaUIsNkZBQTZGLEVBQUUsSUFBSSxhQUFhLEVBQUUsSUFBSTs7Y0FFek4sQ0FBQztBQUNmO0FBZ0RPLFNBQVMsYUFBYSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEtBQUssRUFBRTtJQUM5RSxPQUFPLENBQUM7b0JBQ1csRUFBRSxHQUFHLHdDQUF3QyxFQUFFLFVBQVUsRUFBRSxFQUFFLFdBQVcsYUFBYSxHQUFHO1lBQ2hHLEVBQUUsUUFBUTs7Q0FFckIsQ0FBQztBQUNGIiwic291cmNlcyI6WyJub2RlX21vZHVsZXMvQHBhcmNlbC9ydW50aW1lLWJyb3dzZXItaG1yL2xpYi9ydW50aW1lLWVmOTFhZjE4YjkyYzA3NDQuanMiLCJzcmMvanMvY29udGVudC5qcyIsInNyYy9qcy9hcHAvZmxvYXRpbmdCdG4uanMiLCJub2RlX21vZHVsZXMvd2ViZXh0ZW5zaW9uLXBvbHlmaWxsL2Rpc3QvYnJvd3Nlci1wb2x5ZmlsbC5qcyIsInNyYy9qcy9hcHAvY29tcG9uZW50cy9pY29ucy5qcyIsIm5vZGVfbW9kdWxlcy9AcGFyY2VsL3RyYW5zZm9ybWVyLWpzL3NyYy9lc21vZHVsZS1oZWxwZXJzLmpzIiwic3JjL2pzL3V0aWxzL2hleFRvSFNMLmpzIiwic3JjL2pzL2FwcC9tYWluRm9udHMuanMiLCJzcmMvanMvYXBwL2NvbXBvbmVudHMvcmVuZGVyRm9udHMuanMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyIEhNUl9IT1NUID0gXCJsb2NhbGhvc3RcIjt2YXIgSE1SX1BPUlQgPSAxMjM0O3ZhciBITVJfU0VDVVJFID0gZmFsc2U7dmFyIEhNUl9FTlZfSEFTSCA9IFwiZGRmNmUwNzI0YmQzNThiZFwiO3ZhciBITVJfVVNFX1NTRSA9IGZhbHNlO21vZHVsZS5idW5kbGUuSE1SX0JVTkRMRV9JRCA9IFwiNTljOTg4N2QxMjczMDY0N1wiO1widXNlIHN0cmljdFwiO1xuXG4vKiBnbG9iYWwgSE1SX0hPU1QsIEhNUl9QT1JULCBITVJfRU5WX0hBU0gsIEhNUl9TRUNVUkUsIEhNUl9VU0VfU1NFLCBjaHJvbWUsIGJyb3dzZXIsIF9fcGFyY2VsX19pbXBvcnRfXywgX19wYXJjZWxfX2ltcG9ydFNjcmlwdHNfXywgU2VydmljZVdvcmtlckdsb2JhbFNjb3BlICovXG4vKjo6XG5pbXBvcnQgdHlwZSB7XG4gIEhNUkFzc2V0LFxuICBITVJNZXNzYWdlLFxufSBmcm9tICdAcGFyY2VsL3JlcG9ydGVyLWRldi1zZXJ2ZXIvc3JjL0hNUlNlcnZlci5qcyc7XG5pbnRlcmZhY2UgUGFyY2VsUmVxdWlyZSB7XG4gIChzdHJpbmcpOiBtaXhlZDtcbiAgY2FjaGU6IHt8W3N0cmluZ106IFBhcmNlbE1vZHVsZXx9O1xuICBob3REYXRhOiB7fFtzdHJpbmddOiBtaXhlZHx9O1xuICBNb2R1bGU6IGFueTtcbiAgcGFyZW50OiA/UGFyY2VsUmVxdWlyZTtcbiAgaXNQYXJjZWxSZXF1aXJlOiB0cnVlO1xuICBtb2R1bGVzOiB7fFtzdHJpbmddOiBbRnVuY3Rpb24sIHt8W3N0cmluZ106IHN0cmluZ3x9XXx9O1xuICBITVJfQlVORExFX0lEOiBzdHJpbmc7XG4gIHJvb3Q6IFBhcmNlbFJlcXVpcmU7XG59XG5pbnRlcmZhY2UgUGFyY2VsTW9kdWxlIHtcbiAgaG90OiB7fFxuICAgIGRhdGE6IG1peGVkLFxuICAgIGFjY2VwdChjYjogKEZ1bmN0aW9uKSA9PiB2b2lkKTogdm9pZCxcbiAgICBkaXNwb3NlKGNiOiAobWl4ZWQpID0+IHZvaWQpOiB2b2lkLFxuICAgIC8vIGFjY2VwdChkZXBzOiBBcnJheTxzdHJpbmc+IHwgc3RyaW5nLCBjYjogKEZ1bmN0aW9uKSA9PiB2b2lkKTogdm9pZCxcbiAgICAvLyBkZWNsaW5lKCk6IHZvaWQsXG4gICAgX2FjY2VwdENhbGxiYWNrczogQXJyYXk8KEZ1bmN0aW9uKSA9PiB2b2lkPixcbiAgICBfZGlzcG9zZUNhbGxiYWNrczogQXJyYXk8KG1peGVkKSA9PiB2b2lkPixcbiAgfH07XG59XG5pbnRlcmZhY2UgRXh0ZW5zaW9uQ29udGV4dCB7XG4gIHJ1bnRpbWU6IHt8XG4gICAgcmVsb2FkKCk6IHZvaWQsXG4gICAgZ2V0VVJMKHVybDogc3RyaW5nKTogc3RyaW5nO1xuICAgIGdldE1hbmlmZXN0KCk6IHttYW5pZmVzdF92ZXJzaW9uOiBudW1iZXIsIC4uLn07XG4gIHx9O1xufVxuZGVjbGFyZSB2YXIgbW9kdWxlOiB7YnVuZGxlOiBQYXJjZWxSZXF1aXJlLCAuLi59O1xuZGVjbGFyZSB2YXIgSE1SX0hPU1Q6IHN0cmluZztcbmRlY2xhcmUgdmFyIEhNUl9QT1JUOiBzdHJpbmc7XG5kZWNsYXJlIHZhciBITVJfRU5WX0hBU0g6IHN0cmluZztcbmRlY2xhcmUgdmFyIEhNUl9TRUNVUkU6IGJvb2xlYW47XG5kZWNsYXJlIHZhciBITVJfVVNFX1NTRTogYm9vbGVhbjtcbmRlY2xhcmUgdmFyIGNocm9tZTogRXh0ZW5zaW9uQ29udGV4dDtcbmRlY2xhcmUgdmFyIGJyb3dzZXI6IEV4dGVuc2lvbkNvbnRleHQ7XG5kZWNsYXJlIHZhciBfX3BhcmNlbF9faW1wb3J0X186IChzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XG5kZWNsYXJlIHZhciBfX3BhcmNlbF9faW1wb3J0U2NyaXB0c19fOiAoc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+O1xuZGVjbGFyZSB2YXIgZ2xvYmFsVGhpczogdHlwZW9mIHNlbGY7XG5kZWNsYXJlIHZhciBTZXJ2aWNlV29ya2VyR2xvYmFsU2NvcGU6IE9iamVjdDtcbiovXG52YXIgT1ZFUkxBWV9JRCA9ICdfX3BhcmNlbF9fZXJyb3JfX292ZXJsYXlfXyc7XG52YXIgT2xkTW9kdWxlID0gbW9kdWxlLmJ1bmRsZS5Nb2R1bGU7XG5mdW5jdGlvbiBNb2R1bGUobW9kdWxlTmFtZSkge1xuICBPbGRNb2R1bGUuY2FsbCh0aGlzLCBtb2R1bGVOYW1lKTtcbiAgdGhpcy5ob3QgPSB7XG4gICAgZGF0YTogbW9kdWxlLmJ1bmRsZS5ob3REYXRhW21vZHVsZU5hbWVdLFxuICAgIF9hY2NlcHRDYWxsYmFja3M6IFtdLFxuICAgIF9kaXNwb3NlQ2FsbGJhY2tzOiBbXSxcbiAgICBhY2NlcHQ6IGZ1bmN0aW9uIChmbikge1xuICAgICAgdGhpcy5fYWNjZXB0Q2FsbGJhY2tzLnB1c2goZm4gfHwgZnVuY3Rpb24gKCkge30pO1xuICAgIH0sXG4gICAgZGlzcG9zZTogZnVuY3Rpb24gKGZuKSB7XG4gICAgICB0aGlzLl9kaXNwb3NlQ2FsbGJhY2tzLnB1c2goZm4pO1xuICAgIH1cbiAgfTtcbiAgbW9kdWxlLmJ1bmRsZS5ob3REYXRhW21vZHVsZU5hbWVdID0gdW5kZWZpbmVkO1xufVxubW9kdWxlLmJ1bmRsZS5Nb2R1bGUgPSBNb2R1bGU7XG5tb2R1bGUuYnVuZGxlLmhvdERhdGEgPSB7fTtcbnZhciBjaGVja2VkQXNzZXRzIC8qOiB7fFtzdHJpbmddOiBib29sZWFufH0gKi8sIGFzc2V0c1RvRGlzcG9zZSAvKjogQXJyYXk8W1BhcmNlbFJlcXVpcmUsIHN0cmluZ10+ICovLCBhc3NldHNUb0FjY2VwdCAvKjogQXJyYXk8W1BhcmNlbFJlcXVpcmUsIHN0cmluZ10+ICovO1xuXG5mdW5jdGlvbiBnZXRIb3N0bmFtZSgpIHtcbiAgcmV0dXJuIEhNUl9IT1NUIHx8IChsb2NhdGlvbi5wcm90b2NvbC5pbmRleE9mKCdodHRwJykgPT09IDAgPyBsb2NhdGlvbi5ob3N0bmFtZSA6ICdsb2NhbGhvc3QnKTtcbn1cbmZ1bmN0aW9uIGdldFBvcnQoKSB7XG4gIHJldHVybiBITVJfUE9SVCB8fCBsb2NhdGlvbi5wb3J0O1xufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVkZWNsYXJlXG52YXIgcGFyZW50ID0gbW9kdWxlLmJ1bmRsZS5wYXJlbnQ7XG5pZiAoKCFwYXJlbnQgfHwgIXBhcmVudC5pc1BhcmNlbFJlcXVpcmUpICYmIHR5cGVvZiBXZWJTb2NrZXQgIT09ICd1bmRlZmluZWQnKSB7XG4gIHZhciBob3N0bmFtZSA9IGdldEhvc3RuYW1lKCk7XG4gIHZhciBwb3J0ID0gZ2V0UG9ydCgpO1xuICB2YXIgcHJvdG9jb2wgPSBITVJfU0VDVVJFIHx8IGxvY2F0aW9uLnByb3RvY29sID09ICdodHRwczonICYmICFbJ2xvY2FsaG9zdCcsICcxMjcuMC4wLjEnLCAnMC4wLjAuMCddLmluY2x1ZGVzKGhvc3RuYW1lKSA/ICd3c3MnIDogJ3dzJztcbiAgdmFyIHdzO1xuICBpZiAoSE1SX1VTRV9TU0UpIHtcbiAgICB3cyA9IG5ldyBFdmVudFNvdXJjZSgnL19fcGFyY2VsX2htcicpO1xuICB9IGVsc2Uge1xuICAgIHRyeSB7XG4gICAgICB3cyA9IG5ldyBXZWJTb2NrZXQocHJvdG9jb2wgKyAnOi8vJyArIGhvc3RuYW1lICsgKHBvcnQgPyAnOicgKyBwb3J0IDogJycpICsgJy8nKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIubWVzc2FnZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVyci5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICAgIHdzID0ge307XG4gICAgfVxuICB9XG5cbiAgLy8gV2ViIGV4dGVuc2lvbiBjb250ZXh0XG4gIHZhciBleHRDdHggPSB0eXBlb2YgYnJvd3NlciA9PT0gJ3VuZGVmaW5lZCcgPyB0eXBlb2YgY2hyb21lID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiBjaHJvbWUgOiBicm93c2VyO1xuXG4gIC8vIFNhZmFyaSBkb2Vzbid0IHN1cHBvcnQgc291cmNlVVJMIGluIGVycm9yIHN0YWNrcy5cbiAgLy8gZXZhbCBtYXkgYWxzbyBiZSBkaXNhYmxlZCB2aWEgQ1NQLCBzbyBkbyBhIHF1aWNrIGNoZWNrLlxuICB2YXIgc3VwcG9ydHNTb3VyY2VVUkwgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICAoMCwgZXZhbCkoJ3Rocm93IG5ldyBFcnJvcihcInRlc3RcIik7IC8vIyBzb3VyY2VVUkw9dGVzdC5qcycpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBzdXBwb3J0c1NvdXJjZVVSTCA9IGVyci5zdGFjay5pbmNsdWRlcygndGVzdC5qcycpO1xuICB9XG5cbiAgLy8gJEZsb3dGaXhNZVxuICB3cy5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbiAoZXZlbnQgLyo6IHtkYXRhOiBzdHJpbmcsIC4uLn0gKi8pIHtcbiAgICBjaGVja2VkQXNzZXRzID0ge30gLyo6IHt8W3N0cmluZ106IGJvb2xlYW58fSAqLztcbiAgICBhc3NldHNUb0FjY2VwdCA9IFtdO1xuICAgIGFzc2V0c1RvRGlzcG9zZSA9IFtdO1xuICAgIHZhciBkYXRhIC8qOiBITVJNZXNzYWdlICovID0gSlNPTi5wYXJzZShldmVudC5kYXRhKTtcbiAgICBpZiAoZGF0YS50eXBlID09PSAndXBkYXRlJykge1xuICAgICAgLy8gUmVtb3ZlIGVycm9yIG92ZXJsYXkgaWYgdGhlcmUgaXMgb25lXG4gICAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZW1vdmVFcnJvck92ZXJsYXkoKTtcbiAgICAgIH1cbiAgICAgIGxldCBhc3NldHMgPSBkYXRhLmFzc2V0cy5maWx0ZXIoYXNzZXQgPT4gYXNzZXQuZW52SGFzaCA9PT0gSE1SX0VOVl9IQVNIKTtcblxuICAgICAgLy8gSGFuZGxlIEhNUiBVcGRhdGVcbiAgICAgIGxldCBoYW5kbGVkID0gYXNzZXRzLmV2ZXJ5KGFzc2V0ID0+IHtcbiAgICAgICAgcmV0dXJuIGFzc2V0LnR5cGUgPT09ICdjc3MnIHx8IGFzc2V0LnR5cGUgPT09ICdqcycgJiYgaG1yQWNjZXB0Q2hlY2sobW9kdWxlLmJ1bmRsZS5yb290LCBhc3NldC5pZCwgYXNzZXQuZGVwc0J5QnVuZGxlKTtcbiAgICAgIH0pO1xuICAgICAgaWYgKGhhbmRsZWQpIHtcbiAgICAgICAgY29uc29sZS5jbGVhcigpO1xuXG4gICAgICAgIC8vIERpc3BhdGNoIGN1c3RvbSBldmVudCBzbyBvdGhlciBydW50aW1lcyAoZS5nIFJlYWN0IFJlZnJlc2gpIGFyZSBhd2FyZS5cbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBDdXN0b21FdmVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ3BhcmNlbGhtcmFjY2VwdCcpKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCBobXJBcHBseVVwZGF0ZXMoYXNzZXRzKTtcblxuICAgICAgICAvLyBEaXNwb3NlIGFsbCBvbGQgYXNzZXRzLlxuICAgICAgICBsZXQgcHJvY2Vzc2VkQXNzZXRzID0ge30gLyo6IHt8W3N0cmluZ106IGJvb2xlYW58fSAqLztcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhc3NldHNUb0Rpc3Bvc2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBsZXQgaWQgPSBhc3NldHNUb0Rpc3Bvc2VbaV1bMV07XG4gICAgICAgICAgaWYgKCFwcm9jZXNzZWRBc3NldHNbaWRdKSB7XG4gICAgICAgICAgICBobXJEaXNwb3NlKGFzc2V0c1RvRGlzcG9zZVtpXVswXSwgaWQpO1xuICAgICAgICAgICAgcHJvY2Vzc2VkQXNzZXRzW2lkXSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gUnVuIGFjY2VwdCBjYWxsYmFja3MuIFRoaXMgd2lsbCBhbHNvIHJlLWV4ZWN1dGUgb3RoZXIgZGlzcG9zZWQgYXNzZXRzIGluIHRvcG9sb2dpY2FsIG9yZGVyLlxuICAgICAgICBwcm9jZXNzZWRBc3NldHMgPSB7fTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhc3NldHNUb0FjY2VwdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGxldCBpZCA9IGFzc2V0c1RvQWNjZXB0W2ldWzFdO1xuICAgICAgICAgIGlmICghcHJvY2Vzc2VkQXNzZXRzW2lkXSkge1xuICAgICAgICAgICAgaG1yQWNjZXB0KGFzc2V0c1RvQWNjZXB0W2ldWzBdLCBpZCk7XG4gICAgICAgICAgICBwcm9jZXNzZWRBc3NldHNbaWRdID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBmdWxsUmVsb2FkKCk7XG4gICAgfVxuICAgIGlmIChkYXRhLnR5cGUgPT09ICdlcnJvcicpIHtcbiAgICAgIC8vIExvZyBwYXJjZWwgZXJyb3JzIHRvIGNvbnNvbGVcbiAgICAgIGZvciAobGV0IGFuc2lEaWFnbm9zdGljIG9mIGRhdGEuZGlhZ25vc3RpY3MuYW5zaSkge1xuICAgICAgICBsZXQgc3RhY2sgPSBhbnNpRGlhZ25vc3RpYy5jb2RlZnJhbWUgPyBhbnNpRGlhZ25vc3RpYy5jb2RlZnJhbWUgOiBhbnNpRGlhZ25vc3RpYy5zdGFjaztcbiAgICAgICAgY29uc29sZS5lcnJvcign8J+aqCBbcGFyY2VsXTogJyArIGFuc2lEaWFnbm9zdGljLm1lc3NhZ2UgKyAnXFxuJyArIHN0YWNrICsgJ1xcblxcbicgKyBhbnNpRGlhZ25vc3RpYy5oaW50cy5qb2luKCdcXG4nKSk7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAvLyBSZW5kZXIgdGhlIGZhbmN5IGh0bWwgb3ZlcmxheVxuICAgICAgICByZW1vdmVFcnJvck92ZXJsYXkoKTtcbiAgICAgICAgdmFyIG92ZXJsYXkgPSBjcmVhdGVFcnJvck92ZXJsYXkoZGF0YS5kaWFnbm9zdGljcy5odG1sKTtcbiAgICAgICAgLy8gJEZsb3dGaXhNZVxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG92ZXJsYXkpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgaWYgKHdzIGluc3RhbmNlb2YgV2ViU29ja2V0KSB7XG4gICAgd3Mub25lcnJvciA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICBpZiAoZS5tZXNzYWdlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZS5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdzLm9uY2xvc2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ1twYXJjZWxdIPCfmqggQ29ubmVjdGlvbiB0byB0aGUgSE1SIHNlcnZlciB3YXMgbG9zdCcpO1xuICAgIH07XG4gIH1cbn1cbmZ1bmN0aW9uIHJlbW92ZUVycm9yT3ZlcmxheSgpIHtcbiAgdmFyIG92ZXJsYXkgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChPVkVSTEFZX0lEKTtcbiAgaWYgKG92ZXJsYXkpIHtcbiAgICBvdmVybGF5LnJlbW92ZSgpO1xuICAgIGNvbnNvbGUubG9nKCdbcGFyY2VsXSDinKggRXJyb3IgcmVzb2x2ZWQnKTtcbiAgfVxufVxuZnVuY3Rpb24gY3JlYXRlRXJyb3JPdmVybGF5KGRpYWdub3N0aWNzKSB7XG4gIHZhciBvdmVybGF5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIG92ZXJsYXkuaWQgPSBPVkVSTEFZX0lEO1xuICBsZXQgZXJyb3JIVE1MID0gJzxkaXYgc3R5bGU9XCJiYWNrZ3JvdW5kOiBibGFjazsgb3BhY2l0eTogMC44NTsgZm9udC1zaXplOiAxNnB4OyBjb2xvcjogd2hpdGU7IHBvc2l0aW9uOiBmaXhlZDsgaGVpZ2h0OiAxMDAlOyB3aWR0aDogMTAwJTsgdG9wOiAwcHg7IGxlZnQ6IDBweDsgcGFkZGluZzogMzBweDsgZm9udC1mYW1pbHk6IE1lbmxvLCBDb25zb2xhcywgbW9ub3NwYWNlOyB6LWluZGV4OiA5OTk5O1wiPic7XG4gIGZvciAobGV0IGRpYWdub3N0aWMgb2YgZGlhZ25vc3RpY3MpIHtcbiAgICBsZXQgc3RhY2sgPSBkaWFnbm9zdGljLmZyYW1lcy5sZW5ndGggPyBkaWFnbm9zdGljLmZyYW1lcy5yZWR1Y2UoKHAsIGZyYW1lKSA9PiB7XG4gICAgICByZXR1cm4gYCR7cH1cbjxhIGhyZWY9XCIvX19wYXJjZWxfbGF1bmNoX2VkaXRvcj9maWxlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGZyYW1lLmxvY2F0aW9uKX1cIiBzdHlsZT1cInRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lOyBjb2xvcjogIzg4OFwiIG9uY2xpY2s9XCJmZXRjaCh0aGlzLmhyZWYpOyByZXR1cm4gZmFsc2VcIj4ke2ZyYW1lLmxvY2F0aW9ufTwvYT5cbiR7ZnJhbWUuY29kZX1gO1xuICAgIH0sICcnKSA6IGRpYWdub3N0aWMuc3RhY2s7XG4gICAgZXJyb3JIVE1MICs9IGBcbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6IDE4cHg7IGZvbnQtd2VpZ2h0OiBib2xkOyBtYXJnaW4tdG9wOiAyMHB4O1wiPlxuICAgICAgICAgIPCfmqggJHtkaWFnbm9zdGljLm1lc3NhZ2V9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8cHJlPiR7c3RhY2t9PC9wcmU+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgJHtkaWFnbm9zdGljLmhpbnRzLm1hcChoaW50ID0+ICc8ZGl2PvCfkqEgJyArIGhpbnQgKyAnPC9kaXY+Jykuam9pbignJyl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICAke2RpYWdub3N0aWMuZG9jdW1lbnRhdGlvbiA/IGA8ZGl2PvCfk50gPGEgc3R5bGU9XCJjb2xvcjogdmlvbGV0XCIgaHJlZj1cIiR7ZGlhZ25vc3RpYy5kb2N1bWVudGF0aW9ufVwiIHRhcmdldD1cIl9ibGFua1wiPkxlYXJuIG1vcmU8L2E+PC9kaXY+YCA6ICcnfVxuICAgICAgPC9kaXY+XG4gICAgYDtcbiAgfVxuICBlcnJvckhUTUwgKz0gJzwvZGl2Pic7XG4gIG92ZXJsYXkuaW5uZXJIVE1MID0gZXJyb3JIVE1MO1xuICByZXR1cm4gb3ZlcmxheTtcbn1cbmZ1bmN0aW9uIGZ1bGxSZWxvYWQoKSB7XG4gIGlmICgncmVsb2FkJyBpbiBsb2NhdGlvbikge1xuICAgIGxvY2F0aW9uLnJlbG9hZCgpO1xuICB9IGVsc2UgaWYgKGV4dEN0eCAmJiBleHRDdHgucnVudGltZSAmJiBleHRDdHgucnVudGltZS5yZWxvYWQpIHtcbiAgICBleHRDdHgucnVudGltZS5yZWxvYWQoKTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0UGFyZW50cyhidW5kbGUsIGlkKSAvKjogQXJyYXk8W1BhcmNlbFJlcXVpcmUsIHN0cmluZ10+ICove1xuICB2YXIgbW9kdWxlcyA9IGJ1bmRsZS5tb2R1bGVzO1xuICBpZiAoIW1vZHVsZXMpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgdmFyIHBhcmVudHMgPSBbXTtcbiAgdmFyIGssIGQsIGRlcDtcbiAgZm9yIChrIGluIG1vZHVsZXMpIHtcbiAgICBmb3IgKGQgaW4gbW9kdWxlc1trXVsxXSkge1xuICAgICAgZGVwID0gbW9kdWxlc1trXVsxXVtkXTtcbiAgICAgIGlmIChkZXAgPT09IGlkIHx8IEFycmF5LmlzQXJyYXkoZGVwKSAmJiBkZXBbZGVwLmxlbmd0aCAtIDFdID09PSBpZCkge1xuICAgICAgICBwYXJlbnRzLnB1c2goW2J1bmRsZSwga10pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoYnVuZGxlLnBhcmVudCkge1xuICAgIHBhcmVudHMgPSBwYXJlbnRzLmNvbmNhdChnZXRQYXJlbnRzKGJ1bmRsZS5wYXJlbnQsIGlkKSk7XG4gIH1cbiAgcmV0dXJuIHBhcmVudHM7XG59XG5mdW5jdGlvbiB1cGRhdGVMaW5rKGxpbmspIHtcbiAgdmFyIGhyZWYgPSBsaW5rLmdldEF0dHJpYnV0ZSgnaHJlZicpO1xuICBpZiAoIWhyZWYpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgdmFyIG5ld0xpbmsgPSBsaW5rLmNsb25lTm9kZSgpO1xuICBuZXdMaW5rLm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAobGluay5wYXJlbnROb2RlICE9PSBudWxsKSB7XG4gICAgICAvLyAkRmxvd0ZpeE1lXG4gICAgICBsaW5rLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQobGluayk7XG4gICAgfVxuICB9O1xuICBuZXdMaW5rLnNldEF0dHJpYnV0ZSgnaHJlZicsXG4gIC8vICRGbG93Rml4TWVcbiAgaHJlZi5zcGxpdCgnPycpWzBdICsgJz8nICsgRGF0ZS5ub3coKSk7XG4gIC8vICRGbG93Rml4TWVcbiAgbGluay5wYXJlbnROb2RlLmluc2VydEJlZm9yZShuZXdMaW5rLCBsaW5rLm5leHRTaWJsaW5nKTtcbn1cbnZhciBjc3NUaW1lb3V0ID0gbnVsbDtcbmZ1bmN0aW9uIHJlbG9hZENTUygpIHtcbiAgaWYgKGNzc1RpbWVvdXQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY3NzVGltZW91dCA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgIHZhciBsaW5rcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2xpbmtbcmVsPVwic3R5bGVzaGVldFwiXScpO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGlua3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIC8vICRGbG93Rml4TWVbaW5jb21wYXRpYmxlLXR5cGVdXG4gICAgICB2YXIgaHJlZiAvKjogc3RyaW5nICovID0gbGlua3NbaV0uZ2V0QXR0cmlidXRlKCdocmVmJyk7XG4gICAgICB2YXIgaG9zdG5hbWUgPSBnZXRIb3N0bmFtZSgpO1xuICAgICAgdmFyIHNlcnZlZEZyb21ITVJTZXJ2ZXIgPSBob3N0bmFtZSA9PT0gJ2xvY2FsaG9zdCcgPyBuZXcgUmVnRXhwKCdeKGh0dHBzPzpcXFxcL1xcXFwvKDAuMC4wLjB8MTI3LjAuMC4xKXxsb2NhbGhvc3QpOicgKyBnZXRQb3J0KCkpLnRlc3QoaHJlZikgOiBocmVmLmluZGV4T2YoaG9zdG5hbWUgKyAnOicgKyBnZXRQb3J0KCkpO1xuICAgICAgdmFyIGFic29sdXRlID0gL15odHRwcz86XFwvXFwvL2kudGVzdChocmVmKSAmJiBocmVmLmluZGV4T2YobG9jYXRpb24ub3JpZ2luKSAhPT0gMCAmJiAhc2VydmVkRnJvbUhNUlNlcnZlcjtcbiAgICAgIGlmICghYWJzb2x1dGUpIHtcbiAgICAgICAgdXBkYXRlTGluayhsaW5rc1tpXSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNzc1RpbWVvdXQgPSBudWxsO1xuICB9LCA1MCk7XG59XG5mdW5jdGlvbiBobXJEb3dubG9hZChhc3NldCkge1xuICBpZiAoYXNzZXQudHlwZSA9PT0gJ2pzJykge1xuICAgIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBsZXQgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gICAgICBzY3JpcHQuc3JjID0gYXNzZXQudXJsICsgJz90PScgKyBEYXRlLm5vdygpO1xuICAgICAgaWYgKGFzc2V0Lm91dHB1dEZvcm1hdCA9PT0gJ2VzbW9kdWxlJykge1xuICAgICAgICBzY3JpcHQudHlwZSA9ICdtb2R1bGUnO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgdmFyIF9kb2N1bWVudCRoZWFkO1xuICAgICAgICBzY3JpcHQub25sb2FkID0gKCkgPT4gcmVzb2x2ZShzY3JpcHQpO1xuICAgICAgICBzY3JpcHQub25lcnJvciA9IHJlamVjdDtcbiAgICAgICAgKF9kb2N1bWVudCRoZWFkID0gZG9jdW1lbnQuaGVhZCkgPT09IG51bGwgfHwgX2RvY3VtZW50JGhlYWQgPT09IHZvaWQgMCB8fCBfZG9jdW1lbnQkaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgaW1wb3J0U2NyaXB0cyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgLy8gV29ya2VyIHNjcmlwdHNcbiAgICAgIGlmIChhc3NldC5vdXRwdXRGb3JtYXQgPT09ICdlc21vZHVsZScpIHtcbiAgICAgICAgcmV0dXJuIF9fcGFyY2VsX19pbXBvcnRfXyhhc3NldC51cmwgKyAnP3Q9JyArIERhdGUubm93KCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgX19wYXJjZWxfX2ltcG9ydFNjcmlwdHNfXyhhc3NldC51cmwgKyAnP3Q9JyArIERhdGUubm93KCkpO1xuICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGhtckFwcGx5VXBkYXRlcyhhc3NldHMpIHtcbiAgZ2xvYmFsLnBhcmNlbEhvdFVwZGF0ZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCBzY3JpcHRzVG9SZW1vdmU7XG4gIHRyeSB7XG4gICAgLy8gSWYgc291cmNlVVJMIGNvbW1lbnRzIGFyZW4ndCBzdXBwb3J0ZWQgaW4gZXZhbCwgd2UgbmVlZCB0byBsb2FkXG4gICAgLy8gdGhlIHVwZGF0ZSBmcm9tIHRoZSBkZXYgc2VydmVyIG92ZXIgSFRUUCBzbyB0aGF0IHN0YWNrIHRyYWNlc1xuICAgIC8vIGFyZSBjb3JyZWN0IGluIGVycm9ycy9sb2dzLiBUaGlzIGlzIG11Y2ggc2xvd2VyIHRoYW4gZXZhbCwgc29cbiAgICAvLyB3ZSBvbmx5IGRvIGl0IGlmIG5lZWRlZCAoY3VycmVudGx5IGp1c3QgU2FmYXJpKS5cbiAgICAvLyBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTM3Mjk3XG4gICAgLy8gVGhpcyBwYXRoIGlzIGFsc28gdGFrZW4gaWYgYSBDU1AgZGlzYWxsb3dzIGV2YWwuXG4gICAgaWYgKCFzdXBwb3J0c1NvdXJjZVVSTCkge1xuICAgICAgbGV0IHByb21pc2VzID0gYXNzZXRzLm1hcChhc3NldCA9PiB7XG4gICAgICAgIHZhciBfaG1yRG93bmxvYWQ7XG4gICAgICAgIHJldHVybiAoX2htckRvd25sb2FkID0gaG1yRG93bmxvYWQoYXNzZXQpKSA9PT0gbnVsbCB8fCBfaG1yRG93bmxvYWQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9obXJEb3dubG9hZC5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgIC8vIFdlYiBleHRlbnNpb24gZml4XG4gICAgICAgICAgaWYgKGV4dEN0eCAmJiBleHRDdHgucnVudGltZSAmJiBleHRDdHgucnVudGltZS5nZXRNYW5pZmVzdCgpLm1hbmlmZXN0X3ZlcnNpb24gPT0gMyAmJiB0eXBlb2YgU2VydmljZVdvcmtlckdsb2JhbFNjb3BlICE9ICd1bmRlZmluZWQnICYmIGdsb2JhbCBpbnN0YW5jZW9mIFNlcnZpY2VXb3JrZXJHbG9iYWxTY29wZSkge1xuICAgICAgICAgICAgZXh0Q3R4LnJ1bnRpbWUucmVsb2FkKCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIHNjcmlwdHNUb1JlbW92ZSA9IGF3YWl0IFByb21pc2UuYWxsKHByb21pc2VzKTtcbiAgICB9XG4gICAgYXNzZXRzLmZvckVhY2goZnVuY3Rpb24gKGFzc2V0KSB7XG4gICAgICBobXJBcHBseShtb2R1bGUuYnVuZGxlLnJvb3QsIGFzc2V0KTtcbiAgICB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBkZWxldGUgZ2xvYmFsLnBhcmNlbEhvdFVwZGF0ZTtcbiAgICBpZiAoc2NyaXB0c1RvUmVtb3ZlKSB7XG4gICAgICBzY3JpcHRzVG9SZW1vdmUuZm9yRWFjaChzY3JpcHQgPT4ge1xuICAgICAgICBpZiAoc2NyaXB0KSB7XG4gICAgICAgICAgdmFyIF9kb2N1bWVudCRoZWFkMjtcbiAgICAgICAgICAoX2RvY3VtZW50JGhlYWQyID0gZG9jdW1lbnQuaGVhZCkgPT09IG51bGwgfHwgX2RvY3VtZW50JGhlYWQyID09PSB2b2lkIDAgfHwgX2RvY3VtZW50JGhlYWQyLnJlbW92ZUNoaWxkKHNjcmlwdCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gaG1yQXBwbHkoYnVuZGxlIC8qOiBQYXJjZWxSZXF1aXJlICovLCBhc3NldCAvKjogIEhNUkFzc2V0ICovKSB7XG4gIHZhciBtb2R1bGVzID0gYnVuZGxlLm1vZHVsZXM7XG4gIGlmICghbW9kdWxlcykge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoYXNzZXQudHlwZSA9PT0gJ2NzcycpIHtcbiAgICByZWxvYWRDU1MoKTtcbiAgfSBlbHNlIGlmIChhc3NldC50eXBlID09PSAnanMnKSB7XG4gICAgbGV0IGRlcHMgPSBhc3NldC5kZXBzQnlCdW5kbGVbYnVuZGxlLkhNUl9CVU5ETEVfSURdO1xuICAgIGlmIChkZXBzKSB7XG4gICAgICBpZiAobW9kdWxlc1thc3NldC5pZF0pIHtcbiAgICAgICAgLy8gUmVtb3ZlIGRlcGVuZGVuY2llcyB0aGF0IGFyZSByZW1vdmVkIGFuZCB3aWxsIGJlY29tZSBvcnBoYW5lZC5cbiAgICAgICAgLy8gVGhpcyBpcyBuZWNlc3Nhcnkgc28gdGhhdCBpZiB0aGUgYXNzZXQgaXMgYWRkZWQgYmFjayBhZ2FpbiwgdGhlIGNhY2hlIGlzIGdvbmUsIGFuZCB3ZSBwcmV2ZW50IGEgZnVsbCBwYWdlIHJlbG9hZC5cbiAgICAgICAgbGV0IG9sZERlcHMgPSBtb2R1bGVzW2Fzc2V0LmlkXVsxXTtcbiAgICAgICAgZm9yIChsZXQgZGVwIGluIG9sZERlcHMpIHtcbiAgICAgICAgICBpZiAoIWRlcHNbZGVwXSB8fCBkZXBzW2RlcF0gIT09IG9sZERlcHNbZGVwXSkge1xuICAgICAgICAgICAgbGV0IGlkID0gb2xkRGVwc1tkZXBdO1xuICAgICAgICAgICAgbGV0IHBhcmVudHMgPSBnZXRQYXJlbnRzKG1vZHVsZS5idW5kbGUucm9vdCwgaWQpO1xuICAgICAgICAgICAgaWYgKHBhcmVudHMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgIGhtckRlbGV0ZShtb2R1bGUuYnVuZGxlLnJvb3QsIGlkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzdXBwb3J0c1NvdXJjZVVSTCkge1xuICAgICAgICAvLyBHbG9iYWwgZXZhbC4gV2Ugd291bGQgdXNlIGBuZXcgRnVuY3Rpb25gIGhlcmUgYnV0IGJyb3dzZXJcbiAgICAgICAgLy8gc3VwcG9ydCBmb3Igc291cmNlIG1hcHMgaXMgYmV0dGVyIHdpdGggZXZhbC5cbiAgICAgICAgKDAsIGV2YWwpKGFzc2V0Lm91dHB1dCk7XG4gICAgICB9XG5cbiAgICAgIC8vICRGbG93Rml4TWVcbiAgICAgIGxldCBmbiA9IGdsb2JhbC5wYXJjZWxIb3RVcGRhdGVbYXNzZXQuaWRdO1xuICAgICAgbW9kdWxlc1thc3NldC5pZF0gPSBbZm4sIGRlcHNdO1xuICAgIH0gZWxzZSBpZiAoYnVuZGxlLnBhcmVudCkge1xuICAgICAgaG1yQXBwbHkoYnVuZGxlLnBhcmVudCwgYXNzZXQpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gaG1yRGVsZXRlKGJ1bmRsZSwgaWQpIHtcbiAgbGV0IG1vZHVsZXMgPSBidW5kbGUubW9kdWxlcztcbiAgaWYgKCFtb2R1bGVzKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChtb2R1bGVzW2lkXSkge1xuICAgIC8vIENvbGxlY3QgZGVwZW5kZW5jaWVzIHRoYXQgd2lsbCBiZWNvbWUgb3JwaGFuZWQgd2hlbiB0aGlzIG1vZHVsZSBpcyBkZWxldGVkLlxuICAgIGxldCBkZXBzID0gbW9kdWxlc1tpZF1bMV07XG4gICAgbGV0IG9ycGhhbnMgPSBbXTtcbiAgICBmb3IgKGxldCBkZXAgaW4gZGVwcykge1xuICAgICAgbGV0IHBhcmVudHMgPSBnZXRQYXJlbnRzKG1vZHVsZS5idW5kbGUucm9vdCwgZGVwc1tkZXBdKTtcbiAgICAgIGlmIChwYXJlbnRzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICBvcnBoYW5zLnB1c2goZGVwc1tkZXBdKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBEZWxldGUgdGhlIG1vZHVsZS4gVGhpcyBtdXN0IGJlIGRvbmUgYmVmb3JlIGRlbGV0aW5nIGRlcGVuZGVuY2llcyBpbiBjYXNlIG9mIGNpcmN1bGFyIGRlcGVuZGVuY2llcy5cbiAgICBkZWxldGUgbW9kdWxlc1tpZF07XG4gICAgZGVsZXRlIGJ1bmRsZS5jYWNoZVtpZF07XG5cbiAgICAvLyBOb3cgZGVsZXRlIHRoZSBvcnBoYW5zLlxuICAgIG9ycGhhbnMuZm9yRWFjaChpZCA9PiB7XG4gICAgICBobXJEZWxldGUobW9kdWxlLmJ1bmRsZS5yb290LCBpZCk7XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAoYnVuZGxlLnBhcmVudCkge1xuICAgIGhtckRlbGV0ZShidW5kbGUucGFyZW50LCBpZCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGhtckFjY2VwdENoZWNrKGJ1bmRsZSAvKjogUGFyY2VsUmVxdWlyZSAqLywgaWQgLyo6IHN0cmluZyAqLywgZGVwc0J5QnVuZGxlIC8qOiA/eyBbc3RyaW5nXTogeyBbc3RyaW5nXTogc3RyaW5nIH0gfSovKSB7XG4gIGlmIChobXJBY2NlcHRDaGVja09uZShidW5kbGUsIGlkLCBkZXBzQnlCdW5kbGUpKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICAvLyBUcmF2ZXJzZSBwYXJlbnRzIGJyZWFkdGggZmlyc3QuIEFsbCBwb3NzaWJsZSBhbmNlc3RyaWVzIG11c3QgYWNjZXB0IHRoZSBITVIgdXBkYXRlLCBvciB3ZSdsbCByZWxvYWQuXG4gIGxldCBwYXJlbnRzID0gZ2V0UGFyZW50cyhtb2R1bGUuYnVuZGxlLnJvb3QsIGlkKTtcbiAgbGV0IGFjY2VwdGVkID0gZmFsc2U7XG4gIHdoaWxlIChwYXJlbnRzLmxlbmd0aCA+IDApIHtcbiAgICBsZXQgdiA9IHBhcmVudHMuc2hpZnQoKTtcbiAgICBsZXQgYSA9IGhtckFjY2VwdENoZWNrT25lKHZbMF0sIHZbMV0sIG51bGwpO1xuICAgIGlmIChhKSB7XG4gICAgICAvLyBJZiB0aGlzIHBhcmVudCBhY2NlcHRzLCBzdG9wIHRyYXZlcnNpbmcgdXB3YXJkLCBidXQgc3RpbGwgY29uc2lkZXIgc2libGluZ3MuXG4gICAgICBhY2NlcHRlZCA9IHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIE90aGVyd2lzZSwgcXVldWUgdGhlIHBhcmVudHMgaW4gdGhlIG5leHQgbGV2ZWwgdXB3YXJkLlxuICAgICAgbGV0IHAgPSBnZXRQYXJlbnRzKG1vZHVsZS5idW5kbGUucm9vdCwgdlsxXSk7XG4gICAgICBpZiAocC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgLy8gSWYgdGhlcmUgYXJlIG5vIHBhcmVudHMsIHRoZW4gd2UndmUgcmVhY2hlZCBhbiBlbnRyeSB3aXRob3V0IGFjY2VwdGluZy4gUmVsb2FkLlxuICAgICAgICBhY2NlcHRlZCA9IGZhbHNlO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIHBhcmVudHMucHVzaCguLi5wKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGFjY2VwdGVkO1xufVxuZnVuY3Rpb24gaG1yQWNjZXB0Q2hlY2tPbmUoYnVuZGxlIC8qOiBQYXJjZWxSZXF1aXJlICovLCBpZCAvKjogc3RyaW5nICovLCBkZXBzQnlCdW5kbGUgLyo6ID97IFtzdHJpbmddOiB7IFtzdHJpbmddOiBzdHJpbmcgfSB9Ki8pIHtcbiAgdmFyIG1vZHVsZXMgPSBidW5kbGUubW9kdWxlcztcbiAgaWYgKCFtb2R1bGVzKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChkZXBzQnlCdW5kbGUgJiYgIWRlcHNCeUJ1bmRsZVtidW5kbGUuSE1SX0JVTkRMRV9JRF0pIHtcbiAgICAvLyBJZiB3ZSByZWFjaGVkIHRoZSByb290IGJ1bmRsZSB3aXRob3V0IGZpbmRpbmcgd2hlcmUgdGhlIGFzc2V0IHNob3VsZCBnbyxcbiAgICAvLyB0aGVyZSdzIG5vdGhpbmcgdG8gZG8uIE1hcmsgYXMgXCJhY2NlcHRlZFwiIHNvIHdlIGRvbid0IHJlbG9hZCB0aGUgcGFnZS5cbiAgICBpZiAoIWJ1bmRsZS5wYXJlbnQpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gaG1yQWNjZXB0Q2hlY2soYnVuZGxlLnBhcmVudCwgaWQsIGRlcHNCeUJ1bmRsZSk7XG4gIH1cbiAgaWYgKGNoZWNrZWRBc3NldHNbaWRdKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY2hlY2tlZEFzc2V0c1tpZF0gPSB0cnVlO1xuICB2YXIgY2FjaGVkID0gYnVuZGxlLmNhY2hlW2lkXTtcbiAgYXNzZXRzVG9EaXNwb3NlLnB1c2goW2J1bmRsZSwgaWRdKTtcbiAgaWYgKCFjYWNoZWQgfHwgY2FjaGVkLmhvdCAmJiBjYWNoZWQuaG90Ll9hY2NlcHRDYWxsYmFja3MubGVuZ3RoKSB7XG4gICAgYXNzZXRzVG9BY2NlcHQucHVzaChbYnVuZGxlLCBpZF0pO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5mdW5jdGlvbiBobXJEaXNwb3NlKGJ1bmRsZSAvKjogUGFyY2VsUmVxdWlyZSAqLywgaWQgLyo6IHN0cmluZyAqLykge1xuICB2YXIgY2FjaGVkID0gYnVuZGxlLmNhY2hlW2lkXTtcbiAgYnVuZGxlLmhvdERhdGFbaWRdID0ge307XG4gIGlmIChjYWNoZWQgJiYgY2FjaGVkLmhvdCkge1xuICAgIGNhY2hlZC5ob3QuZGF0YSA9IGJ1bmRsZS5ob3REYXRhW2lkXTtcbiAgfVxuICBpZiAoY2FjaGVkICYmIGNhY2hlZC5ob3QgJiYgY2FjaGVkLmhvdC5fZGlzcG9zZUNhbGxiYWNrcy5sZW5ndGgpIHtcbiAgICBjYWNoZWQuaG90Ll9kaXNwb3NlQ2FsbGJhY2tzLmZvckVhY2goZnVuY3Rpb24gKGNiKSB7XG4gICAgICBjYihidW5kbGUuaG90RGF0YVtpZF0pO1xuICAgIH0pO1xuICB9XG4gIGRlbGV0ZSBidW5kbGUuY2FjaGVbaWRdO1xufVxuZnVuY3Rpb24gaG1yQWNjZXB0KGJ1bmRsZSAvKjogUGFyY2VsUmVxdWlyZSAqLywgaWQgLyo6IHN0cmluZyAqLykge1xuICAvLyBFeGVjdXRlIHRoZSBtb2R1bGUuXG4gIGJ1bmRsZShpZCk7XG5cbiAgLy8gUnVuIHRoZSBhY2NlcHQgY2FsbGJhY2tzIGluIHRoZSBuZXcgdmVyc2lvbiBvZiB0aGUgbW9kdWxlLlxuICB2YXIgY2FjaGVkID0gYnVuZGxlLmNhY2hlW2lkXTtcbiAgaWYgKGNhY2hlZCAmJiBjYWNoZWQuaG90ICYmIGNhY2hlZC5ob3QuX2FjY2VwdENhbGxiYWNrcy5sZW5ndGgpIHtcbiAgICBjYWNoZWQuaG90Ll9hY2NlcHRDYWxsYmFja3MuZm9yRWFjaChmdW5jdGlvbiAoY2IpIHtcbiAgICAgIHZhciBhc3NldHNUb0Fsc29BY2NlcHQgPSBjYihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBnZXRQYXJlbnRzKG1vZHVsZS5idW5kbGUucm9vdCwgaWQpO1xuICAgICAgfSk7XG4gICAgICBpZiAoYXNzZXRzVG9BbHNvQWNjZXB0ICYmIGFzc2V0c1RvQWNjZXB0Lmxlbmd0aCkge1xuICAgICAgICBhc3NldHNUb0Fsc29BY2NlcHQuZm9yRWFjaChmdW5jdGlvbiAoYSkge1xuICAgICAgICAgIGhtckRpc3Bvc2UoYVswXSwgYVsxXSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vICRGbG93Rml4TWVbbWV0aG9kLXVuYmluZGluZ11cbiAgICAgICAgYXNzZXRzVG9BY2NlcHQucHVzaC5hcHBseShhc3NldHNUb0FjY2VwdCwgYXNzZXRzVG9BbHNvQWNjZXB0KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufSIsImltcG9ydCAnLi9hcHAvZmxvYXRpbmdCdG4nXHJcbi8vIGltcG9ydCAnLi9hcHAvY3VzdG9tRm9udHMnXHJcbmltcG9ydCAnLi9hcHAvbWFpbkZvbnRzJ1xyXG4iLCIvLyBVc2UgYSBjcm9zcy1icm93c2VyIHN0b3JhZ2UgQVBJOlxyXG5pbXBvcnQgYnJvd3NlciBmcm9tICd3ZWJleHRlbnNpb24tcG9seWZpbGwnXHJcblxyXG5pbXBvcnQgeyBpY29uX3N1biwgaWNvbl9tb29uLCBpY29uX21vb25fZnVsbCwgaWNvbl9zZXR0aW5ncywgaWNvbl9wYWludCB9IGZyb20gJy4vY29tcG9uZW50cy9pY29ucy5qcydcclxuaW1wb3J0IHsgaGV4VG9IU0wgfSBmcm9tICcuLi91dGlscy9oZXhUb0hTTCdcclxuXHJcbi8vIGltcG9ydCB7IGZvbnRIdG1sQ29kZSwgYWRkRm9udHNFdmVudEhhbmRsZXJzIH0gZnJvbSAnLi9jdXN0b21Gb250cydcclxuaW1wb3J0IHsgZm9udEh0bWxDb2RlLCBoYW5kbGVGb250c0xpc3RlbmVycyB9IGZyb20gJy4vbWFpbkZvbnRzJ1xyXG4vLyBjb25zb2xlLmxvZyhmb250SHRtbENvZGUpXHJcblxyXG4vLyBsZXQgaXNPcHRpb25zU2hvd24gPSBmYWxzZVxyXG5cclxuLy8gR2xvYmFsIFZhcmlhYmxlc1xyXG5sZXQgaXNPcHRpb25zU2hvd24gPSBmYWxzZVxyXG5sZXQgJGh0bWxUYWdcclxubGV0ICRmbG9hdGluZ0J0blxyXG5sZXQgJGZsb2F0aW5nT3B0aW9uc1xyXG5sZXQgJGZsb2F0aW5nQnRuc0NvbnRhaW5lclxyXG5cclxubGV0ICRzZXR0aW5ncyAvLyBAIEFjY2VudCBUaGVtZVxyXG5sZXQgJHJlc2V0QWxsQnRuXHJcbi8vIGxldCBpc1NldHRpbmdzT3BlbiA9IGZhbHNlXHJcbmxldCBzdHlsZUVsZW1lbnQgPSBudWxsIC8vIERlY2xhcmUgdGhlIHN0eWxlRWxlbWVudCB2YXJpYWJsZVxyXG5cclxubGV0IGRlZmF1bHRDb2xvckxpZ2h0ID0gJyM2YjRkZmUnXHJcbmxldCBkZWZhdWx0Q29sb3JEYXJrID0gJyNjYTkzZmInXHJcbi8vIGxldCBpc0Rpc2FibGVkUmVzZXRBbGwgPSB0cnVlXHJcblxyXG5jb25zdCByZW5kZXJDb2xvcnNUYWIgPSBgXHJcblx0PHNlY3Rpb24+XHJcblx0XHQ8ZGl2IGNsYXNzPVwiY29sb3JwaWNrZXItY29udGFpbmVyXCI+XHJcblx0XHRcdDxkaXYgY2xhc3M9XCJjb2xvcnBpY2tlclwiPlxyXG5cdFx0XHRcdDxpbnB1dCB0eXBlPVwiY29sb3JcIiBpZD1cImFjY2VudExpZ2h0XCIgdmFsdWU9XCIjNmI0ZGZlXCIgLz5cclxuXHRcdFx0XHQ8bGFiZWwgZm9yPVwiYWNjZW50TGlnaHRcIj5BY2NlbnQgPHNwYW4+TGlnaHQ8L3NwYW4+PC9sYWJlbD5cclxuXHRcdFx0PC9kaXY+XHJcblx0XHRcdDxkaXYgY2xhc3M9XCJjb2xvcnBpY2tlclwiPlxyXG5cdFx0XHRcdDxpbnB1dCB0eXBlPVwiY29sb3JcIiBpZD1cImFjY2VudERhcmtcIiB2YWx1ZT1cIiNjYTkzZmJcIiAvPlxyXG5cdFx0XHRcdDxsYWJlbCBmb3I9XCJhY2NlbnREYXJrXCI+QWNjZW50IDxzcGFuPkRhcms8L3NwYW4+PC9sYWJlbD5cclxuXHRcdFx0PC9kaXY+XHJcblx0XHQ8L2Rpdj5cclxuXHRcdDxmb290ZXIgY2xhc3M9XCJncmlkIG10LTEwXCI+XHJcblx0XHRcdDxidXR0b24gaWQ9XCJyZXNldEFsbFNldHRpbmdzXCIgY2xhc3M9XCJidG4gYmxvY2sgcmVsYXRpdmUgYnRuLXByaW1hcnkgdGV4dC1jZW50ZXJcIiBhcz1cImJ1dHRvblwiPlJlc2V0IEFjY2VudHM8L2J1dHRvbj5cclxuXHRcdDwvZm9vdGVyPlxyXG5cdDwvc2VjdGlvbj5cclxuYFxyXG5cclxuLy8gSW5pdGlhbGl6YXRpb25cclxuaW5pdCgpXHJcblxyXG5mdW5jdGlvbiB0YWJzU3dpdGNoaW5nKCkge1xyXG5cdGNvbnN0IHRhYnMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZ3B0aC1zZXR0aW5ncyAudGFiLWJ1dHRvbicpXHJcblx0Y29uc3QgcGFuZXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuZ3B0aC1zZXR0aW5ncyAudGFiLXBhbmUnKVxyXG5cclxuXHR0YWJzLmZvckVhY2goKHRhYiwgaW5kZXgpID0+IHtcclxuXHRcdHRhYi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuXHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnRhYi1idXR0b24uYWN0aXZlJykuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJylcclxuXHRcdFx0ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnRhYi1wYW5lOm5vdCguaGlkZGVuKScpLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpXHJcblxyXG5cdFx0XHR0YWIuY2xhc3NMaXN0LmFkZCgnYWN0aXZlJylcclxuXHRcdFx0cGFuZXNbaW5kZXhdLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpXHJcblx0XHR9KVxyXG5cdH0pXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGluaXRUaGVtZSgpIHtcclxuXHR0cnkge1xyXG5cdFx0Y29uc3QgeyBncHRoZW1lOiBzdG9yZWRUaGVtZSB9ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLnN5bmMuZ2V0KCdncHRoZW1lJylcclxuXHRcdGNvbnN0IHRoZW1lID0gc3RvcmVkVGhlbWUgfHwgKHdpbmRvdy5tYXRjaE1lZGlhKCcocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KScpLm1hdGNoZXMgPyAnbGlnaHQnIDogJ2RhcmsnKVxyXG5cdFx0YXBwbHlUaGVtZSh0aGVtZSlcclxuXHR9IGNhdGNoIChlcnJvcikge1xyXG5cdFx0Y29uc29sZS5lcnJvcignRXJyb3IgaW5pdGlhbGl6aW5nIHRoZW1lOicsIGVycm9yKVxyXG5cdH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0VGhlbWUodGhlbWUpIHtcclxuXHR0cnkge1xyXG5cdFx0YXdhaXQgYnJvd3Nlci5zdG9yYWdlLnN5bmMuc2V0KHsgZ3B0aGVtZTogdGhlbWUgfSlcclxuXHRcdGFwcGx5VGhlbWUodGhlbWUpXHJcblx0XHR0b2dnbGVPcHRpb25zKClcclxuXHR9IGNhdGNoIChlcnJvcikge1xyXG5cdFx0Y29uc29sZS5lcnJvcignRXJyb3Igc2V0dGluZyB0aGVtZTonLCBlcnJvcilcclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNyZWF0ZUFuZEFwcGVuZFNWR1N0aWNreUJ0bigpIHtcclxuXHRjb25zdCBncHRoRmxvYXRpbmdCdG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxyXG5cdGdwdGhGbG9hdGluZ0J0bi5jbGFzc05hbWUgPSAnZ3B0aF9fZmxvYXRpbmcnXHJcblxyXG5cdC8vIDxpbWcgc3JjPVwiJHtncHRoVG9nZ2xlSW1nfVwiIGFsdD1cImdwdGgtdG9nZ2xlXCIvPlxyXG5cdGxldCBodG1sQ29kZSA9IGBcclxuXHRcdDxkaXYgY2xhc3M9XCJncHRoX19mbG9hdGluZy1pY29uXCI+XHJcblx0XHRcdCR7aWNvbl9wYWludH1cclxuXHRcdDwvZGl2PlxyXG5cdFx0XHJcblx0XHQ8ZGl2IGNsYXNzPVwiZ3B0aF9fb3B0aW9uc1wiPlxyXG5cdFx0XHQ8ZGl2IGNsYXNzPVwiZ3B0aF9fb3B0aW9ucy1idG5zXCI+XHJcblx0XHRcdFx0PGJ1dHRvbiBpZD1cImxpZ2h0XCIgZGF0YS1ncHRoLXRoZW1lPVwibGlnaHRcIj4ke2ljb25fc3VufTwvYnV0dG9uPlxyXG5cdFx0XHRcdDxidXR0b24gaWQ9XCJkYXJrXCIgZGF0YS1ncHRoLXRoZW1lPVwiZGFya1wiPiR7aWNvbl9tb29ufTwvYnV0dG9uPlxyXG5cdFx0XHRcdDxidXR0b24gaWQ9XCJvbGVkXCIgZGF0YS1ncHRoLXRoZW1lPVwiYmxhY2tcIj4ke2ljb25fbW9vbl9mdWxsfTwvYnV0dG9uPlxyXG5cdFx0XHRcdDxidXR0b24gaWQ9XCJncHRoLW9wZW4tc2V0dGluZ3NcIiBkYXRhLWdwdGgtdGhlbWU9XCJtb3JlXCI+JHtpY29uX3NldHRpbmdzfTwvYnV0dG9uPlxyXG5cdFx0XHQ8L2Rpdj5cclxuXHRcdDwvZGl2PlxyXG5cdGBcclxuXHJcblx0Ly8gZ3B0aEZsb2F0aW5nQnRuLmlubmVySFRNTCA9IGh0bWxDb2RlXHJcblx0Z3B0aEZsb2F0aW5nQnRuLmluc2VydEFkamFjZW50SFRNTCgnYmVmb3JlZW5kJywgaHRtbENvZGUpXHJcblx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChncHRoRmxvYXRpbmdCdG4pXHJcblxyXG5cdC8vIENhY2hlIERPTSBlbGVtZW50cyBhZnRlciBhcHBlbmRpbmdcclxuXHQkaHRtbFRhZyA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxyXG5cdCRmbG9hdGluZ0J0biA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncHRoX19mbG9hdGluZycpXHJcblx0JGZsb2F0aW5nT3B0aW9ucyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncHRoX19vcHRpb25zJylcclxuXHQkZmxvYXRpbmdCdG5zQ29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdwdGhfX29wdGlvbnMtYnRucycpXHJcblxyXG5cdC8vIEFkZCBldmVudCBsaXN0ZW5lcnMgYWZ0ZXIgRE9NIGVsZW1lbnRzIGFyZSBhcHBlbmRlZFxyXG5cdCRmbG9hdGluZ0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRvZ2dsZU9wdGlvbnMpXHJcblx0JGZsb2F0aW5nQnRuc0NvbnRhaW5lci5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGhhbmRsZUNoYW5nZVRoZW1lKVxyXG59XHJcblxyXG5mdW5jdGlvbiBoYW5kbGVDaGFuZ2VUaGVtZShlKSB7XHJcblx0Y29uc3QgdGhlbWVCdXR0b24gPSBlLnRhcmdldC5jbG9zZXN0KCdidXR0b24nKVxyXG5cdGlmICghdGhlbWVCdXR0b24pIHJldHVyblxyXG5cclxuXHRjb25zdCB0aGVtZSA9IHRoZW1lQnV0dG9uLmlkXHJcblxyXG5cdGlmICh0aGVtZSAhPT0gJ2dwdGgtb3Blbi1zZXR0aW5ncycpIHtcclxuXHRcdHNldFRoZW1lKHRoZW1lKVxyXG5cdFx0cmV0dXJuXHJcblx0fVxyXG5cclxuXHQvKiBJZiBjbGlja2VkIG9uIFwi4pqZ77iPIE9wZW4gU2V0dGluZ3NcIiAqL1xyXG5cdGlmICh0aGVtZSA9PT0gJ2dwdGgtb3Blbi1zZXR0aW5ncycpIHtcclxuXHRcdG9wZW5TZXR0aW5ncygpXHJcblx0XHQvLyB0b2dnbGVPcHRpb25zKClcclxuXHR9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFwcGx5VGhlbWUodGhlbWUpIHtcclxuXHQkaHRtbFRhZy5kYXRhc2V0LmdwdGhlbWUgPSB0aGVtZVxyXG5cdCRodG1sVGFnLnN0eWxlLmNvbG9yU2NoZW1lID0gdGhlbWUgPT09ICdvbGVkJyA/ICdkYXJrJyA6IHRoZW1lXHJcblx0JGh0bWxUYWcuY2xhc3NOYW1lID0gdGhlbWUgPT09ICdvbGVkJyA/ICdkYXJrJyA6IHRoZW1lXHJcblx0aWYgKHRoZW1lICE9PSAnb2xlZCcpICRodG1sVGFnLnJlbW92ZUF0dHJpYnV0ZSgnZGF0YS1ncHRoZW1lJylcclxufVxyXG5cclxuZnVuY3Rpb24gdG9nZ2xlT3B0aW9ucygpIHtcclxuXHRpc09wdGlvbnNTaG93biA9ICFpc09wdGlvbnNTaG93blxyXG5cdCRmbG9hdGluZ09wdGlvbnMuY2xhc3NMaXN0LnRvZ2dsZSgnZ3B0aF9fb3B0aW9ucy0tc2hvd24nLCBpc09wdGlvbnNTaG93bilcclxuXHJcblx0aWYgKGlzT3B0aW9uc1Nob3duKSBkb2N1bWVudC5ib2R5LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgaGlkZU9wdGlvbnMpXHJcblx0ZWxzZSBkb2N1bWVudC5ib2R5LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgaGlkZU9wdGlvbnMpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhpZGVPcHRpb25zKGUpIHtcclxuXHRjb25zdCBpc0NsaWNrSW5zaWRlRmxvYXRpbmdCdG4gPSAkZmxvYXRpbmdCdG4uY29udGFpbnMoZS50YXJnZXQpXHJcblx0Y29uc3QgaXNDbGlja0luc2lkZUZsb2F0aW5nT3B0aW9ucyA9ICRmbG9hdGluZ09wdGlvbnMuY29udGFpbnMoZS50YXJnZXQpXHJcblxyXG5cdGlmICghaXNDbGlja0luc2lkZUZsb2F0aW5nQnRuICYmICFpc0NsaWNrSW5zaWRlRmxvYXRpbmdPcHRpb25zKSB0b2dnbGVPcHRpb25zKClcclxuXHJcblx0Ly8gaWYgKCEkZmxvYXRpbmdCdG4uY29udGFpbnMoZS50YXJnZXQpICYmICEkZmxvYXRpbmdUaGVtZU9wdGlvbnMuY29udGFpbnMoZS50YXJnZXQpKSB0b2dnbGVPcHRpb25zKClcclxufVxyXG5cclxuZnVuY3Rpb24gZGVjcmVpc2VGbG9hdGluZ0J0blNpemUoKSB7XHJcblx0c2V0VGltZW91dCgoKSA9PiB7XHJcblx0XHQkZmxvYXRpbmdCdG4uY2xhc3NMaXN0LmFkZCgnZ3B0aF9fZmxvYXRpbmctLXNtYWxsJylcclxuXHR9LCAzMDAwKVxyXG59XHJcblxyXG4vKiBfX19fX19fX19fX19fXyBUSEVNRSBDVVNUT01JWkFUSU9OIC0gQUNDRU5UIFRIRU1FIF9fX19fX19fX19fX19fICovXHJcbmZ1bmN0aW9uIHJlbmRlclNldHRpbmdzKCkge1xyXG5cdGNvbnN0IGdwdGhTZXR0aW5ncyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXHJcblx0Z3B0aFNldHRpbmdzLmNsYXNzTmFtZSA9IGBncHRoLXNldHRpbmdzIGZpeGVkIGZsZXggZmxleC1jb2xgXHJcblxyXG5cdGxldCBodG1sQ29kZSA9IGBcclxuXHRcdDxoZWFkZXIgY2xhc3M9XCJtYi01XCI+XHJcblx0XHRcdDxoMiBjbGFzcz1cIm10LTUgdGV4dC1jZW50ZXIgZm9udC1tZWRpdW0gZ3B0aC1zZXR0aW5nc19fdGl0bGVcIj48c3BhbiBjbGFzcz1cImZvbnQtc2VtaWJvbGRcIj5HUFRoZW1lczwvc3Bhbj4gQ3VzdG9taXphdGlvbjwvaDI+XHJcblxyXG5cdFx0XHQ8YnV0dG9uIGNsYXNzPVwidGV4dC10b2tlbi10ZXh0LXRlcnRpYXJ5IGhvdmVyOnRleHQtdG9rZW4tdGV4dC1wcmltYXJ5IGFic29sdXRlIHRvcC00IHJpZ2h0LTRcIiBpZD1cImdwdGgtc2V0dGluZ3MtY2xvc2VcIj5cclxuXHRcdFx0XHQ8c3ZnIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj48cGF0aCBkPVwiTTYuMzQzMTUgNi4zNDMzOEwxNy42NTY5IDE3LjY1NzFNMTcuNjU2OSA2LjM0MzM4TDYuMzQzMTUgMTcuNjU3MVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIj48L3BhdGg+PC9zdmc+XHJcblx0XHRcdDwvYnV0dG9uPlxyXG5cdFx0PC9oZWFkZXI+XHJcblxyXG5cdFx0PG1haW4gPlxyXG5cdFx0XHQ8ZGl2IGNsYXNzPVwidGFic1wiPlxyXG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJ0YWItYnV0dG9ucyBmbGV4IGl0ZW1zLWNlbnRlciByb3VuZGVkLWZ1bGwgcC0xIGZvbnQtc2VtaWJvbGQgbWItMTBcIj5cclxuXHRcdFx0XHRcdDxidXR0b24gY2xhc3M9XCJ0YWItYnV0dG9uIHB5LTIgcHgtNCBmb2N1czpvdXRsaW5lLW5vbmUgdGV4dC1jZW50ZXIgcm91bmRlZC1mdWxsIGFjdGl2ZVwiPlxyXG5cdFx0XHRcdFx0XHRDb2xvclxyXG5cdFx0XHRcdFx0PC9idXR0b24+XHJcblx0XHRcdFx0XHQ8YnV0dG9uIGNsYXNzPVwidGFiLWJ1dHRvbiBweS0yIHB4LTQgZm9jdXM6b3V0bGluZS1ub25lIHRleHQtY2VudGVyIHJvdW5kZWQtZnVsbFwiPlxyXG5cdFx0XHRcdFx0XHRGb250XHJcblx0XHRcdFx0XHQ8L2J1dHRvbj5cclxuXHRcdFx0XHRcdDxidXR0b24gY2xhc3M9XCJ0YWItYnV0dG9uIHB5LTIgcHgtNCBmb2N1czpvdXRsaW5lLW5vbmUgdGV4dC1jZW50ZXIgcm91bmRlZC1mdWxsXCI+XHJcblx0XHRcdFx0XHRcdEFzc2V0c1xyXG5cdFx0XHRcdFx0PC9idXR0b24+XHJcblx0XHRcdFx0PC9kaXY+XHJcblxyXG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJ0YWItY29udGVudFwiPlxyXG5cdFx0XHRcdFx0PGRpdiBjbGFzcz1cInRhYi1wYW5lIGFjdGl2ZVwiIGlkPVwidGFiLWNvbG9yc1wiPlxyXG5cdFx0XHRcdFx0XHQke3JlbmRlckNvbG9yc1RhYn1cclxuXHRcdFx0XHRcdDwvZGl2PlxyXG5cclxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJ0YWItcGFuZSBoaWRkZW5cIiBpZD1cInRhYi1mb250c1wiPlxyXG5cdFx0XHRcdFx0XHQke2ZvbnRIdG1sQ29kZX1cclxuXHRcdFx0XHRcdDwvZGl2PlxyXG5cclxuXHRcdFx0XHRcdDxkaXYgY2xhc3M9XCJ0YWItcGFuZSBoaWRkZW5cIiBpZD1cInRhYi1hc3NldHNcIj5cclxuXHRcdFx0XHRcdFx0PHAgY2xhc3M9XCJ0ZXh0LWNlbnRlciB0ZXh0LXRva2VuLXRleHQtdGVydGlhcnkgdGV4dC1zbSBtYi0yIGZvbnQtd2VpZ2h0LTIwMFwiPm9vb3BzLCBzdWNoIGVtcHR5PC9wPlxyXG5cdFx0XHRcdFx0XHQ8cCBjbGFzcz1cInRleHQtY2VudGVyIHRleHQtdG9rZW4tdGV4dC1zZWNvbmRhcnkgdGV4dC1tZCBmb250LXNlbWlib2xkXCI+Q29taW5nIFNvb248L3A+XHJcblx0XHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0PC9kaXY+XHJcblx0XHQ8L21haW4+XHJcblx0YFxyXG5cclxuXHRncHRoU2V0dGluZ3MuaW5zZXJ0QWRqYWNlbnRIVE1MKCdiZWZvcmVlbmQnLCBodG1sQ29kZSlcclxuXHRkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGdwdGhTZXR0aW5ncylcclxuXHJcblx0ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dwdGgtc2V0dGluZ3MtY2xvc2UnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGNsb3NlU2V0dGluZ3MpXHJcblxyXG5cdCRzZXR0aW5ncyA9IGdwdGhTZXR0aW5nc1xyXG5cclxuXHR0YWJzU3dpdGNoaW5nKClcclxuXHJcblx0JHJlc2V0QWxsQnRuID0gJHNldHRpbmdzLnF1ZXJ5U2VsZWN0b3IoJyNyZXNldEFsbFNldHRpbmdzJylcclxuXHQkcmVzZXRBbGxCdG4uZGlzYWJsZWQgPSB0cnVlXHJcblxyXG5cdCRzZXR0aW5ncy5xdWVyeVNlbGVjdG9yKCcjcmVzZXRBbGxTZXR0aW5ncycpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgcmVzZXRBbGxTZXR0aW5ncylcclxuXHJcblx0Ly8gYWRkRm9udHNFdmVudEhhbmRsZXJzKClcclxuXHRoYW5kbGVGb250c0xpc3RlbmVycygpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIG9wZW5TZXR0aW5ncygpIHtcclxuXHQkc2V0dGluZ3MuY2xhc3NMaXN0LmFkZCgnZ3B0aC1zZXR0aW5ncy0tb3BlbicpXHJcblx0JHNldHRpbmdzLmFkZEV2ZW50TGlzdGVuZXIoJ3RyYW5zaXRpb25lbmQnLCBoYW5kbGVTZXR0aW5nc09wZW5lZClcclxuXHQkcmVzZXRBbGxCdG4uZGlzYWJsZWQgPSBmYWxzZVxyXG5cclxuXHQvLyBpc09wdGlvbnNTaG93biA9IGZhbHNlXHJcblx0Ly8gdG9nZ2xlT3B0aW9ucygpXHJcbn1cclxuZnVuY3Rpb24gaGFuZGxlU2V0dGluZ3NPcGVuZWQoKSB7XHJcblx0ZG9jdW1lbnQuYm9keS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGhhbmRsZUNsaWNrT3V0c2lkZVNldHRpbmdzKVxyXG5cdCRzZXR0aW5ncy5yZW1vdmVFdmVudExpc3RlbmVyKCd0cmFuc2l0aW9uZW5kJywgaGFuZGxlU2V0dGluZ3NPcGVuZWQpXHJcbn1cclxuZnVuY3Rpb24gY2xvc2VTZXR0aW5ncygpIHtcclxuXHQkc2V0dGluZ3MuY2xhc3NMaXN0LnJlbW92ZSgnZ3B0aC1zZXR0aW5ncy0tb3BlbicpXHJcblx0ZG9jdW1lbnQuYm9keS5yZW1vdmVFdmVudExpc3RlbmVyKCdjbGljaycsIGhhbmRsZUNsaWNrT3V0c2lkZVNldHRpbmdzKVxyXG5cdCRyZXNldEFsbEJ0bi5kaXNhYmxlZCA9IHRydWVcclxufVxyXG5mdW5jdGlvbiBoYW5kbGVDbGlja091dHNpZGVTZXR0aW5ncyhlKSB7XHJcblx0bGV0IGlzT3BlblNldHRpbmdzQnV0dG9uID0gZS50YXJnZXQuaWQgPT09ICdncHRoLXNldHRpbmdzLW9wZW4nXHJcblxyXG5cdGlmICghJHNldHRpbmdzLmNvbnRhaW5zKGUudGFyZ2V0KSAmJiAhaXNPcGVuU2V0dGluZ3NCdXR0b24pIGNsb3NlU2V0dGluZ3MoKVxyXG59XHJcblxyXG5mdW5jdGlvbiBoYW5kbGVDb2xvcklucHV0KCkge1xyXG5cdCRzZXR0aW5ncy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XHJcblx0XHQvLyBjb25zb2xlLmxvZyhlLnRhcmdldClcclxuXHJcblx0XHRpZiAoZS50YXJnZXQuaWQgPT09ICdhY2NlbnRMaWdodCcpIHtcclxuXHRcdFx0ZS50YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoZSkgPT4ge1xyXG5cdFx0XHRcdHVwZGF0ZUNTU1ZhcnMoZS50YXJnZXQudmFsdWUsIG51bGwpXHJcblx0XHRcdH0pXHJcblx0XHRcdC8vIFNhdmUgbGlnaHQgYWNjZW50IGNvbG9yIHRvIHN0b3JhZ2VcclxuXHRcdFx0ZS50YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKGUpID0+IHtcclxuXHRcdFx0XHRzZXRBY2NlbnRUb1N0b3JhZ2UoJ2FjY2VudF9saWdodCcsIGUudGFyZ2V0LnZhbHVlKVxyXG5cdFx0XHRcdGNsb3NlU2V0dGluZ3MoKVxyXG5cdFx0XHR9KVxyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChlLnRhcmdldC5pZCA9PT0gJ2FjY2VudERhcmsnKSB7XHJcblx0XHRcdGUudGFyZ2V0LmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKGUpID0+IHtcclxuXHRcdFx0XHR1cGRhdGVDU1NWYXJzKG51bGwsIGUudGFyZ2V0LnZhbHVlKVxyXG5cdFx0XHR9KVxyXG5cdFx0XHQvLyBTYXZlIGRhcmsgYWNjZW50IGNvbG9yIHRvIHN0b3JhZ2VcclxuXHRcdFx0ZS50YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKGUpID0+IHtcclxuXHRcdFx0XHRzZXRBY2NlbnRUb1N0b3JhZ2UoJ2FjY2VudF9kYXJrJywgZS50YXJnZXQudmFsdWUpXHJcblx0XHRcdFx0Y2xvc2VTZXR0aW5ncygpXHJcblx0XHRcdH0pXHJcblx0XHR9XHJcblx0fSlcclxufVxyXG4vLyBGdW5jdGlvbiB0byBjcmVhdGUgYW5kIGluamVjdCB0aGUgPHN0eWxlPiBlbGVtZW50XHJcbmZ1bmN0aW9uIGluamVjdFN0eWxlRWxlbWVudCgpIHtcclxuXHRzdHlsZUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpXHJcblx0c3R5bGVFbGVtZW50LnR5cGUgPSAndGV4dC9jc3MnXHJcblx0ZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZUVsZW1lbnQpXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVwZGF0ZUNTU1ZhcnMobGlnaHRDb2xvciwgZGFya0NvbG9yKSB7XHJcblx0aWYgKCFzdHlsZUVsZW1lbnQpIGluamVjdFN0eWxlRWxlbWVudCgpXHJcblxyXG5cdGNvbnN0IGxpZ2h0SFNMID0gbGlnaHRDb2xvclxyXG5cdFx0PyBoZXhUb0hTTChsaWdodENvbG9yKVxyXG5cdFx0OiBoZXhUb0hTTCgkc2V0dGluZ3MucXVlcnlTZWxlY3RvcignLmNvbG9ycGlja2VyICNhY2NlbnRMaWdodCcpLnZhbHVlKVxyXG5cdGNvbnN0IGRhcmtIU0wgPSBkYXJrQ29sb3JcclxuXHRcdD8gaGV4VG9IU0woZGFya0NvbG9yKVxyXG5cdFx0OiBoZXhUb0hTTCgkc2V0dGluZ3MucXVlcnlTZWxlY3RvcignLmNvbG9ycGlja2VyICNhY2NlbnREYXJrJykudmFsdWUpXHJcblxyXG5cdGxldCBjc3NWYXJzID0gJydcclxuXHJcblx0Y3NzVmFycyA9IGBcclxuICAgICAgICBodG1sLmxpZ2h0IHtcclxuICAgICAgICAgICAgLS1hY2NlbnQtaDogJHtsaWdodEhTTFswXX0gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgLS1hY2NlbnQtczogJHtsaWdodEhTTFsxXX0lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIC0tYWNjZW50LWw6ICR7bGlnaHRIU0xbMl19JSAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgICAgICBodG1sLmRhcmsge1xyXG4gICAgICAgICAgICAtLWFjY2VudC1oOiAke2RhcmtIU0xbMF19ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIC0tYWNjZW50LXM6ICR7ZGFya0hTTFsxXX0lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIC0tYWNjZW50LWw6ICR7ZGFya0hTTFsyXX0lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgYFxyXG5cclxuXHQvLyBjb25zb2xlLmxvZyhjc3NWYXJzKVxyXG5cclxuXHRzdHlsZUVsZW1lbnQudGV4dENvbnRlbnQgPSBjc3NWYXJzXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNldEFjY2VudFRvU3RvcmFnZShzdG9yYWdlQ29sb3JQcm9wZXJ0eSwgYWNjZW50VmFsdWUpIHtcclxuXHR0cnkge1xyXG5cdFx0aWYgKHN0b3JhZ2VDb2xvclByb3BlcnR5ID09PSAnYWNjZW50X2xpZ2h0Jykge1xyXG5cdFx0XHRhd2FpdCBicm93c2VyLnN0b3JhZ2Uuc3luYy5zZXQoeyBhY2NlbnRfbGlnaHQ6IGFjY2VudFZhbHVlIH0pXHJcblx0XHR9XHJcblx0XHRpZiAoc3RvcmFnZUNvbG9yUHJvcGVydHkgPT09ICdhY2NlbnRfZGFyaycpIHtcclxuXHRcdFx0YXdhaXQgYnJvd3Nlci5zdG9yYWdlLnN5bmMuc2V0KHsgYWNjZW50X2Rhcms6IGFjY2VudFZhbHVlIH0pXHJcblx0XHR9XHJcblx0XHQvLyBjb25zb2xlLmxvZyh7IHN0b3JhZ2VDb2xvclByb3BlcnR5LCBhY2NlbnRWYWx1ZSB9KVxyXG5cdH0gY2F0Y2ggKGUpIHtcclxuXHRcdGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHNldHRpbmcgdGhlIGFjY2VudCBjb2xvcnMgaW4gc3RvcmFnZTonLCBlKVxyXG5cdH1cclxufVxyXG5cclxuZnVuY3Rpb24gc2V0Q29sb3JJbnB1dFZhbHVlKHsgYWNjZW50TGlnaHQsIGFjY2VudERhcmsgfSkge1xyXG5cdC8vIGNvbnNvbGUubG9nKHsgYWNjZW50TGlnaHQsIGFjY2VudERhcmsgfSlcclxuXHQkc2V0dGluZ3MucXVlcnlTZWxlY3RvcignLmNvbG9ycGlja2VyICNhY2NlbnRMaWdodCcpLnZhbHVlID0gYWNjZW50TGlnaHRcclxuXHQkc2V0dGluZ3MucXVlcnlTZWxlY3RvcignLmNvbG9ycGlja2VyICNhY2NlbnREYXJrJykudmFsdWUgPSBhY2NlbnREYXJrXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUFjY2VudHNTdG9yYWdlKCkge1xyXG5cdHRyeSB7XHJcblx0XHQvLyBHZXQgYWNjZW50IGNvbG9ycyBmcm9tIHN0b3JhZ2VcclxuXHRcdGNvbnN0IHsgYWNjZW50X2xpZ2h0OiBhY2NlbnRMaWdodCwgYWNjZW50X2Rhcms6IGFjY2VudERhcmsgfSA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5zeW5jLmdldChbXHJcblx0XHRcdCdhY2NlbnRfbGlnaHQnLFxyXG5cdFx0XHQnYWNjZW50X2RhcmsnLFxyXG5cdFx0XSlcclxuXHRcdC8vIGNvbnNvbGUubG9nKCdSZXRyaWV2ZWQgYWNjZW50IGNvbG9ycyBmcm9tIHN0b3JhZ2U6JywgYWNjZW50TGlnaHQsIGFjY2VudERhcmspXHJcblxyXG5cdFx0Ly8gU2V0IGRlZmF1bHQgYWNjZW50IGNvbG9ycyBpZiBub3QgYWxyZWFkeSBzZXRcclxuXHRcdGlmICghYWNjZW50TGlnaHQgfHwgIWFjY2VudERhcmspIHtcclxuXHRcdFx0YXdhaXQgYnJvd3Nlci5zdG9yYWdlLnN5bmMuc2V0KHtcclxuXHRcdFx0XHRhY2NlbnRfbGlnaHQ6IGRlZmF1bHRDb2xvckxpZ2h0LFxyXG5cdFx0XHRcdGFjY2VudF9kYXJrOiBkZWZhdWx0Q29sb3JEYXJrLFxyXG5cdFx0XHR9KVxyXG5cdFx0XHRjb25zb2xlLmxvZygnRGVmYXVsdCBhY2NlbnQgY29sb3JzIHNldCBpbiBzdG9yYWdlJylcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBhY2NlbnRDb2xvckxpZ2h0ID0gYWNjZW50TGlnaHQgfHwgZGVmYXVsdENvbG9yTGlnaHRcclxuXHRcdGNvbnN0IGFjY2VudENvbG9yRGFyayA9IGFjY2VudERhcmsgfHwgZGVmYXVsdENvbG9yRGFya1xyXG5cclxuXHRcdC8vIFVwZGF0ZSBDU1Mgd2l0aCByZXRyaWV2ZWQgb3IgZGVmYXVsdCBhY2NlbnQgY29sb3JzXHJcblx0XHR1cGRhdGVDU1NWYXJzKGFjY2VudENvbG9yTGlnaHQsIGFjY2VudENvbG9yRGFyaylcclxuXHJcblx0XHRzZXRDb2xvcklucHV0VmFsdWUoeyBhY2NlbnRMaWdodDogYWNjZW50Q29sb3JMaWdodCwgYWNjZW50RGFyazogYWNjZW50Q29sb3JEYXJrIH0pXHJcblxyXG5cdFx0Ly8gY29uc29sZS5sb2coJ0FjY2VudCBjb2xvcnMgYXBwbGllZCB0byBDU1M6JywgYWNjZW50Q29sb3JMaWdodCwgYWNjZW50Q29sb3JEYXJrKVxyXG5cdH0gY2F0Y2ggKGVycm9yKSB7XHJcblx0XHRjb25zb2xlLmVycm9yKCdFcnJvciBoYW5kbGluZyBhY2NlbnQgY29sb3JzOicsIGVycm9yKVxyXG5cdH1cclxufVxyXG5hc3luYyBmdW5jdGlvbiByZXNldEFsbFNldHRpbmdzKCkge1xyXG5cdGlmICghc3R5bGVFbGVtZW50KSBpbmplY3RTdHlsZUVsZW1lbnQoKVxyXG5cclxuXHQvLyBsZXQgYWNjZW50TGlnaHQgPSBbMjUwLCA5OSwgNjVdXHJcblx0Ly8gbGV0IGFjY2VudERhcmsgPSBbMjcyLCA5MywgNzhdXHJcblx0bGV0IGFjY2VudExpZ2h0ID0gaGV4VG9IU0woZGVmYXVsdENvbG9yTGlnaHQpXHJcblx0bGV0IGFjY2VudERhcmsgPSBoZXhUb0hTTChkZWZhdWx0Q29sb3JEYXJrKVxyXG5cclxuXHRjb25zdCBjc3NWYXJzID0gYFxyXG4gICAgICAgIGh0bWwubGlnaHQge1xyXG4gICAgICAgICAgICAtLWFjY2VudC1oOiAke2FjY2VudExpZ2h0WzBdfSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICAtLWFjY2VudC1zOiAke2FjY2VudExpZ2h0WzFdfSUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgLS1hY2NlbnQtbDogJHthY2NlbnRMaWdodFsyXX0lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGh0bWwuZGFyayB7XHJcbiAgICAgICAgICAgIC0tYWNjZW50LWg6ICR7YWNjZW50RGFya1swXX0gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgLS1hY2NlbnQtczogJHthY2NlbnREYXJrWzFdfSUgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgLS1hY2NlbnQtbDogJHthY2NlbnREYXJrWzJdfSUgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICBgXHJcblxyXG5cdHN0eWxlRWxlbWVudC50ZXh0Q29udGVudCA9IGNzc1ZhcnNcclxuXHJcblx0c2V0Q29sb3JJbnB1dFZhbHVlKHsgYWNjZW50TGlnaHQ6IGRlZmF1bHRDb2xvckxpZ2h0LCBhY2NlbnREYXJrOiBkZWZhdWx0Q29sb3JEYXJrIH0pXHJcblxyXG5cdGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5zeW5jLnNldCh7XHJcblx0XHRhY2NlbnRfbGlnaHQ6IGRlZmF1bHRDb2xvckxpZ2h0LFxyXG5cdFx0YWNjZW50X2Rhcms6IGRlZmF1bHRDb2xvckRhcmssXHJcblx0fSlcclxufVxyXG5cclxuLyogPT09IEluaXRpYWxpemF0aW9uICovXHJcbmZ1bmN0aW9uIGluaXQoKSB7XHJcblx0aW5pdFRoZW1lKClcclxuXHRjcmVhdGVBbmRBcHBlbmRTVkdTdGlja3lCdG4oKVxyXG5cdHJlbmRlclNldHRpbmdzKClcclxuXHRkZWNyZWlzZUZsb2F0aW5nQnRuU2l6ZSgpXHJcblx0aGFuZGxlQWNjZW50c1N0b3JhZ2UoKVxyXG5cdGhhbmRsZUNvbG9ySW5wdXQoKVxyXG59XHJcblxyXG4vKiA/IE9ubHkgZm9yIGRlYnVnZ2luZyAtIHJlbW92ZSBsYXRlciEgKi9cclxuLyogZGVidWdHZXRBbGxTdG9yYWdlSXRlbXMoKVxyXG4vLyBHZXQgYWxsIHRoZSBpdGVtcyBpbiB0aGUgc3RvcmFnZVxyXG5mdW5jdGlvbiBkZWJ1Z0dldEFsbFN0b3JhZ2VJdGVtcygpIHtcclxuXHRicm93c2VyLnN0b3JhZ2Uuc3luYy5nZXQobnVsbCwgZnVuY3Rpb24gKGl0ZW1zKSB7XHJcblx0XHRjb25zb2xlLmxvZyhpdGVtcykgLy8gVGhpcyB3aWxsIGxvZyBhbGwgdGhlIGl0ZW1zIHN0b3JlZCBpbiBzeW5jIHN0b3JhZ2VcclxuXHR9KVxyXG59XHJcbiovXHJcbiIsIi8qIHdlYmV4dGVuc2lvbi1wb2x5ZmlsbCAtIHYwLjEwLjAgLSBGcmkgQXVnIDEyIDIwMjIgMTk6NDI6NDQgKi9cbi8qIC0qLSBNb2RlOiBpbmRlbnQtdGFicy1tb2RlOiBuaWw7IGpzLWluZGVudC1sZXZlbDogMiAtKi0gKi9cbi8qIHZpbTogc2V0IHN0cz0yIHN3PTIgZXQgdHc9ODA6ICovXG4vKiBUaGlzIFNvdXJjZSBDb2RlIEZvcm0gaXMgc3ViamVjdCB0byB0aGUgdGVybXMgb2YgdGhlIE1vemlsbGEgUHVibGljXG4gKiBMaWNlbnNlLCB2LiAyLjAuIElmIGEgY29weSBvZiB0aGUgTVBMIHdhcyBub3QgZGlzdHJpYnV0ZWQgd2l0aCB0aGlzXG4gKiBmaWxlLCBZb3UgY2FuIG9idGFpbiBvbmUgYXQgaHR0cDovL21vemlsbGEub3JnL01QTC8yLjAvLiAqL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbmlmICghZ2xvYmFsVGhpcy5jaHJvbWU/LnJ1bnRpbWU/LmlkKSB7XG4gIHRocm93IG5ldyBFcnJvcihcIlRoaXMgc2NyaXB0IHNob3VsZCBvbmx5IGJlIGxvYWRlZCBpbiBhIGJyb3dzZXIgZXh0ZW5zaW9uLlwiKTtcbn1cblxuaWYgKHR5cGVvZiBnbG9iYWxUaGlzLmJyb3dzZXIgPT09IFwidW5kZWZpbmVkXCIgfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKGdsb2JhbFRoaXMuYnJvd3NlcikgIT09IE9iamVjdC5wcm90b3R5cGUpIHtcbiAgY29uc3QgQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFID0gXCJUaGUgbWVzc2FnZSBwb3J0IGNsb3NlZCBiZWZvcmUgYSByZXNwb25zZSB3YXMgcmVjZWl2ZWQuXCI7XG5cbiAgLy8gV3JhcHBpbmcgdGhlIGJ1bGsgb2YgdGhpcyBwb2x5ZmlsbCBpbiBhIG9uZS10aW1lLXVzZSBmdW5jdGlvbiBpcyBhIG1pbm9yXG4gIC8vIG9wdGltaXphdGlvbiBmb3IgRmlyZWZveC4gU2luY2UgU3BpZGVybW9ua2V5IGRvZXMgbm90IGZ1bGx5IHBhcnNlIHRoZVxuICAvLyBjb250ZW50cyBvZiBhIGZ1bmN0aW9uIHVudGlsIHRoZSBmaXJzdCB0aW1lIGl0J3MgY2FsbGVkLCBhbmQgc2luY2UgaXQgd2lsbFxuICAvLyBuZXZlciBhY3R1YWxseSBuZWVkIHRvIGJlIGNhbGxlZCwgdGhpcyBhbGxvd3MgdGhlIHBvbHlmaWxsIHRvIGJlIGluY2x1ZGVkXG4gIC8vIGluIEZpcmVmb3ggbmVhcmx5IGZvciBmcmVlLlxuICBjb25zdCB3cmFwQVBJcyA9IGV4dGVuc2lvbkFQSXMgPT4ge1xuICAgIC8vIE5PVEU6IGFwaU1ldGFkYXRhIGlzIGFzc29jaWF0ZWQgdG8gdGhlIGNvbnRlbnQgb2YgdGhlIGFwaS1tZXRhZGF0YS5qc29uIGZpbGVcbiAgICAvLyBhdCBidWlsZCB0aW1lIGJ5IHJlcGxhY2luZyB0aGUgZm9sbG93aW5nIFwiaW5jbHVkZVwiIHdpdGggdGhlIGNvbnRlbnQgb2YgdGhlXG4gICAgLy8gSlNPTiBmaWxlLlxuICAgIGNvbnN0IGFwaU1ldGFkYXRhID0ge1xuICAgICAgXCJhbGFybXNcIjoge1xuICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImNsZWFyQWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImJvb2ttYXJrc1wiOiB7XG4gICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRDaGlsZHJlblwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRSZWNlbnRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0U3ViVHJlZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRUcmVlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVRyZWVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiYnJvd3NlckFjdGlvblwiOiB7XG4gICAgICAgIFwiZGlzYWJsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwiZW5hYmxlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0UG9wdXBcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwib3BlblBvcHVwXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInNldEJhZGdlQmFja2dyb3VuZENvbG9yXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBcInNldEljb25cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0UG9wdXBcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBcInNldFRpdGxlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiYnJvd3NpbmdEYXRhXCI6IHtcbiAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlQ2FjaGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlQ29va2llc1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVEb3dubG9hZHNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlRm9ybURhdGFcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlSGlzdG9yeVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVMb2NhbFN0b3JhZ2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlUGFzc3dvcmRzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVBsdWdpbkRhdGFcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0dGluZ3NcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImNvbW1hbmRzXCI6IHtcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImNvbnRleHRNZW51c1wiOiB7XG4gICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZUFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImNvb2tpZXNcIjoge1xuICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWxsQ29va2llU3RvcmVzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImRldnRvb2xzXCI6IHtcbiAgICAgICAgXCJpbnNwZWN0ZWRXaW5kb3dcIjoge1xuICAgICAgICAgIFwiZXZhbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiBmYWxzZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJwYW5lbHNcIjoge1xuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAzLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDMsXG4gICAgICAgICAgICBcInNpbmdsZUNhbGxiYWNrQXJnXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZWxlbWVudHNcIjoge1xuICAgICAgICAgICAgXCJjcmVhdGVTaWRlYmFyUGFuZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiZG93bmxvYWRzXCI6IHtcbiAgICAgICAgXCJjYW5jZWxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZG93bmxvYWRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZXJhc2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0RmlsZUljb25cIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwib3BlblwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwicGF1c2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlRmlsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZXN1bWVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJleHRlbnNpb25cIjoge1xuICAgICAgICBcImlzQWxsb3dlZEZpbGVTY2hlbWVBY2Nlc3NcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwiaXNBbGxvd2VkSW5jb2duaXRvQWNjZXNzXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJoaXN0b3J5XCI6IHtcbiAgICAgICAgXCJhZGRVcmxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZGVsZXRlQWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcImRlbGV0ZVJhbmdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImRlbGV0ZVVybFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRWaXNpdHNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJpMThuXCI6IHtcbiAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBY2NlcHRMYW5ndWFnZXNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcImlkZW50aXR5XCI6IHtcbiAgICAgICAgXCJsYXVuY2hXZWJBdXRoRmxvd1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwiaWRsZVwiOiB7XG4gICAgICAgIFwicXVlcnlTdGF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwibWFuYWdlbWVudFwiOiB7XG4gICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRTZWxmXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInNldEVuYWJsZWRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwidW5pbnN0YWxsU2VsZlwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwibm90aWZpY2F0aW9uc1wiOiB7XG4gICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRQZXJtaXNzaW9uTGV2ZWxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJwYWdlQWN0aW9uXCI6IHtcbiAgICAgICAgXCJnZXRQb3B1cFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRUaXRsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJoaWRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRJY29uXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRUaXRsZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIFwic2hvd1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcInBlcm1pc3Npb25zXCI6IHtcbiAgICAgICAgXCJjb250YWluc1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInJlcXVlc3RcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcInJ1bnRpbWVcIjoge1xuICAgICAgICBcImdldEJhY2tncm91bmRQYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcImdldFBsYXRmb3JtSW5mb1wiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgfSxcbiAgICAgICAgXCJvcGVuT3B0aW9uc1BhZ2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVxdWVzdFVwZGF0ZUNoZWNrXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9LFxuICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICB9LFxuICAgICAgICBcInNlbmROYXRpdmVNZXNzYWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInNldFVuaW5zdGFsbFVSTFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwic2Vzc2lvbnNcIjoge1xuICAgICAgICBcImdldERldmljZXNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0UmVjZW50bHlDbG9zZWRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVzdG9yZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwic3RvcmFnZVwiOiB7XG4gICAgICAgIFwibG9jYWxcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwibWFuYWdlZFwiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwic3luY1wiOiB7XG4gICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIFwidGFic1wiOiB7XG4gICAgICAgIFwiY2FwdHVyZVZpc2libGVUYWJcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImRpc2NhcmRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZHVwbGljYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImV4ZWN1dGVTY3JpcHRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0Wm9vbVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ29CYWNrXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdvRm9yd2FyZFwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJoaWdobGlnaHRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiaW5zZXJ0Q1NTXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwicXVlcnlcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVsb2FkXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9LFxuICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJyZW1vdmVDU1NcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwic2VuZE1lc3NhZ2VcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAzXG4gICAgICAgIH0sXG4gICAgICAgIFwic2V0Wm9vbVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJ0b3BTaXRlc1wiOiB7XG4gICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgXCJ3ZWJOYXZpZ2F0aW9uXCI6IHtcbiAgICAgICAgXCJnZXRBbGxGcmFtZXNcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0RnJhbWVcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcIndlYlJlcXVlc3RcIjoge1xuICAgICAgICBcImhhbmRsZXJCZWhhdmlvckNoYW5nZWRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBcIndpbmRvd3NcIjoge1xuICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgfSxcbiAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwiZ2V0TGFzdEZvY3VzZWRcIjoge1xuICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgIH0sXG4gICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICB9LFxuICAgICAgICBcInVwZGF0ZVwiOiB7XG4gICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAoT2JqZWN0LmtleXMoYXBpTWV0YWRhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXBpLW1ldGFkYXRhLmpzb24gaGFzIG5vdCBiZWVuIGluY2x1ZGVkIGluIGJyb3dzZXItcG9seWZpbGxcIik7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQSBXZWFrTWFwIHN1YmNsYXNzIHdoaWNoIGNyZWF0ZXMgYW5kIHN0b3JlcyBhIHZhbHVlIGZvciBhbnkga2V5IHdoaWNoIGRvZXNcbiAgICAgKiBub3QgZXhpc3Qgd2hlbiBhY2Nlc3NlZCwgYnV0IGJlaGF2ZXMgZXhhY3RseSBhcyBhbiBvcmRpbmFyeSBXZWFrTWFwXG4gICAgICogb3RoZXJ3aXNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbn0gY3JlYXRlSXRlbVxuICAgICAqICAgICAgICBBIGZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIGluIG9yZGVyIHRvIGNyZWF0ZSB0aGUgdmFsdWUgZm9yIGFueVxuICAgICAqICAgICAgICBrZXkgd2hpY2ggZG9lcyBub3QgZXhpc3QsIHRoZSBmaXJzdCB0aW1lIGl0IGlzIGFjY2Vzc2VkLiBUaGVcbiAgICAgKiAgICAgICAgZnVuY3Rpb24gcmVjZWl2ZXMsIGFzIGl0cyBvbmx5IGFyZ3VtZW50LCB0aGUga2V5IGJlaW5nIGNyZWF0ZWQuXG4gICAgICovXG4gICAgY2xhc3MgRGVmYXVsdFdlYWtNYXAgZXh0ZW5kcyBXZWFrTWFwIHtcbiAgICAgIGNvbnN0cnVjdG9yKGNyZWF0ZUl0ZW0sIGl0ZW1zID0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHN1cGVyKGl0ZW1zKTtcbiAgICAgICAgdGhpcy5jcmVhdGVJdGVtID0gY3JlYXRlSXRlbTtcbiAgICAgIH1cblxuICAgICAgZ2V0KGtleSkge1xuICAgICAgICBpZiAoIXRoaXMuaGFzKGtleSkpIHtcbiAgICAgICAgICB0aGlzLnNldChrZXksIHRoaXMuY3JlYXRlSXRlbShrZXkpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBzdXBlci5nZXQoa2V5KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIG9iamVjdCBpcyBhbiBvYmplY3Qgd2l0aCBhIGB0aGVuYCBtZXRob2QsIGFuZCBjYW5cbiAgICAgKiB0aGVyZWZvcmUgYmUgYXNzdW1lZCB0byBiZWhhdmUgYXMgYSBQcm9taXNlLlxuICAgICAqXG4gICAgICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gdGVzdC5cbiAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgdGhlbmFibGUuXG4gICAgICovXG4gICAgY29uc3QgaXNUaGVuYWJsZSA9IHZhbHVlID0+IHtcbiAgICAgIHJldHVybiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhbmQgcmV0dXJucyBhIGZ1bmN0aW9uIHdoaWNoLCB3aGVuIGNhbGxlZCwgd2lsbCByZXNvbHZlIG9yIHJlamVjdFxuICAgICAqIHRoZSBnaXZlbiBwcm9taXNlIGJhc2VkIG9uIGhvdyBpdCBpcyBjYWxsZWQ6XG4gICAgICpcbiAgICAgKiAtIElmLCB3aGVuIGNhbGxlZCwgYGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcmAgY29udGFpbnMgYSBub24tbnVsbCBvYmplY3QsXG4gICAgICogICB0aGUgcHJvbWlzZSBpcyByZWplY3RlZCB3aXRoIHRoYXQgdmFsdWUuXG4gICAgICogLSBJZiB0aGUgZnVuY3Rpb24gaXMgY2FsbGVkIHdpdGggZXhhY3RseSBvbmUgYXJndW1lbnQsIHRoZSBwcm9taXNlIGlzXG4gICAgICogICByZXNvbHZlZCB0byB0aGF0IHZhbHVlLlxuICAgICAqIC0gT3RoZXJ3aXNlLCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB0byBhbiBhcnJheSBjb250YWluaW5nIGFsbCBvZiB0aGVcbiAgICAgKiAgIGZ1bmN0aW9uJ3MgYXJndW1lbnRzLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtvYmplY3R9IHByb21pc2VcbiAgICAgKiAgICAgICAgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIHJlc29sdXRpb24gYW5kIHJlamVjdGlvbiBmdW5jdGlvbnMgb2YgYVxuICAgICAqICAgICAgICBwcm9taXNlLlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IHByb21pc2UucmVzb2x2ZVxuICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlc29sdXRpb24gZnVuY3Rpb24uXG4gICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZWplY3RcbiAgICAgKiAgICAgICAgVGhlIHByb21pc2UncyByZWplY3Rpb24gZnVuY3Rpb24uXG4gICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSB3cmFwcGVkIG1ldGhvZCB3aGljaCBoYXMgY3JlYXRlZCB0aGUgY2FsbGJhY2suXG4gICAgICogQHBhcmFtIHtib29sZWFufSBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZ1xuICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICogICAgICAgIGFyZ3VtZW50IG9mIHRoZSBjYWxsYmFjaywgYWx0ZXJuYXRpdmVseSBhbiBhcnJheSBvZiBhbGwgdGhlXG4gICAgICogICAgICAgIGNhbGxiYWNrIGFyZ3VtZW50cyBpcyByZXNvbHZlZC4gQnkgZGVmYXVsdCwgaWYgdGhlIGNhbGxiYWNrXG4gICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgKiAgICAgICAgcmVzb2x2ZWQgdG8gdGhlIHByb21pc2UsIHdoaWxlIGFsbCBhcmd1bWVudHMgd2lsbCBiZSByZXNvbHZlZCBhc1xuICAgICAqICAgICAgICBhbiBhcnJheSBpZiBtdWx0aXBsZSBhcmUgZ2l2ZW4uXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb259XG4gICAgICogICAgICAgIFRoZSBnZW5lcmF0ZWQgY2FsbGJhY2sgZnVuY3Rpb24uXG4gICAgICovXG4gICAgY29uc3QgbWFrZUNhbGxiYWNrID0gKHByb21pc2UsIG1ldGFkYXRhKSA9PiB7XG4gICAgICByZXR1cm4gKC4uLmNhbGxiYWNrQXJncykgPT4ge1xuICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgIHByb21pc2UucmVqZWN0KG5ldyBFcnJvcihleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgfSBlbHNlIGlmIChtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyB8fFxuICAgICAgICAgICAgICAgICAgIChjYWxsYmFja0FyZ3MubGVuZ3RoIDw9IDEgJiYgbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmcgIT09IGZhbHNlKSkge1xuICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3NbMF0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3MpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH07XG5cbiAgICBjb25zdCBwbHVyYWxpemVBcmd1bWVudHMgPSAobnVtQXJncykgPT4gbnVtQXJncyA9PSAxID8gXCJhcmd1bWVudFwiIDogXCJhcmd1bWVudHNcIjtcblxuICAgIC8qKlxuICAgICAqIENyZWF0ZXMgYSB3cmFwcGVyIGZ1bmN0aW9uIGZvciBhIG1ldGhvZCB3aXRoIHRoZSBnaXZlbiBuYW1lIGFuZCBtZXRhZGF0YS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lXG4gICAgICogICAgICAgIFRoZSBuYW1lIG9mIHRoZSBtZXRob2Qgd2hpY2ggaXMgYmVpbmcgd3JhcHBlZC5cbiAgICAgKiBAcGFyYW0ge29iamVjdH0gbWV0YWRhdGFcbiAgICAgKiAgICAgICAgTWV0YWRhdGEgYWJvdXQgdGhlIG1ldGhvZCBiZWluZyB3cmFwcGVkLlxuICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWluQXJnc1xuICAgICAqICAgICAgICBUaGUgbWluaW11bSBudW1iZXIgb2YgYXJndW1lbnRzIHdoaWNoIG11c3QgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAqICAgICAgICBmdW5jdGlvbi4gSWYgY2FsbGVkIHdpdGggZmV3ZXIgdGhhbiB0aGlzIG51bWJlciBvZiBhcmd1bWVudHMsIHRoZVxuICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWF4QXJnc1xuICAgICAqICAgICAgICBUaGUgbWF4aW11bSBudW1iZXIgb2YgYXJndW1lbnRzIHdoaWNoIG1heSBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBtb3JlIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgKiAgICAgICAgd3JhcHBlciB3aWxsIHJhaXNlIGFuIGV4Y2VwdGlvbi5cbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnXG4gICAgICogICAgICAgIFdoZXRoZXIgb3Igbm90IHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHdpdGggb25seSB0aGUgZmlyc3RcbiAgICAgKiAgICAgICAgYXJndW1lbnQgb2YgdGhlIGNhbGxiYWNrLCBhbHRlcm5hdGl2ZWx5IGFuIGFycmF5IG9mIGFsbCB0aGVcbiAgICAgKiAgICAgICAgY2FsbGJhY2sgYXJndW1lbnRzIGlzIHJlc29sdmVkLiBCeSBkZWZhdWx0LCBpZiB0aGUgY2FsbGJhY2tcbiAgICAgKiAgICAgICAgZnVuY3Rpb24gaXMgaW52b2tlZCB3aXRoIG9ubHkgYSBzaW5nbGUgYXJndW1lbnQsIHRoYXQgd2lsbCBiZVxuICAgICAqICAgICAgICByZXNvbHZlZCB0byB0aGUgcHJvbWlzZSwgd2hpbGUgYWxsIGFyZ3VtZW50cyB3aWxsIGJlIHJlc29sdmVkIGFzXG4gICAgICogICAgICAgIGFuIGFycmF5IGlmIG11bHRpcGxlIGFyZSBnaXZlbi5cbiAgICAgKlxuICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbihvYmplY3QsIC4uLiopfVxuICAgICAqICAgICAgIFRoZSBnZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbi5cbiAgICAgKi9cbiAgICBjb25zdCB3cmFwQXN5bmNGdW5jdGlvbiA9IChuYW1lLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uIGFzeW5jRnVuY3Rpb25XcmFwcGVyKHRhcmdldCwgLi4uYXJncykge1xuICAgICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChhcmdzLmxlbmd0aCA+IG1ldGFkYXRhLm1heEFyZ3MpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGlmIChtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjaykge1xuICAgICAgICAgICAgLy8gVGhpcyBBUEkgbWV0aG9kIGhhcyBjdXJyZW50bHkgbm8gY2FsbGJhY2sgb24gQ2hyb21lLCBidXQgaXQgcmV0dXJuIGEgcHJvbWlzZSBvbiBGaXJlZm94LFxuICAgICAgICAgICAgLy8gYW5kIHNvIHRoZSBwb2x5ZmlsbCB3aWxsIHRyeSB0byBjYWxsIGl0IHdpdGggYSBjYWxsYmFjayBmaXJzdCwgYW5kIGl0IHdpbGwgZmFsbGJhY2tcbiAgICAgICAgICAgIC8vIHRvIG5vdCBwYXNzaW5nIHRoZSBjYWxsYmFjayBpZiB0aGUgZmlyc3QgY2FsbCBmYWlscy5cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzLCBtYWtlQ2FsbGJhY2soe3Jlc29sdmUsIHJlamVjdH0sIG1ldGFkYXRhKSk7XG4gICAgICAgICAgICB9IGNhdGNoIChjYkVycm9yKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtuYW1lfSBBUEkgbWV0aG9kIGRvZXNuJ3Qgc2VlbSB0byBzdXBwb3J0IHRoZSBjYWxsYmFjayBwYXJhbWV0ZXIsIGAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJmYWxsaW5nIGJhY2sgdG8gY2FsbCBpdCB3aXRob3V0IGEgY2FsbGJhY2s6IFwiLCBjYkVycm9yKTtcblxuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncyk7XG5cbiAgICAgICAgICAgICAgLy8gVXBkYXRlIHRoZSBBUEkgbWV0aG9kIG1ldGFkYXRhLCBzbyB0aGF0IHRoZSBuZXh0IEFQSSBjYWxscyB3aWxsIG5vdCB0cnkgdG9cbiAgICAgICAgICAgICAgLy8gdXNlIHRoZSB1bnN1cHBvcnRlZCBjYWxsYmFjayBhbnltb3JlLlxuICAgICAgICAgICAgICBtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjayA9IGZhbHNlO1xuICAgICAgICAgICAgICBtZXRhZGF0YS5ub0NhbGxiYWNrID0gdHJ1ZTtcblxuICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChtZXRhZGF0YS5ub0NhbGxiYWNrKSB7XG4gICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncyk7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzLCBtYWtlQ2FsbGJhY2soe3Jlc29sdmUsIHJlamVjdH0sIG1ldGFkYXRhKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH07XG4gICAgfTtcblxuICAgIC8qKlxuICAgICAqIFdyYXBzIGFuIGV4aXN0aW5nIG1ldGhvZCBvZiB0aGUgdGFyZ2V0IG9iamVjdCwgc28gdGhhdCBjYWxscyB0byBpdCBhcmVcbiAgICAgKiBpbnRlcmNlcHRlZCBieSB0aGUgZ2l2ZW4gd3JhcHBlciBmdW5jdGlvbi4gVGhlIHdyYXBwZXIgZnVuY3Rpb24gcmVjZWl2ZXMsXG4gICAgICogYXMgaXRzIGZpcnN0IGFyZ3VtZW50LCB0aGUgb3JpZ2luYWwgYHRhcmdldGAgb2JqZWN0LCBmb2xsb3dlZCBieSBlYWNoIG9mXG4gICAgICogdGhlIGFyZ3VtZW50cyBwYXNzZWQgdG8gdGhlIG9yaWdpbmFsIG1ldGhvZC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgKiAgICAgICAgVGhlIG9yaWdpbmFsIHRhcmdldCBvYmplY3QgdGhhdCB0aGUgd3JhcHBlZCBtZXRob2QgYmVsb25ncyB0by5cbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBtZXRob2RcbiAgICAgKiAgICAgICAgVGhlIG1ldGhvZCBiZWluZyB3cmFwcGVkLiBUaGlzIGlzIHVzZWQgYXMgdGhlIHRhcmdldCBvZiB0aGUgUHJveHlcbiAgICAgKiAgICAgICAgb2JqZWN0IHdoaWNoIGlzIGNyZWF0ZWQgdG8gd3JhcCB0aGUgbWV0aG9kLlxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IHdyYXBwZXJcbiAgICAgKiAgICAgICAgVGhlIHdyYXBwZXIgZnVuY3Rpb24gd2hpY2ggaXMgY2FsbGVkIGluIHBsYWNlIG9mIGEgZGlyZWN0IGludm9jYXRpb25cbiAgICAgKiAgICAgICAgb2YgdGhlIHdyYXBwZWQgbWV0aG9kLlxuICAgICAqXG4gICAgICogQHJldHVybnMge1Byb3h5PGZ1bmN0aW9uPn1cbiAgICAgKiAgICAgICAgQSBQcm94eSBvYmplY3QgZm9yIHRoZSBnaXZlbiBtZXRob2QsIHdoaWNoIGludm9rZXMgdGhlIGdpdmVuIHdyYXBwZXJcbiAgICAgKiAgICAgICAgbWV0aG9kIGluIGl0cyBwbGFjZS5cbiAgICAgKi9cbiAgICBjb25zdCB3cmFwTWV0aG9kID0gKHRhcmdldCwgbWV0aG9kLCB3cmFwcGVyKSA9PiB7XG4gICAgICByZXR1cm4gbmV3IFByb3h5KG1ldGhvZCwge1xuICAgICAgICBhcHBseSh0YXJnZXRNZXRob2QsIHRoaXNPYmosIGFyZ3MpIHtcbiAgICAgICAgICByZXR1cm4gd3JhcHBlci5jYWxsKHRoaXNPYmosIHRhcmdldCwgLi4uYXJncyk7XG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9O1xuXG4gICAgbGV0IGhhc093blByb3BlcnR5ID0gRnVuY3Rpb24uY2FsbC5iaW5kKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkpO1xuXG4gICAgLyoqXG4gICAgICogV3JhcHMgYW4gb2JqZWN0IGluIGEgUHJveHkgd2hpY2ggaW50ZXJjZXB0cyBhbmQgd3JhcHMgY2VydGFpbiBtZXRob2RzXG4gICAgICogYmFzZWQgb24gdGhlIGdpdmVuIGB3cmFwcGVyc2AgYW5kIGBtZXRhZGF0YWAgb2JqZWN0cy5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgKiAgICAgICAgVGhlIHRhcmdldCBvYmplY3QgdG8gd3JhcC5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbd3JhcHBlcnMgPSB7fV1cbiAgICAgKiAgICAgICAgQW4gb2JqZWN0IHRyZWUgY29udGFpbmluZyB3cmFwcGVyIGZ1bmN0aW9ucyBmb3Igc3BlY2lhbCBjYXNlcy4gQW55XG4gICAgICogICAgICAgIGZ1bmN0aW9uIHByZXNlbnQgaW4gdGhpcyBvYmplY3QgdHJlZSBpcyBjYWxsZWQgaW4gcGxhY2Ugb2YgdGhlXG4gICAgICogICAgICAgIG1ldGhvZCBpbiB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgYHRhcmdldGAgb2JqZWN0IHRyZWUuIFRoZXNlXG4gICAgICogICAgICAgIHdyYXBwZXIgbWV0aG9kcyBhcmUgaW52b2tlZCBhcyBkZXNjcmliZWQgaW4ge0BzZWUgd3JhcE1ldGhvZH0uXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge29iamVjdH0gW21ldGFkYXRhID0ge31dXG4gICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgbWV0YWRhdGEgdXNlZCB0byBhdXRvbWF0aWNhbGx5IGdlbmVyYXRlXG4gICAgICogICAgICAgIFByb21pc2UtYmFzZWQgd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFzeW5jaHJvbm91cy4gQW55IGZ1bmN0aW9uIGluXG4gICAgICogICAgICAgIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZSB3aGljaCBoYXMgYSBjb3JyZXNwb25kaW5nIG1ldGFkYXRhIG9iamVjdFxuICAgICAqICAgICAgICBpbiB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgYG1ldGFkYXRhYCB0cmVlIGlzIHJlcGxhY2VkIHdpdGggYW5cbiAgICAgKiAgICAgICAgYXV0b21hdGljYWxseS1nZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbiwgYXMgZGVzY3JpYmVkIGluXG4gICAgICogICAgICAgIHtAc2VlIHdyYXBBc3luY0Z1bmN0aW9ufVxuICAgICAqXG4gICAgICogQHJldHVybnMge1Byb3h5PG9iamVjdD59XG4gICAgICovXG4gICAgY29uc3Qgd3JhcE9iamVjdCA9ICh0YXJnZXQsIHdyYXBwZXJzID0ge30sIG1ldGFkYXRhID0ge30pID0+IHtcbiAgICAgIGxldCBjYWNoZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICBsZXQgaGFuZGxlcnMgPSB7XG4gICAgICAgIGhhcyhwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgIHJldHVybiBwcm9wIGluIHRhcmdldCB8fCBwcm9wIGluIGNhY2hlO1xuICAgICAgICB9LFxuXG4gICAgICAgIGdldChwcm94eVRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgcmV0dXJuIGNhY2hlW3Byb3BdO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmICghKHByb3AgaW4gdGFyZ2V0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBsZXQgdmFsdWUgPSB0YXJnZXRbcHJvcF07XG5cbiAgICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2Qgb24gdGhlIHVuZGVybHlpbmcgb2JqZWN0LiBDaGVjayBpZiB3ZSBuZWVkIHRvIGRvXG4gICAgICAgICAgICAvLyBhbnkgd3JhcHBpbmcuXG5cbiAgICAgICAgICAgIGlmICh0eXBlb2Ygd3JhcHBlcnNbcHJvcF0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAvLyBXZSBoYXZlIGEgc3BlY2lhbC1jYXNlIHdyYXBwZXIgZm9yIHRoaXMgbWV0aG9kLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXJzW3Byb3BdKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYW4gYXN5bmMgbWV0aG9kIHRoYXQgd2UgaGF2ZSBtZXRhZGF0YSBmb3IuIENyZWF0ZSBhXG4gICAgICAgICAgICAgIC8vIFByb21pc2Ugd3JhcHBlciBmb3IgaXQuXG4gICAgICAgICAgICAgIGxldCB3cmFwcGVyID0gd3JhcEFzeW5jRnVuY3Rpb24ocHJvcCwgbWV0YWRhdGFbcHJvcF0pO1xuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXIpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gVGhpcyBpcyBhIG1ldGhvZCB0aGF0IHdlIGRvbid0IGtub3cgb3IgY2FyZSBhYm91dC4gUmV0dXJuIHRoZVxuICAgICAgICAgICAgICAvLyBvcmlnaW5hbCBtZXRob2QsIGJvdW5kIHRvIHRoZSB1bmRlcmx5aW5nIG9iamVjdC5cbiAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5iaW5kKHRhcmdldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiZcbiAgICAgICAgICAgICAgICAgICAgIChoYXNPd25Qcm9wZXJ0eSh3cmFwcGVycywgcHJvcCkgfHxcbiAgICAgICAgICAgICAgICAgICAgICBoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpKSB7XG4gICAgICAgICAgICAvLyBUaGlzIGlzIGFuIG9iamVjdCB0aGF0IHdlIG5lZWQgdG8gZG8gc29tZSB3cmFwcGluZyBmb3IgdGhlIGNoaWxkcmVuXG4gICAgICAgICAgICAvLyBvZi4gQ3JlYXRlIGEgc3ViLW9iamVjdCB3cmFwcGVyIGZvciBpdCB3aXRoIHRoZSBhcHByb3ByaWF0ZSBjaGlsZFxuICAgICAgICAgICAgLy8gbWV0YWRhdGEuXG4gICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgXCIqXCIpKSB7XG4gICAgICAgICAgICAvLyBXcmFwIGFsbCBwcm9wZXJ0aWVzIGluICogbmFtZXNwYWNlLlxuICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbXCIqXCJdKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gV2UgZG9uJ3QgbmVlZCB0byBkbyBhbnkgd3JhcHBpbmcgZm9yIHRoaXMgcHJvcGVydHksXG4gICAgICAgICAgICAvLyBzbyBqdXN0IGZvcndhcmQgYWxsIGFjY2VzcyB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIHtcbiAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9LFxuXG4gICAgICAgIHNldChwcm94eVRhcmdldCwgcHJvcCwgdmFsdWUsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgaWYgKHByb3AgaW4gY2FjaGUpIHtcbiAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSxcblxuICAgICAgICBkZWZpbmVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCwgZGVzYykge1xuICAgICAgICAgIHJldHVybiBSZWZsZWN0LmRlZmluZVByb3BlcnR5KGNhY2hlLCBwcm9wLCBkZXNjKTtcbiAgICAgICAgfSxcblxuICAgICAgICBkZWxldGVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgIHJldHVybiBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KGNhY2hlLCBwcm9wKTtcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICAgIC8vIFBlciBjb250cmFjdCBvZiB0aGUgUHJveHkgQVBJLCB0aGUgXCJnZXRcIiBwcm94eSBoYW5kbGVyIG11c3QgcmV0dXJuIHRoZVxuICAgICAgLy8gb3JpZ2luYWwgdmFsdWUgb2YgdGhlIHRhcmdldCBpZiB0aGF0IHZhbHVlIGlzIGRlY2xhcmVkIHJlYWQtb25seSBhbmRcbiAgICAgIC8vIG5vbi1jb25maWd1cmFibGUuIEZvciB0aGlzIHJlYXNvbiwgd2UgY3JlYXRlIGFuIG9iamVjdCB3aXRoIHRoZVxuICAgICAgLy8gcHJvdG90eXBlIHNldCB0byBgdGFyZ2V0YCBpbnN0ZWFkIG9mIHVzaW5nIGB0YXJnZXRgIGRpcmVjdGx5LlxuICAgICAgLy8gT3RoZXJ3aXNlIHdlIGNhbm5vdCByZXR1cm4gYSBjdXN0b20gb2JqZWN0IGZvciBBUElzIHRoYXRcbiAgICAgIC8vIGFyZSBkZWNsYXJlZCByZWFkLW9ubHkgYW5kIG5vbi1jb25maWd1cmFibGUsIHN1Y2ggYXMgYGNocm9tZS5kZXZ0b29sc2AuXG4gICAgICAvL1xuICAgICAgLy8gVGhlIHByb3h5IGhhbmRsZXJzIHRoZW1zZWx2ZXMgd2lsbCBzdGlsbCB1c2UgdGhlIG9yaWdpbmFsIGB0YXJnZXRgXG4gICAgICAvLyBpbnN0ZWFkIG9mIHRoZSBgcHJveHlUYXJnZXRgLCBzbyB0aGF0IHRoZSBtZXRob2RzIGFuZCBwcm9wZXJ0aWVzIGFyZVxuICAgICAgLy8gZGVyZWZlcmVuY2VkIHZpYSB0aGUgb3JpZ2luYWwgdGFyZ2V0cy5cbiAgICAgIGxldCBwcm94eVRhcmdldCA9IE9iamVjdC5jcmVhdGUodGFyZ2V0KTtcbiAgICAgIHJldHVybiBuZXcgUHJveHkocHJveHlUYXJnZXQsIGhhbmRsZXJzKTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIHNldCBvZiB3cmFwcGVyIGZ1bmN0aW9ucyBmb3IgYW4gZXZlbnQgb2JqZWN0LCB3aGljaCBoYW5kbGVzXG4gICAgICogd3JhcHBpbmcgb2YgbGlzdGVuZXIgZnVuY3Rpb25zIHRoYXQgdGhvc2UgbWVzc2FnZXMgYXJlIHBhc3NlZC5cbiAgICAgKlxuICAgICAqIEEgc2luZ2xlIHdyYXBwZXIgaXMgY3JlYXRlZCBmb3IgZWFjaCBsaXN0ZW5lciBmdW5jdGlvbiwgYW5kIHN0b3JlZCBpbiBhXG4gICAgICogbWFwLiBTdWJzZXF1ZW50IGNhbGxzIHRvIGBhZGRMaXN0ZW5lcmAsIGBoYXNMaXN0ZW5lcmAsIG9yIGByZW1vdmVMaXN0ZW5lcmBcbiAgICAgKiByZXRyaWV2ZSB0aGUgb3JpZ2luYWwgd3JhcHBlciwgc28gdGhhdCAgYXR0ZW1wdHMgdG8gcmVtb3ZlIGFcbiAgICAgKiBwcmV2aW91c2x5LWFkZGVkIGxpc3RlbmVyIHdvcmsgYXMgZXhwZWN0ZWQuXG4gICAgICpcbiAgICAgKiBAcGFyYW0ge0RlZmF1bHRXZWFrTWFwPGZ1bmN0aW9uLCBmdW5jdGlvbj59IHdyYXBwZXJNYXBcbiAgICAgKiAgICAgICAgQSBEZWZhdWx0V2Vha01hcCBvYmplY3Qgd2hpY2ggd2lsbCBjcmVhdGUgdGhlIGFwcHJvcHJpYXRlIHdyYXBwZXJcbiAgICAgKiAgICAgICAgZm9yIGEgZ2l2ZW4gbGlzdGVuZXIgZnVuY3Rpb24gd2hlbiBvbmUgZG9lcyBub3QgZXhpc3QsIGFuZCByZXRyaWV2ZVxuICAgICAqICAgICAgICBhbiBleGlzdGluZyBvbmUgd2hlbiBpdCBkb2VzLlxuICAgICAqXG4gICAgICogQHJldHVybnMge29iamVjdH1cbiAgICAgKi9cbiAgICBjb25zdCB3cmFwRXZlbnQgPSB3cmFwcGVyTWFwID0+ICh7XG4gICAgICBhZGRMaXN0ZW5lcih0YXJnZXQsIGxpc3RlbmVyLCAuLi5hcmdzKSB7XG4gICAgICAgIHRhcmdldC5hZGRMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lciksIC4uLmFyZ3MpO1xuICAgICAgfSxcblxuICAgICAgaGFzTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICByZXR1cm4gdGFyZ2V0Lmhhc0xpc3RlbmVyKHdyYXBwZXJNYXAuZ2V0KGxpc3RlbmVyKSk7XG4gICAgICB9LFxuXG4gICAgICByZW1vdmVMaXN0ZW5lcih0YXJnZXQsIGxpc3RlbmVyKSB7XG4gICAgICAgIHRhcmdldC5yZW1vdmVMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgfSxcbiAgICB9KTtcblxuICAgIGNvbnN0IG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMgPSBuZXcgRGVmYXVsdFdlYWtNYXAobGlzdGVuZXIgPT4ge1xuICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJldHVybiBsaXN0ZW5lcjtcbiAgICAgIH1cblxuICAgICAgLyoqXG4gICAgICAgKiBXcmFwcyBhbiBvblJlcXVlc3RGaW5pc2hlZCBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IHdpbGwgcmV0dXJuIGFcbiAgICAgICAqIGBnZXRDb250ZW50KClgIHByb3BlcnR5IHdoaWNoIHJldHVybnMgYSBgUHJvbWlzZWAgcmF0aGVyIHRoYW4gdXNpbmcgYVxuICAgICAgICogY2FsbGJhY2sgQVBJLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSByZXFcbiAgICAgICAqICAgICAgICBUaGUgSEFSIGVudHJ5IG9iamVjdCByZXByZXNlbnRpbmcgdGhlIG5ldHdvcmsgcmVxdWVzdC5cbiAgICAgICAqL1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uUmVxdWVzdEZpbmlzaGVkKHJlcSkge1xuICAgICAgICBjb25zdCB3cmFwcGVkUmVxID0gd3JhcE9iamVjdChyZXEsIHt9IC8qIHdyYXBwZXJzICovLCB7XG4gICAgICAgICAgZ2V0Q29udGVudDoge1xuICAgICAgICAgICAgbWluQXJnczogMCxcbiAgICAgICAgICAgIG1heEFyZ3M6IDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGxpc3RlbmVyKHdyYXBwZWRSZXEpO1xuICAgICAgfTtcbiAgICB9KTtcblxuICAgIGNvbnN0IG9uTWVzc2FnZVdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm4gbGlzdGVuZXI7XG4gICAgICB9XG5cbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYSBtZXNzYWdlIGxpc3RlbmVyIGZ1bmN0aW9uIHNvIHRoYXQgaXQgbWF5IHNlbmQgcmVzcG9uc2VzIGJhc2VkIG9uXG4gICAgICAgKiBpdHMgcmV0dXJuIHZhbHVlLCByYXRoZXIgdGhhbiBieSByZXR1cm5pbmcgYSBzZW50aW5lbCB2YWx1ZSBhbmQgY2FsbGluZyBhXG4gICAgICAgKiBjYWxsYmFjay4gSWYgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHJldHVybnMgYSBQcm9taXNlLCB0aGUgcmVzcG9uc2UgaXNcbiAgICAgICAqIHNlbnQgd2hlbiB0aGUgcHJvbWlzZSBlaXRoZXIgcmVzb2x2ZXMgb3IgcmVqZWN0cy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0geyp9IG1lc3NhZ2VcbiAgICAgICAqICAgICAgICBUaGUgbWVzc2FnZSBzZW50IGJ5IHRoZSBvdGhlciBlbmQgb2YgdGhlIGNoYW5uZWwuXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gc2VuZGVyXG4gICAgICAgKiAgICAgICAgRGV0YWlscyBhYm91dCB0aGUgc2VuZGVyIG9mIHRoZSBtZXNzYWdlLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbigqKX0gc2VuZFJlc3BvbnNlXG4gICAgICAgKiAgICAgICAgQSBjYWxsYmFjayB3aGljaCwgd2hlbiBjYWxsZWQgd2l0aCBhbiBhcmJpdHJhcnkgYXJndW1lbnQsIHNlbmRzXG4gICAgICAgKiAgICAgICAgdGhhdCB2YWx1ZSBhcyBhIHJlc3BvbnNlLlxuICAgICAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAgICAgKiAgICAgICAgVHJ1ZSBpZiB0aGUgd3JhcHBlZCBsaXN0ZW5lciByZXR1cm5lZCBhIFByb21pc2UsIHdoaWNoIHdpbGwgbGF0ZXJcbiAgICAgICAqICAgICAgICB5aWVsZCBhIHJlc3BvbnNlLiBGYWxzZSBvdGhlcndpc2UuXG4gICAgICAgKi9cbiAgICAgIHJldHVybiBmdW5jdGlvbiBvbk1lc3NhZ2UobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgbGV0IGRpZENhbGxTZW5kUmVzcG9uc2UgPSBmYWxzZTtcblxuICAgICAgICBsZXQgd3JhcHBlZFNlbmRSZXNwb25zZTtcbiAgICAgICAgbGV0IHNlbmRSZXNwb25zZVByb21pc2UgPSBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICB3cmFwcGVkU2VuZFJlc3BvbnNlID0gZnVuY3Rpb24ocmVzcG9uc2UpIHtcbiAgICAgICAgICAgIGRpZENhbGxTZW5kUmVzcG9uc2UgPSB0cnVlO1xuICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbGV0IHJlc3VsdDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXN1bHQgPSBsaXN0ZW5lcihtZXNzYWdlLCBzZW5kZXIsIHdyYXBwZWRTZW5kUmVzcG9uc2UpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICByZXN1bHQgPSBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaXNSZXN1bHRUaGVuYWJsZSA9IHJlc3VsdCAhPT0gdHJ1ZSAmJiBpc1RoZW5hYmxlKHJlc3VsdCk7XG5cbiAgICAgICAgLy8gSWYgdGhlIGxpc3RlbmVyIGRpZG4ndCByZXR1cm5lZCB0cnVlIG9yIGEgUHJvbWlzZSwgb3IgY2FsbGVkXG4gICAgICAgIC8vIHdyYXBwZWRTZW5kUmVzcG9uc2Ugc3luY2hyb25vdXNseSwgd2UgY2FuIGV4aXQgZWFybGllclxuICAgICAgICAvLyBiZWNhdXNlIHRoZXJlIHdpbGwgYmUgbm8gcmVzcG9uc2Ugc2VudCBmcm9tIHRoaXMgbGlzdGVuZXIuXG4gICAgICAgIGlmIChyZXN1bHQgIT09IHRydWUgJiYgIWlzUmVzdWx0VGhlbmFibGUgJiYgIWRpZENhbGxTZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBIHNtYWxsIGhlbHBlciB0byBzZW5kIHRoZSBtZXNzYWdlIGlmIHRoZSBwcm9taXNlIHJlc29sdmVzXG4gICAgICAgIC8vIGFuZCBhbiBlcnJvciBpZiB0aGUgcHJvbWlzZSByZWplY3RzIChhIHdyYXBwZWQgc2VuZE1lc3NhZ2UgaGFzXG4gICAgICAgIC8vIHRvIHRyYW5zbGF0ZSB0aGUgbWVzc2FnZSBpbnRvIGEgcmVzb2x2ZWQgcHJvbWlzZSBvciBhIHJlamVjdGVkXG4gICAgICAgIC8vIHByb21pc2UpLlxuICAgICAgICBjb25zdCBzZW5kUHJvbWlzZWRSZXN1bHQgPSAocHJvbWlzZSkgPT4ge1xuICAgICAgICAgIHByb21pc2UudGhlbihtc2cgPT4ge1xuICAgICAgICAgICAgLy8gc2VuZCB0aGUgbWVzc2FnZSB2YWx1ZS5cbiAgICAgICAgICAgIHNlbmRSZXNwb25zZShtc2cpO1xuICAgICAgICAgIH0sIGVycm9yID0+IHtcbiAgICAgICAgICAgIC8vIFNlbmQgYSBKU09OIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBlcnJvciBpZiB0aGUgcmVqZWN0ZWQgdmFsdWVcbiAgICAgICAgICAgIC8vIGlzIGFuIGluc3RhbmNlIG9mIGVycm9yLCBvciB0aGUgb2JqZWN0IGl0c2VsZiBvdGhlcndpc2UuXG4gICAgICAgICAgICBsZXQgbWVzc2FnZTtcbiAgICAgICAgICAgIGlmIChlcnJvciAmJiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciB8fFxuICAgICAgICAgICAgICAgIHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSBcInN0cmluZ1wiKSkge1xuICAgICAgICAgICAgICBtZXNzYWdlID0gZXJyb3IubWVzc2FnZTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIG1lc3NhZ2UgPSBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWRcIjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fOiB0cnVlLFxuICAgICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSkuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgICAgIC8vIFByaW50IGFuIGVycm9yIG9uIHRoZSBjb25zb2xlIGlmIHVuYWJsZSB0byBzZW5kIHRoZSByZXNwb25zZS5cbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBvbk1lc3NhZ2UgcmVqZWN0ZWQgcmVwbHlcIiwgZXJyKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBJZiB0aGUgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCBzZW5kIHRoZSByZXNvbHZlZCB2YWx1ZSBhcyBhXG4gICAgICAgIC8vIHJlc3VsdCwgb3RoZXJ3aXNlIHdhaXQgdGhlIHByb21pc2UgcmVsYXRlZCB0byB0aGUgd3JhcHBlZFNlbmRSZXNwb25zZVxuICAgICAgICAvLyBjYWxsYmFjayB0byByZXNvbHZlIGFuZCBzZW5kIGl0IGFzIGEgcmVzcG9uc2UuXG4gICAgICAgIGlmIChpc1Jlc3VsdFRoZW5hYmxlKSB7XG4gICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHJlc3VsdCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHNlbmRSZXNwb25zZVByb21pc2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gTGV0IENocm9tZSBrbm93IHRoYXQgdGhlIGxpc3RlbmVyIGlzIHJlcGx5aW5nLlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjayA9ICh7cmVqZWN0LCByZXNvbHZlfSwgcmVwbHkpID0+IHtcbiAgICAgIGlmIChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgIC8vIERldGVjdCB3aGVuIG5vbmUgb2YgdGhlIGxpc3RlbmVycyByZXBsaWVkIHRvIHRoZSBzZW5kTWVzc2FnZSBjYWxsIGFuZCByZXNvbHZlXG4gICAgICAgIC8vIHRoZSBwcm9taXNlIHRvIHVuZGVmaW5lZCBhcyBpbiBGaXJlZm94LlxuICAgICAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL21vemlsbGEvd2ViZXh0ZW5zaW9uLXBvbHlmaWxsL2lzc3Vlcy8xMzBcbiAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSA9PT0gQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFKSB7XG4gICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAocmVwbHkgJiYgcmVwbHkuX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fKSB7XG4gICAgICAgIC8vIENvbnZlcnQgYmFjayB0aGUgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaW50b1xuICAgICAgICAvLyBhbiBFcnJvciBpbnN0YW5jZS5cbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihyZXBseS5tZXNzYWdlKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKHJlcGx5KTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3Qgd3JhcHBlZFNlbmRNZXNzYWdlID0gKG5hbWUsIG1ldGFkYXRhLCBhcGlOYW1lc3BhY2VPYmosIC4uLmFyZ3MpID0+IHtcbiAgICAgIGlmIChhcmdzLmxlbmd0aCA8IG1ldGFkYXRhLm1pbkFyZ3MpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gbWV0YWRhdGEubWF4QXJncykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHdyYXBwZWRDYiA9IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrLmJpbmQobnVsbCwge3Jlc29sdmUsIHJlamVjdH0pO1xuICAgICAgICBhcmdzLnB1c2god3JhcHBlZENiKTtcbiAgICAgICAgYXBpTmFtZXNwYWNlT2JqLnNlbmRNZXNzYWdlKC4uLmFyZ3MpO1xuICAgICAgfSk7XG4gICAgfTtcblxuICAgIGNvbnN0IHN0YXRpY1dyYXBwZXJzID0ge1xuICAgICAgZGV2dG9vbHM6IHtcbiAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgIG9uUmVxdWVzdEZpbmlzaGVkOiB3cmFwRXZlbnQob25SZXF1ZXN0RmluaXNoZWRXcmFwcGVycyksXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgcnVudGltZToge1xuICAgICAgICBvbk1lc3NhZ2U6IHdyYXBFdmVudChvbk1lc3NhZ2VXcmFwcGVycyksXG4gICAgICAgIG9uTWVzc2FnZUV4dGVybmFsOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7bWluQXJnczogMSwgbWF4QXJnczogM30pLFxuICAgICAgfSxcbiAgICAgIHRhYnM6IHtcbiAgICAgICAgc2VuZE1lc3NhZ2U6IHdyYXBwZWRTZW5kTWVzc2FnZS5iaW5kKG51bGwsIFwic2VuZE1lc3NhZ2VcIiwge21pbkFyZ3M6IDIsIG1heEFyZ3M6IDN9KSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBjb25zdCBzZXR0aW5nTWV0YWRhdGEgPSB7XG4gICAgICBjbGVhcjoge21pbkFyZ3M6IDEsIG1heEFyZ3M6IDF9LFxuICAgICAgZ2V0OiB7bWluQXJnczogMSwgbWF4QXJnczogMX0sXG4gICAgICBzZXQ6IHttaW5BcmdzOiAxLCBtYXhBcmdzOiAxfSxcbiAgICB9O1xuICAgIGFwaU1ldGFkYXRhLnByaXZhY3kgPSB7XG4gICAgICBuZXR3b3JrOiB7XCIqXCI6IHNldHRpbmdNZXRhZGF0YX0sXG4gICAgICBzZXJ2aWNlczoge1wiKlwiOiBzZXR0aW5nTWV0YWRhdGF9LFxuICAgICAgd2Vic2l0ZXM6IHtcIipcIjogc2V0dGluZ01ldGFkYXRhfSxcbiAgICB9O1xuXG4gICAgcmV0dXJuIHdyYXBPYmplY3QoZXh0ZW5zaW9uQVBJcywgc3RhdGljV3JhcHBlcnMsIGFwaU1ldGFkYXRhKTtcbiAgfTtcblxuICAvLyBUaGUgYnVpbGQgcHJvY2VzcyBhZGRzIGEgVU1EIHdyYXBwZXIgYXJvdW5kIHRoaXMgZmlsZSwgd2hpY2ggbWFrZXMgdGhlXG4gIC8vIGBtb2R1bGVgIHZhcmlhYmxlIGF2YWlsYWJsZS5cbiAgbW9kdWxlLmV4cG9ydHMgPSB3cmFwQVBJcyhjaHJvbWUpO1xufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzLmJyb3dzZXI7XG59XG4iLCJleHBvcnQgY29uc3QgaWNvbl9zdW4gPSBgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIGNsYXNzPVwiaWNvbiBpY29uLXRhYmxlciBpY29ucy10YWJsZXItb3V0bGluZSBpY29uLXRhYmxlci1zdW5cIj48cGF0aCBzdHJva2U9XCJub25lXCIgZD1cIk0wIDBoMjR2MjRIMHpcIiBmaWxsPVwibm9uZVwiIC8+PHBhdGggZD1cIk0xMiAxMm0tNCAwYTQgNCAwIDEgMCA4IDBhNCA0IDAgMSAwIC04IDBcIiAvPjxwYXRoIGQ9XCJNMyAxMmgxbTggLTl2MW04IDhoMW0tOSA4djFtLTYuNCAtMTUuNGwuNyAuN20xMi4xIC0uN2wtLjcgLjdtMCAxMS40bC43IC43bS0xMi4xIC0uN2wtLjcgLjdcIiAvPjwvc3ZnPmBcclxuXHJcbmV4cG9ydCBjb25zdCBpY29uX21vb24gPSBgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIGNsYXNzPVwiaWNvbiBpY29uLXRhYmxlciBpY29ucy10YWJsZXItb3V0bGluZSBpY29uLXRhYmxlci1tb29uXCI+PHBhdGggc3Ryb2tlPVwibm9uZVwiIGQ9XCJNMCAwaDI0djI0SDB6XCIgZmlsbD1cIm5vbmVcIi8+PHBhdGggZD1cIk0xMiAzYy4xMzIgMCAuMjYzIDAgLjM5MyAwYTcuNSA3LjUgMCAwIDAgNy45MiAxMi40NDZhOSA5IDAgMSAxIC04LjMxMyAtMTIuNDU0elwiIC8+PC9zdmc+YFxyXG5cclxuZXhwb3J0IGNvbnN0IGljb25fbW9vbl9mdWxsID0gYDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHdpZHRoPVwiMjRcIiBoZWlnaHQ9XCIyNFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZS13aWR0aD1cIjJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBjbGFzcz1cImljb24gaWNvbi10YWJsZXIgaWNvbnMtdGFibGVyLW91dGxpbmUgaWNvbi10YWJsZXItbW9vbi0yXCI+PHBhdGggc3Ryb2tlPVwibm9uZVwiIGQ9XCJNMCAwaDI0djI0SDB6XCIgZmlsbD1cIm5vbmVcIi8+PHBhdGggZD1cIk0xNi40MTggNC4xNTdhOCA4IDAgMCAwIDAgMTUuNjg2XCIgLz48cGF0aCBkPVwiTTEyIDEybS05IDBhOSA5IDAgMSAwIDE4IDBhOSA5IDAgMSAwIC0xOCAwXCIgLz48L3N2Zz5gXHJcblxyXG5leHBvcnQgY29uc3QgaWNvbl9zZXR0aW5ncyA9IGA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgY2xhc3M9XCJpY29uIGljb24tdGFibGVyIGljb25zLXRhYmxlci1vdXRsaW5lIGljb24tdGFibGVyLXNldHRpbmdzXCI+PHBhdGggc3Ryb2tlPVwibm9uZVwiIGQ9XCJNMCAwaDI0djI0SDB6XCIgZmlsbD1cIm5vbmVcIi8+PHBhdGggZD1cIk0xMC4zMjUgNC4zMTdjLjQyNiAtMS43NTYgMi45MjQgLTEuNzU2IDMuMzUgMGExLjcyNCAxLjcyNCAwIDAgMCAyLjU3MyAxLjA2NmMxLjU0MyAtLjk0IDMuMzEgLjgyNiAyLjM3IDIuMzdhMS43MjQgMS43MjQgMCAwIDAgMS4wNjUgMi41NzJjMS43NTYgLjQyNiAxLjc1NiAyLjkyNCAwIDMuMzVhMS43MjQgMS43MjQgMCAwIDAgLTEuMDY2IDIuNTczYy45NCAxLjU0MyAtLjgyNiAzLjMxIC0yLjM3IDIuMzdhMS43MjQgMS43MjQgMCAwIDAgLTIuNTcyIDEuMDY1Yy0uNDI2IDEuNzU2IC0yLjkyNCAxLjc1NiAtMy4zNSAwYTEuNzI0IDEuNzI0IDAgMCAwIC0yLjU3MyAtMS4wNjZjLTEuNTQzIC45NCAtMy4zMSAtLjgyNiAtMi4zNyAtMi4zN2ExLjcyNCAxLjcyNCAwIDAgMCAtMS4wNjUgLTIuNTcyYy0xLjc1NiAtLjQyNiAtMS43NTYgLTIuOTI0IDAgLTMuMzVhMS43MjQgMS43MjQgMCAwIDAgMS4wNjYgLTIuNTczYy0uOTQgLTEuNTQzIC44MjYgLTMuMzEgMi4zNyAtMi4zN2MxIC42MDggMi4yOTYgLjA3IDIuNTcyIC0xLjA2NXpcIiAvPjxwYXRoIGQ9XCJNOSAxMmEzIDMgMCAxIDAgNiAwYTMgMyAwIDAgMCAtNiAwXCIgLz48L3N2Zz5gXHJcblxyXG5leHBvcnQgY29uc3QgaWNvbl9wYWludCA9IGA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2Utd2lkdGg9XCIyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgY2xhc3M9XCJpY29uIGljb24tdGFibGVyIGljb25zLXRhYmxlci1vdXRsaW5lIGljb24tdGFibGVyLXBhaW50XCI+PHBhdGggc3Ryb2tlPVwibm9uZVwiIGQ9XCJNMCAwaDI0djI0SDB6XCIgZmlsbD1cIm5vbmVcIi8+PHBhdGggZD1cIk01IDNtMCAyYTIgMiAwIDAgMSAyIC0yaDEwYTIgMiAwIDAgMSAyIDJ2MmEyIDIgMCAwIDEgLTIgMmgtMTBhMiAyIDAgMCAxIC0yIC0yelwiIC8+PHBhdGggZD1cIk0xOSA2aDFhMiAyIDAgMCAxIDIgMmE1IDUgMCAwIDEgLTUgNWwtNSAwdjJcIiAvPjxwYXRoIGQ9XCJNMTAgMTVtMCAxYTEgMSAwIDAgMSAxIC0xaDJhMSAxIDAgMCAxIDEgMXY0YTEgMSAwIDAgMSAtMSAxaC0yYTEgMSAwIDAgMSAtMSAtMXpcIiAvPjwvc3ZnPmBcclxuXHJcbmV4cG9ydCBjb25zdCBpY29uX3BhbGV0dGUgPSBgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgd2lkdGg9XCIyNFwiIGhlaWdodD1cIjI0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlLXdpZHRoPVwiMlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIGNsYXNzPVwiaWNvbiBpY29uLXRhYmxlciBpY29ucy10YWJsZXItb3V0bGluZSBpY29uLXRhYmxlci1wYWxldHRlXCI+PHBhdGggc3Ryb2tlPVwibm9uZVwiIGQ9XCJNMCAwaDI0djI0SDB6XCIgZmlsbD1cIm5vbmVcIi8+PHBhdGggZD1cIk0xMiAyMWE5IDkgMCAwIDEgMCAtMThjNC45NyAwIDkgMy41ODIgOSA4YzAgMS4wNiAtLjQ3NCAyLjA3OCAtMS4zMTggMi44MjhjLS44NDQgLjc1IC0xLjk4OSAxLjE3MiAtMy4xODIgMS4xNzJoLTIuNWEyIDIgMCAwIDAgLTEgMy43NWExLjMgMS4zIDAgMCAxIC0xIDIuMjVcIiAvPjxwYXRoIGQ9XCJNOC41IDEwLjVtLTEgMGExIDEgMCAxIDAgMiAwYTEgMSAwIDEgMCAtMiAwXCIgLz48cGF0aCBkPVwiTTEyLjUgNy41bS0xIDBhMSAxIDAgMSAwIDIgMGExIDEgMCAxIDAgLTIgMFwiIC8+PHBhdGggZD1cIk0xNi41IDEwLjVtLTEgMGExIDEgMCAxIDAgMiAwYTEgMSAwIDEgMCAtMiAwXCIgLz48L3N2Zz5gXHJcbiIsImV4cG9ydHMuaW50ZXJvcERlZmF1bHQgPSBmdW5jdGlvbiAoYSkge1xuICByZXR1cm4gYSAmJiBhLl9fZXNNb2R1bGUgPyBhIDoge2RlZmF1bHQ6IGF9O1xufTtcblxuZXhwb3J0cy5kZWZpbmVJbnRlcm9wRmxhZyA9IGZ1bmN0aW9uIChhKSB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhLCAnX19lc01vZHVsZScsIHt2YWx1ZTogdHJ1ZX0pO1xufTtcblxuZXhwb3J0cy5leHBvcnRBbGwgPSBmdW5jdGlvbiAoc291cmNlLCBkZXN0KSB7XG4gIE9iamVjdC5rZXlzKHNvdXJjZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgaWYgKFxuICAgICAga2V5ID09PSAnZGVmYXVsdCcgfHxcbiAgICAgIGtleSA9PT0gJ19fZXNNb2R1bGUnIHx8XG4gICAgICBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZGVzdCwga2V5KVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkZXN0LCBrZXksIHtcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZVtrZXldO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgcmV0dXJuIGRlc3Q7XG59O1xuXG5leHBvcnRzLmV4cG9ydCA9IGZ1bmN0aW9uIChkZXN0LCBkZXN0TmFtZSwgZ2V0KSB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkZXN0LCBkZXN0TmFtZSwge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBnZXQsXG4gIH0pO1xufTtcbiIsImV4cG9ydCBmdW5jdGlvbiBoZXhUb0hTTChoZXgpIHtcclxuXHQvLyBDb252ZXJ0IGhleCB0byBSR0IgZmlyc3RcclxuXHRsZXQgciA9IDAsXHJcblx0XHRnID0gMCxcclxuXHRcdGIgPSAwXHJcblx0aWYgKGhleC5sZW5ndGggPT09IDQpIHtcclxuXHRcdHIgPSBwYXJzZUludChoZXhbMV0gKyBoZXhbMV0sIDE2KVxyXG5cdFx0ZyA9IHBhcnNlSW50KGhleFsyXSArIGhleFsyXSwgMTYpXHJcblx0XHRiID0gcGFyc2VJbnQoaGV4WzNdICsgaGV4WzNdLCAxNilcclxuXHR9IGVsc2UgaWYgKGhleC5sZW5ndGggPT09IDcpIHtcclxuXHRcdHIgPSBwYXJzZUludChoZXguc2xpY2UoMSwgMyksIDE2KVxyXG5cdFx0ZyA9IHBhcnNlSW50KGhleC5zbGljZSgzLCA1KSwgMTYpXHJcblx0XHRiID0gcGFyc2VJbnQoaGV4LnNsaWNlKDUsIDcpLCAxNilcclxuXHR9XHJcblxyXG5cdC8vIFRoZW4gY29udmVydCBSR0IgdG8gSFNMXHJcblx0ciAvPSAyNTVcclxuXHRnIC89IDI1NVxyXG5cdGIgLz0gMjU1XHJcblx0Y29uc3QgbWF4ID0gTWF0aC5tYXgociwgZywgYilcclxuXHRjb25zdCBtaW4gPSBNYXRoLm1pbihyLCBnLCBiKVxyXG5cdGxldCBoLFxyXG5cdFx0cyxcclxuXHRcdGwgPSAobWF4ICsgbWluKSAvIDJcclxuXHJcblx0aWYgKG1heCA9PT0gbWluKSB7XHJcblx0XHRoID0gcyA9IDAgLy8gYWNocm9tYXRpY1xyXG5cdH0gZWxzZSB7XHJcblx0XHRjb25zdCBkID0gbWF4IC0gbWluXHJcblx0XHRzID0gbCA+IDAuNSA/IGQgLyAoMiAtIG1heCAtIG1pbikgOiBkIC8gKG1heCArIG1pbilcclxuXHRcdHN3aXRjaCAobWF4KSB7XHJcblx0XHRcdGNhc2UgcjpcclxuXHRcdFx0XHRoID0gKGcgLSBiKSAvIGQgKyAoZyA8IGIgPyA2IDogMClcclxuXHRcdFx0XHRicmVha1xyXG5cdFx0XHRjYXNlIGc6XHJcblx0XHRcdFx0aCA9IChiIC0gcikgLyBkICsgMlxyXG5cdFx0XHRcdGJyZWFrXHJcblx0XHRcdGNhc2UgYjpcclxuXHRcdFx0XHRoID0gKHIgLSBnKSAvIGQgKyA0XHJcblx0XHRcdFx0YnJlYWtcclxuXHRcdH1cclxuXHRcdGggLz0gNlxyXG5cdH1cclxuXHJcblx0cmV0dXJuIFtNYXRoLnJvdW5kKGggKiAzNjApLCBNYXRoLnJvdW5kKHMgKiAxMDApLCBNYXRoLnJvdW5kKGwgKiAxMDApXVxyXG59XHJcbiIsIi8vIG1haW4uanNcclxuaW1wb3J0IGJyb3dzZXIgZnJvbSAnd2ViZXh0ZW5zaW9uLXBvbHlmaWxsJ1xyXG5pbXBvcnQgeyByZW5kZXJGb250U21hbGxDYXJkLCByZW5kZXJGb250QmlnQ2FyZCwgcmVuZGVyQnV0dG9uIH0gZnJvbSAnLi9jb21wb25lbnRzL3JlbmRlckZvbnRzJ1xyXG5cclxuLy8gQ29uc3RhbnRzXHJcbmNvbnN0IERFRkFVTFRTID0ge1xyXG5cdGZvbnRGYW1pbHk6IGdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5nZXRQcm9wZXJ0eVZhbHVlKCctLWZvbnRGYW1pbHlEZWZhdWx0JyksXHJcblx0Zm9udFNpemU6IDE2LFxyXG5cdGxldHRlclNwYWNpbmc6IDAsXHJcblx0bGluZUhlaWdodDogMjgsXHJcbn1cclxuXHJcbmNvbnN0IEZPTlRfTkFNRVMgPSBbXHJcblx0J0RlZmF1bHQnLFxyXG5cdCdJbnRlcicsXHJcblx0J1JvYm90bycsXHJcblx0J1JvYm90byBNb25vJyxcclxuXHQnRE0gU2FucycsXHJcblx0J1JlZGRpdCBNb25vJyxcclxuXHQnUG9wcGlucycsXHJcblx0J05vdG8gU2FucycsXHJcblx0J0xhdG8nLFxyXG5cdCdRdWlja3NhbmQnLFxyXG5cdCdPdXRmaXQnLFxyXG5dXHJcblxyXG4vLyBjb25zdCBHT09HTEVfRk9OVF9XRUlHSFRTID0gYDppdGFsLHdnaHRAMCwxMDA7MCwyMDA7MCwzMDA7MCw0MDA7MCw1MDA7MCw2MDA7MCw3MDA7MCw4MDA7MCw5MDA7MSwxMDA7MSwyMDA7MSwzMDA7MSw0MDA7MSw1MDA7MSw2MDA7MSw3MDA7MSw4MDA7MSw5MDBgXHJcbmNvbnN0IEdPT0dMRV9GT05UX1dFSUdIVFMgPSBgOml0YWwsd2dodEAwLDEwMDswLDMwMDswLDQwMDswLDUwMDswLDYwMDswLDcwMDsxLDEwMDsxLDMwMDsxLDQwMDsxLDUwMDsxLDYwMDsxLDcwMGBcclxuXHJcbmxldCBvbkZvY3VzVmFsRm9udFNpemUgPSBudWxsLFxyXG5cdG9uRm9jdXNWYWxMaW5lSGVpZ2h0ID0gbnVsbCxcclxuXHRvbkZvY3VzVmFsTGV0dGVyU3BhY2luZyA9IG51bGxcclxuXHJcbmNvbnN0IGZvbnRTaXplRGF0YSA9IHtcclxuXHRuYW1lOiAnRm9udCBTaXplJyxcclxuXHRjbGFzc05hbWU6ICdmb250c19fc2l6ZScsXHJcblx0aW5wdXRJZDogJ2ZvbnRTaXplJyxcclxuXHRpbnB1dFR5cGU6ICdudW1iZXInLFxyXG5cdGlucHV0VmFsdWU6IERFRkFVTFRTLmZvbnRTaXplLFxyXG5cdGlucHV0UGxhY2Vob2xkZXI6IERFRkFVTFRTLmZvbnRTaXplLFxyXG5cdHVuaXQ6ICdweCcsXHJcblx0bWluOiAxMixcclxuXHRtYXg6IDI0LFxyXG59XHJcblxyXG5jb25zdCBsaW5lSGVpZ2h0RGF0YSA9IHtcclxuXHRuYW1lOiAnTGluZSBIZWlnaHQnLFxyXG5cdGNsYXNzTmFtZTogJ2ZvbnRzX19saW5lSGVpZ2h0JyxcclxuXHRpbnB1dElkOiAnbGluZUhlaWdodCcsXHJcblx0aW5wdXRUeXBlOiAnbnVtYmVyJyxcclxuXHRpbnB1dFZhbHVlOiBERUZBVUxUUy5saW5lSGVpZ2h0LFxyXG5cdGlucHV0UGxhY2Vob2xkZXI6IERFRkFVTFRTLmxpbmVIZWlnaHQsXHJcblx0dW5pdDogJ3B4JyxcclxuXHRtaW46IDEyLFxyXG5cdG1heDogNjAsXHJcbn1cclxuXHJcbmNvbnN0IGxldHRlclNwYWNpbmdEYXRhID0ge1xyXG5cdG5hbWU6ICdMZXR0ZXIgU3BhY2luZycsXHJcblx0Y2xhc3NOYW1lOiAnZm9udHNfX2xldHRlclNwYWNpbmcnLFxyXG5cdGlucHV0SWQ6ICdsZXR0ZXJTcGFjaW5nJyxcclxuXHRpbnB1dFR5cGU6ICdudW1iZXInLFxyXG5cdGlucHV0VmFsdWU6IERFRkFVTFRTLmxldHRlclNwYWNpbmcsXHJcblx0aW5wdXRQbGFjZWhvbGRlcjogREVGQVVMVFMubGV0dGVyU3BhY2luZyxcclxuXHR1bml0OiAncHgnLFxyXG5cdG1pbjogLTMwLFxyXG5cdG1heDogMzAsXHJcbn1cclxuXHJcbi8vIEhUTUwgdGVtcGxhdGUgZm9yIGZvbnQgY2hhbmdlciBwb3BvdmVyXHJcbmV4cG9ydCBsZXQgZm9udEh0bWxDb2RlID0gYFxyXG4gIDxzZWN0aW9uIGlkPVwiZm9udENoYW5nZXJQb3BvdmVyXCIgY2xhc3M9XCJmb250c1wiPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvbnRzX19wcm9wc1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZm9udHNfX2ZhbWlseSBmb250c19fZ3JvdXAgY2FyZCBjYXJkLS1iaWcgaC1mdWxsXCI+XHJcbiAgICAgICAgPGxhYmVsIGZvcj1cImZvbnRGYW1pbHlcIiBjbGFzcz1cImdyaWQgZ2FwLTEgaC1mdWxsIHctZnVsbFwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJjYXJkX191bml0IGNhcmRfX2ljb25cIj5UPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzcz1cImNhcmRfX25hbWUgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj5GT05UIEZBTUlMWTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHNlbGVjdCBpZD1cImZvbnRGYW1pbHlcIiBjbGFzcz1cImJvcmRlci1ub25lIG91dGxpbmUtbm9uZSBmb2N1czpub25lIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAke0ZPTlRfTkFNRVMubWFwKFxyXG5cdFx0XHRcdChuYW1lKSA9PiBgPG9wdGlvbiB2YWx1ZT1cIiR7bmFtZSA9PT0gJ0RlZmF1bHQnID8gREVGQVVMVFMuZm9udEZhbWlseSA6IG5hbWV9XCI+JHtuYW1lfTwvb3B0aW9uPmBcclxuXHRcdFx0KS5qb2luKCcnKX1cclxuICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICAke3JlbmRlckZvbnRCaWdDYXJkKGZvbnRTaXplRGF0YSl9XHJcbiAgICAgICR7cmVuZGVyRm9udFNtYWxsQ2FyZChsaW5lSGVpZ2h0RGF0YSl9XHJcbiAgICAgICR7cmVuZGVyRm9udFNtYWxsQ2FyZChsZXR0ZXJTcGFjaW5nRGF0YSl9XHJcbiAgICA8L2Rpdj5cclxuICAgIDxmb290ZXIgY2xhc3M9XCJncmlkIG10LTEwXCI+XHJcbiAgICAgICR7cmVuZGVyQnV0dG9uKHsgaWQ6ICdyZXNldEZvbnQnLCBjb250ZW50OiAnUmVzZXQgRm9udHMnLCBkaXNhYmxlZDogZmFsc2UsIGNsYXNzTmFtZTogJ2J0bi1wcmltYXJ5JyB9KX1cclxuICAgIDwvZm9vdGVyPlxyXG4gIDwvc2VjdGlvbj5cclxuYFxyXG5cclxuLy8gRnVuY3Rpb24gdG8gc2V0IGlucHV0IGZpZWxkIHZhbHVlc1xyXG5mdW5jdGlvbiBzZXRJbnB1dEZpZWxkVmFsdWUoaW5wdXRTZWxlY3RvciwgaW5wdXRWYWwpIHtcclxuXHRjb25zdCBpbnB1dEVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgLmdwdGgtc2V0dGluZ3MgIyR7aW5wdXRTZWxlY3Rvcn1gKVxyXG5cclxuXHRpbnB1dEVsLnZhbHVlID0gaW5wdXRWYWxcclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gYXBwbHkgc2V0dGluZ3NcclxuZnVuY3Rpb24gYXBwbHlTZXR0aW5ncyhzZXR0aW5ncykge1xyXG5cdE9iamVjdC5lbnRyaWVzKHNldHRpbmdzKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuXHRcdGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eShgLS0ke2tleX1gLCB2YWx1ZSlcclxuXHRcdHNldElucHV0RmllbGRWYWx1ZShrZXksIHZhbHVlKVxyXG5cclxuXHRcdC8vIGNvbnNvbGUubG9nKCdnZXRDb21wdXRlZFN0eWxlOiAnLCBnZXRDb21wdXRlZFN0eWxlKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuZ2V0UHJvcGVydHlWYWx1ZShgLS0ke2tleX1gKSlcclxuXHR9KVxyXG59XHJcblxyXG4vLyBGdW5jdGlvbiB0byBzYXZlIHNldHRpbmdzIHRvIENocm9tZSBTdG9yYWdlXHJcbmFzeW5jIGZ1bmN0aW9uIHNhdmVTZXR0aW5ncyhzZXR0aW5ncykge1xyXG5cdHRyeSB7XHJcblx0XHRhd2FpdCBicm93c2VyLnN0b3JhZ2Uuc3luYy5zZXQoc2V0dGluZ3MpXHJcblx0fSBjYXRjaCAoZXJyb3IpIHtcclxuXHRcdGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzYXZlIHNldHRpbmdzOicsIGVycm9yKVxyXG5cdH1cclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gbG9hZCBzZXR0aW5ncyBmcm9tIENocm9tZSBTdG9yYWdlXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpIHtcclxuXHR0cnkge1xyXG5cdFx0Y29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2Uuc3luYy5nZXQoT2JqZWN0LmtleXMoREVGQVVMVFMpKVxyXG5cclxuXHRcdGlmIChzZXR0aW5ncy5mb250RmFtaWx5ICYmIHNldHRpbmdzLmZvbnRGYW1pbHkgIT09IERFRkFVTFRTLmZvbnRGYW1pbHkpIHtcclxuXHRcdFx0bG9hZEdvb2dsZUZvbnQoc2V0dGluZ3MuZm9udEZhbWlseSlcclxuXHRcdH1cclxuXHRcdGFwcGx5U2V0dGluZ3Moc2V0dGluZ3MpXHJcblx0fSBjYXRjaCAoZXJyb3IpIHtcclxuXHRcdGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBsb2FkIHNldHRpbmdzOicsIGVycm9yKVxyXG5cdH1cclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gZHluYW1pY2FsbHkgbG9hZCBHb29nbGUgRm9udHNcclxuZnVuY3Rpb24gbG9hZEdvb2dsZUZvbnQoZm9udEZhbWlseSkge1xyXG5cdC8qIFx0Y29uc3QgaHJlZiA9IGBodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PSR7Zm9udEZhbWlseS5yZXBsYWNlKFxyXG5cdFx0JyAnLFxyXG5cdFx0JysnXHJcblx0KX0ke0dPT0dMRV9GT05UX1dFSUdIVFN9JmRpc3BsYXk9c3dhcGBcclxuXHJcblx0Y29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpbmsnKVxyXG5cdGxpbmsucmVsID0gJ3N0eWxlc2hlZXQnXHJcblx0bGluay5ocmVmID0gaHJlZlxyXG5cdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluaykgKi9cclxuXHRjb25zdCBsaW5rcyA9IFtcclxuXHRcdHsgcmVsOiAncHJlY29ubmVjdCcsIGhyZWY6ICdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tJyB9LFxyXG5cdFx0eyByZWw6ICdwcmVjb25uZWN0JywgaHJlZjogJ2h0dHBzOi8vZm9udHMuZ3N0YXRpYy5jb20nLCBjcm9zc29yaWdpbjogJycgfSxcclxuXHRcdHtcclxuXHRcdFx0cmVsOiAnc3R5bGVzaGVldCcsXHJcblx0XHRcdGhyZWY6IGBodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PSR7Zm9udEZhbWlseS5yZXBsYWNlKFxyXG5cdFx0XHRcdCcgJyxcclxuXHRcdFx0XHQnKydcclxuXHRcdFx0KX0ke0dPT0dMRV9GT05UX1dFSUdIVFN9JmRpc3BsYXk9c3dhcGAsXHJcblx0XHR9LFxyXG5cdF1cclxuXHJcblx0bGlua3MuZm9yRWFjaCgoeyByZWwsIGhyZWYsIGNyb3Nzb3JpZ2luIH0pID0+IHtcclxuXHRcdGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJylcclxuXHRcdGxpbmsucmVsID0gcmVsXHJcblx0XHRsaW5rLmhyZWYgPSBocmVmXHJcblx0XHRpZiAoY3Jvc3NvcmlnaW4gIT09IHVuZGVmaW5lZCkge1xyXG5cdFx0XHRsaW5rLmNyb3NzT3JpZ2luID0gY3Jvc3NvcmlnaW5cclxuXHRcdH1cclxuXHRcdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQobGluaylcclxuXHR9KVxyXG59XHJcbi8vIEZ1bmN0aW9uIHRvIGdldCBhbGwgR29vZ2xlIEZvbnQgbGlua3NcclxuZnVuY3Rpb24gZ2V0QWxsSGVhZEZvbnRzTGlua3MoKSB7XHJcblx0Ly8gcmV0dXJuIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImxpbmtbcmVsPSdzdHlsZXNoZWV0J10sIGxpbmtbcmVsPSdwcmVjb25uZWN0J11cIikpXHJcblx0cmV0dXJuIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImhlYWQgbGlua1tocmVmKj0nZm9udHMuJ11cIikpXHJcbn1cclxuLy8gRnVuY3Rpb24gdG8gcmVtb3ZlIGFsbCBHb29nbGUgRm9udCBsaW5rc1xyXG5mdW5jdGlvbiByZW1vdmVBbGxHb29nbGVGb250c0xpbmtzKCkge1xyXG5cdGNvbnN0IGxpbmtzID0gZ2V0QWxsSGVhZEZvbnRzTGlua3MoKVxyXG5cclxuXHQvLyBjb25zb2xlLmxvZygnbGlua3M6ICcsIGxpbmtzKVxyXG5cclxuXHRsaW5rcy5mb3JFYWNoKChsaW5rKSA9PiB7XHJcblx0XHRpZiAobGluay5ocmVmLmluY2x1ZGVzKCdmb250cy5nb29nbGVhcGlzLmNvbScpIHx8IGxpbmsuaHJlZi5pbmNsdWRlcygnZm9udHMuZ3N0YXRpYy5jb20nKSkge1xyXG5cdFx0XHRsaW5rLnJlbW92ZSgpXHJcblx0XHR9XHJcblx0fSlcclxufVxyXG4vKiBmdW5jdGlvbiBnZXRBbGxIZWFkTGlua3MoKSB7XHJcblx0cmV0dXJuIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImxpbmtbcmVsPSdzdHlsZXNoZWV0J11cIikpXHJcbn1cclxuLy8gRnVuY3Rpb24gdG8gcmVtb3ZlIGFsbCBHb29nbGUgRm9udCBsaW5rc1xyXG5mdW5jdGlvbiByZW1vdmVBbGxHb29nbGVGb250c0xpbmtzKCkge1xyXG5cdGNvbnN0IGxpbmtzID0gZ2V0QWxsSGVhZExpbmtzKClcclxuXHJcblx0bGlua3MuZm9yRWFjaCgobGluaykgPT4ge1xyXG5cdFx0aWYgKGxpbmsuaHJlZi5pbmNsdWRlcygnZ29vZ2xlYXBpcy5jb20nKSkge1xyXG5cdFx0XHRsaW5rLnJlbW92ZSgpXHJcblx0XHR9XHJcblx0fSlcclxufSAqL1xyXG5cclxuLy8gRnVuY3Rpb24gdG8gdmFsaWRhdGUgaW5wdXQgZmllbGRzXHJcbmZ1bmN0aW9uIHZhbGlkYXRlSW5wdXRGaWVsZChpbnB1dFZhbHVlLCBtaW4sIG1heCA9IDI0KSB7XHJcblx0aWYgKGlzTmFOKGlucHV0VmFsdWUpKSB7XHJcblx0XHRkaXNwbGF5RXJyb3IoJ0VtcHR5IG9yIGludmFsaWQgdmFsdWUnKVxyXG5cdFx0cmV0dXJuIGZhbHNlXHJcblx0fSBlbHNlIGlmIChpbnB1dFZhbHVlIDwgbWluIHx8IGlucHV0VmFsdWUgPiBtYXgpIHtcclxuXHRcdGRpc3BsYXlFcnJvcihgTnVtYmVyIG11c3QgYmUgYmV0d2VlbiAke21pbn0gYW5kICR7bWF4fWApXHJcblx0XHRyZXR1cm4gZmFsc2VcclxuXHR9XHJcblx0cmV0dXJuIHRydWVcclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gZGlzcGxheSBlcnJvciBtZXNzYWdlc1xyXG5mdW5jdGlvbiBkaXNwbGF5RXJyb3IobWVzc2FnZSkge1xyXG5cdC8vIFJlbW92ZSBhbnkgcHJldmlvdXMgZXJyb3IgbWVzc2FnZXNcclxuXHRjb25zdCBleGlzdGluZ0Vycm9yID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdwdGgtZXJyb3ItbXNnJylcclxuXHRpZiAoZXhpc3RpbmdFcnJvcikgZXhpc3RpbmdFcnJvci5yZW1vdmUoKVxyXG5cclxuXHQvLyBDcmVhdGUgYW5kIGluc2VydCB0aGUgbmV3IGVycm9yIG1lc3NhZ2VcclxuXHRjb25zdCBlcnJvck1lc3NhZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxyXG5cdGVycm9yTWVzc2FnZS5jbGFzc05hbWUgPSAnZ3B0aC1lcnJvci1tc2cgZml4ZWQgcm91bmRlZC14bCBiZy1yZWQtNTAwIHJlZC01MDAgcC0zIGZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXInXHJcblx0ZXJyb3JNZXNzYWdlLnRleHRDb250ZW50ID0gbWVzc2FnZVxyXG5cdGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZXJyb3JNZXNzYWdlKVxyXG5cclxuXHQvLyBSZW1vdmUgdGhlIGVycm9yIG1lc3NhZ2UgYWZ0ZXIgNCBzZWNvbmRzXHJcblx0c2V0VGltZW91dCgoKSA9PiB7XHJcblx0XHRlcnJvck1lc3NhZ2UucmVtb3ZlKClcclxuXHR9LCA0MDAwKVxyXG59XHJcblxyXG4vLyBGdW5jdGlvbiB0byBmb3JtYXQgbnVtYmVyc1xyXG5mdW5jdGlvbiBmb3JtYXROdW1iZXIoaW5wdXRWYWwsIHRvRml4ZWROdW0gPSAyKSB7XHJcblx0Ly8gUmVtb3ZlIGxlYWRpbmcgemVyb3MgZnJvbSB0aGUgaW50ZWdlciBwYXJ0XHJcblx0aW5wdXRWYWwgPSBpbnB1dFZhbC5yZXBsYWNlKC9eMCsoPz1cXGQqXFwuKS8sICcnKVxyXG5cdC8vIFBhcnNlIHRoZSBpbnB1dCBhcyBhIG51bWJlciBhbmQgcmV0dXJuIGl0IHdpdGggMiBkZWNpbWFsIHBsYWNlc1xyXG5cdGxldCBmb3JtYXR0ZWQgPSBwYXJzZUZsb2F0KGlucHV0VmFsKS50b0ZpeGVkKHRvRml4ZWROdW0pXHJcblx0Ly8gUmVtb3ZlIHRyYWlsaW5nIHplcm9zIGZyb20gdGhlIGRlY2ltYWwgcGFydFxyXG5cdGZvcm1hdHRlZCA9IGZvcm1hdHRlZC5yZXBsYWNlKC9cXC4/MCskLywgJycpXHJcblx0Ly8gUmV0dXJuIHRoZSBmb3JtYXR0ZWQgbnVtYmVyIGFzIGEgc3RyaW5nXHJcblx0cmV0dXJuIGZvcm1hdHRlZFxyXG59XHJcblxyXG4vLyBGdW5jdGlvbiB0byBoYW5kbGUgZm9udCBzaXplIGNoYW5nZVxyXG5mdW5jdGlvbiBjaGFuZ2VGb250U2l6ZShlKSB7XHJcblx0Y29uc3QgbmV3VmFsID0gZm9ybWF0TnVtYmVyKGUudGFyZ2V0LnZhbHVlKVxyXG5cdG9uRm9jdXNWYWxGb250U2l6ZSA9IGZvcm1hdE51bWJlcihvbkZvY3VzVmFsRm9udFNpemUsIDQpXHJcblxyXG5cdGlmIChvbkZvY3VzVmFsRm9udFNpemUgPT09IG5ld1ZhbCkgcmV0dXJuXHJcblxyXG5cdGlmICghdmFsaWRhdGVJbnB1dEZpZWxkKG5ld1ZhbCwgZm9udFNpemVEYXRhLm1pbiwgZm9udFNpemVEYXRhLm1heCkpIHtcclxuXHRcdHNldElucHV0RmllbGRWYWx1ZSgnZm9udFNpemUnLCBvbkZvY3VzVmFsRm9udFNpemUpXHJcblx0XHRhcHBseVNldHRpbmdzKHsgZm9udFNpemU6IG9uRm9jdXNWYWxGb250U2l6ZSB9KVxyXG5cdFx0c2F2ZVNldHRpbmdzKHsgZm9udFNpemU6IG9uRm9jdXNWYWxGb250U2l6ZSB9KVxyXG5cdFx0Ly8gc2V0SW5wdXRGaWVsZCgnZm9udFNpemUnLCBERUZBVUxUUy5mb250U2l6ZSlcclxuXHRcdC8vIGFwcGx5U2V0dGluZ3MoeyBmb250U2l6ZTogREVGQVVMVFMuZm9udFNpemUgfSlcclxuXHRcdC8vIHNhdmVTZXR0aW5ncyh7IGZvbnRTaXplOiBERUZBVUxUUy5mb250U2l6ZSB9KVxyXG5cdFx0cmV0dXJuXHJcblx0fVxyXG5cclxuXHRhcHBseVNldHRpbmdzKHsgZm9udFNpemU6IG5ld1ZhbCB9KVxyXG5cdHNhdmVTZXR0aW5ncyh7IGZvbnRTaXplOiBuZXdWYWwgfSlcclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gaGFuZGxlIGxpbmUgaGVpZ2h0IGNoYW5nZVxyXG5mdW5jdGlvbiBjaGFuZ2VMaW5lSGVpZ2h0KGUpIHtcclxuXHRjb25zdCBuZXdWYWwgPSBmb3JtYXROdW1iZXIoZS50YXJnZXQudmFsdWUpXHJcblx0b25Gb2N1c1ZhbExpbmVIZWlnaHQgPSBmb3JtYXROdW1iZXIob25Gb2N1c1ZhbExpbmVIZWlnaHQsIDQpXHJcblxyXG5cdGlmIChvbkZvY3VzVmFsTGluZUhlaWdodCA9PT0gbmV3VmFsKSByZXR1cm5cclxuXHJcblx0aWYgKCF2YWxpZGF0ZUlucHV0RmllbGQobmV3VmFsLCBsaW5lSGVpZ2h0RGF0YS5taW4sIGxpbmVIZWlnaHREYXRhLm1heCkpIHtcclxuXHRcdHNldElucHV0RmllbGRWYWx1ZSgnbGluZUhlaWdodCcsIG9uRm9jdXNWYWxMaW5lSGVpZ2h0KVxyXG5cdFx0YXBwbHlTZXR0aW5ncyh7IGxpbmVIZWlnaHQ6IG9uRm9jdXNWYWxMaW5lSGVpZ2h0IH0pXHJcblx0XHRzYXZlU2V0dGluZ3MoeyBsaW5lSGVpZ2h0OiBvbkZvY3VzVmFsTGluZUhlaWdodCB9KVxyXG5cdFx0cmV0dXJuXHJcblx0fVxyXG5cclxuXHRhcHBseVNldHRpbmdzKHsgbGluZUhlaWdodDogbmV3VmFsIH0pXHJcblx0c2F2ZVNldHRpbmdzKHsgbGluZUhlaWdodDogbmV3VmFsIH0pXHJcbn1cclxuXHJcbi8vIEZ1bmN0aW9uIHRvIGhhbmRsZSBsZXR0ZXIgc3BhY2luZyBjaGFuZ2VcclxuZnVuY3Rpb24gY2hhbmdlTGV0dGVyU3BhY2luZyhlKSB7XHJcblx0Y29uc3QgbmV3VmFsID0gZm9ybWF0TnVtYmVyKGUudGFyZ2V0LnZhbHVlKVxyXG5cdG9uRm9jdXNWYWxMZXR0ZXJTcGFjaW5nID0gZm9ybWF0TnVtYmVyKG9uRm9jdXNWYWxMZXR0ZXJTcGFjaW5nLCA0KVxyXG5cclxuXHRpZiAob25Gb2N1c1ZhbExldHRlclNwYWNpbmcgPT09IG5ld1ZhbCkgcmV0dXJuXHJcblxyXG5cdGlmICghdmFsaWRhdGVJbnB1dEZpZWxkKG5ld1ZhbCwgbGV0dGVyU3BhY2luZ0RhdGEubWluLCBsZXR0ZXJTcGFjaW5nRGF0YS5tYXgpKSB7XHJcblx0XHRzZXRJbnB1dEZpZWxkVmFsdWUoJ2xldHRlclNwYWNpbmcnLCBvbkZvY3VzVmFsTGV0dGVyU3BhY2luZylcclxuXHRcdGFwcGx5U2V0dGluZ3MoeyBsZXR0ZXJTcGFjaW5nOiBvbkZvY3VzVmFsTGV0dGVyU3BhY2luZyB9KVxyXG5cdFx0c2F2ZVNldHRpbmdzKHsgbGV0dGVyU3BhY2luZzogb25Gb2N1c1ZhbExldHRlclNwYWNpbmcgfSlcclxuXHRcdHJldHVyblxyXG5cdH1cclxuXHJcblx0YXBwbHlTZXR0aW5ncyh7IGxldHRlclNwYWNpbmc6IG5ld1ZhbCB9KVxyXG5cdHNhdmVTZXR0aW5ncyh7IGxldHRlclNwYWNpbmc6IG5ld1ZhbCB9KVxyXG59XHJcblxyXG4vLyBGdW5jdGlvbiB0byBoYW5kbGUgZm9udCBmYW1pbHkgY2hhbmdlXHJcbmFzeW5jIGZ1bmN0aW9uIGNoYW5nZUZvbnRGYW1pbHkoZSkge1xyXG5cdGNvbnN0IHNlbGVjdGVkRm9udCA9IGUudGFyZ2V0LnZhbHVlXHJcblxyXG5cdC8vIFJlbW92ZSBhbGwgZXhpc3RpbmcgR29vZ2xlIEZvbnRzIGxpbmtzXHJcblx0cmVtb3ZlQWxsR29vZ2xlRm9udHNMaW5rcygpXHJcblx0aWYgKHNlbGVjdGVkRm9udCAhPT0gREVGQVVMVFMuZm9udEZhbWlseSkge1xyXG5cdFx0Ly8gTG9hZCB0aGUgbmV3bHkgc2VsZWN0ZWQgR29vZ2xlIEZvbnRcclxuXHRcdGxvYWRHb29nbGVGb250KHNlbGVjdGVkRm9udClcclxuXHRcdGFwcGx5U2V0dGluZ3MoeyBmb250RmFtaWx5OiBzZWxlY3RlZEZvbnQgfSlcclxuXHRcdHRyeSB7XHJcblx0XHRcdGF3YWl0IHNhdmVTZXR0aW5ncyh7IGZvbnRGYW1pbHk6IHNlbGVjdGVkRm9udCB9KVxyXG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcclxuXHRcdFx0Y29uc29sZS5lcnJvcignRmFpbGVkIHRvIHNhdmUgZm9udCBmYW1pbHk6JywgZXJyb3IpXHJcblx0XHR9XHJcblx0fSBlbHNlIHtcclxuXHRcdC8vIEFwcGx5IGRlZmF1bHQgZm9udCBmYW1pbHkgc2V0dGluZ3NcclxuXHRcdGFwcGx5U2V0dGluZ3MoeyBmb250RmFtaWx5OiBzZWxlY3RlZEZvbnQgfSlcclxuXHRcdHRyeSB7XHJcblx0XHRcdGF3YWl0IHNhdmVTZXR0aW5ncyh7IGZvbnRGYW1pbHk6IHNlbGVjdGVkRm9udCB9KVxyXG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcclxuXHRcdFx0Y29uc29sZS5lcnJvcignRmFpbGVkIHRvIHJlc2V0IGZvbnQgZmFtaWx5OicsIGVycm9yKVxyXG5cdFx0fVxyXG5cdH1cclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gcmVzZXQgZm9udHMgdG8gZGVmYXVsdFxyXG5mdW5jdGlvbiByZXNldEZvbnRzKCkge1xyXG5cdGFwcGx5U2V0dGluZ3MoREVGQVVMVFMpXHJcblx0c2F2ZVNldHRpbmdzKERFRkFVTFRTKVxyXG59XHJcblxyXG4vLyBGdW5jdGlvbiB0byBoYW5kbGUgZm9udCBsaXN0ZW5lcnNcclxuZXhwb3J0IGZ1bmN0aW9uIGhhbmRsZUZvbnRzTGlzdGVuZXJzKCkge1xyXG5cdGNvbnN0IHNlbGVjdG9ycyA9IHtcclxuXHRcdHNlbGVjdEZvbnRGYW1pbHk6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5ncHRoLXNldHRpbmdzICNmb250RmFtaWx5JyksXHJcblx0XHRpbnB1dEZvbnRTaXplOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZ3B0aC1zZXR0aW5ncyAjZm9udFNpemUnKSxcclxuXHRcdGlucHV0TGluZUhlaWdodDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdwdGgtc2V0dGluZ3MgI2xpbmVIZWlnaHQnKSxcclxuXHRcdGlucHV0TGV0dGVyU3BhY2luZzogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdwdGgtc2V0dGluZ3MgI2xldHRlclNwYWNpbmcnKSxcclxuXHRcdGJ0blJlc2V0Rm9udDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdwdGgtc2V0dGluZ3MgI3Jlc2V0Rm9udCcpLFxyXG5cdH1cclxuXHJcblx0c2VsZWN0b3JzLnNlbGVjdEZvbnRGYW1pbHkuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgY2hhbmdlRm9udEZhbWlseSlcclxuXHRzZWxlY3RvcnMuaW5wdXRGb250U2l6ZS5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgY2hhbmdlRm9udFNpemUpXHJcblx0c2VsZWN0b3JzLmlucHV0TGluZUhlaWdodC5hZGRFdmVudExpc3RlbmVyKCdibHVyJywgY2hhbmdlTGluZUhlaWdodClcclxuXHRzZWxlY3RvcnMuaW5wdXRMZXR0ZXJTcGFjaW5nLmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCBjaGFuZ2VMZXR0ZXJTcGFjaW5nKVxyXG5cclxuXHRzZWxlY3RvcnMuaW5wdXRGb250U2l6ZS5hZGRFdmVudExpc3RlbmVyKCdmb2N1cycsIChlKSA9PiB7XHJcblx0XHRvbkZvY3VzVmFsRm9udFNpemUgPSBlLnRhcmdldC52YWx1ZVxyXG5cdH0pXHJcblx0c2VsZWN0b3JzLmlucHV0TGluZUhlaWdodC5hZGRFdmVudExpc3RlbmVyKCdmb2N1cycsIChlKSA9PiB7XHJcblx0XHRvbkZvY3VzVmFsTGluZUhlaWdodCA9IGUudGFyZ2V0LnZhbHVlXHJcblx0fSlcclxuXHRzZWxlY3RvcnMuaW5wdXRMZXR0ZXJTcGFjaW5nLmFkZEV2ZW50TGlzdGVuZXIoJ2ZvY3VzJywgKGUpID0+IHtcclxuXHRcdG9uRm9jdXNWYWxMZXR0ZXJTcGFjaW5nID0gZS50YXJnZXQudmFsdWVcclxuXHR9KVxyXG5cclxuXHRzZWxlY3RvcnMuaW5wdXRGb250U2l6ZS5hZGRFdmVudExpc3RlbmVyKCdrZXlwcmVzcycsIChlKSA9PiB7XHJcblx0XHRpZiAoZS5rZXkgPT09ICdFbnRlcicpIHtcclxuXHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpXHJcblx0XHRcdGNoYW5nZUZvbnRTaXplKGUpXHJcblx0XHRcdGUudGFyZ2V0LmJsdXIoKVxyXG5cdFx0fVxyXG5cdH0pXHJcblx0c2VsZWN0b3JzLmlucHV0TGluZUhlaWdodC5hZGRFdmVudExpc3RlbmVyKCdrZXlwcmVzcycsIChlKSA9PiB7XHJcblx0XHRpZiAoZS5rZXkgPT09ICdFbnRlcicpIHtcclxuXHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpXHJcblx0XHRcdGNoYW5nZUxpbmVIZWlnaHQoZSlcclxuXHRcdFx0ZS50YXJnZXQuYmx1cigpXHJcblx0XHR9XHJcblx0fSlcclxuXHRzZWxlY3RvcnMuaW5wdXRMZXR0ZXJTcGFjaW5nLmFkZEV2ZW50TGlzdGVuZXIoJ2tleXByZXNzJywgKGUpID0+IHtcclxuXHRcdGlmIChlLmtleSA9PT0gJ0VudGVyJykge1xyXG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KClcclxuXHRcdFx0Y2hhbmdlTGV0dGVyU3BhY2luZyhlKVxyXG5cdFx0XHRlLnRhcmdldC5ibHVyKClcclxuXHRcdH1cclxuXHR9KVxyXG5cclxuXHRzZWxlY3RvcnMuYnRuUmVzZXRGb250LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgcmVzZXRGb250cylcclxufVxyXG5cclxuLy8gRnVuY3Rpb24gdG8gaW5pdGlhbGl6ZSB0aGUgc2V0dGluZ3NcclxuZnVuY3Rpb24gaW5pdCgpIHtcclxuXHQvLyBMb2FkIHNldHRpbmdzIG9uIHBhZ2UgbG9hZFxyXG5cdGxvYWRTZXR0aW5ncygpXHJcbn1cclxuaW5pdCgpXHJcbiIsImV4cG9ydCBmdW5jdGlvbiByZW5kZXJGb250U21hbGxDYXJkKHtcclxuXHRuYW1lLFxyXG5cdGNsYXNzTmFtZSxcclxuXHRpbnB1dElkLFxyXG5cdGlucHV0VHlwZSxcclxuXHRpbnB1dFZhbHVlLFxyXG5cdGlucHV0UGxhY2Vob2xkZXIsXHJcblx0bWluID0gMTYsXHJcblx0bWF4ID0gMjQsXHJcblx0dW5pdCA9ICdweCcsXHJcbn0pIHtcclxuXHRyZXR1cm4gYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCIke2NsYXNzTmFtZX0gY2FyZCBjYXJkLS1zbWFsbFwiIGRhdGEtZ3B0aC1lcnI9XCIke21pbn0ke3VuaXR9ICZoQXJyOyAke21heH0ke3VuaXR9XCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCIke2lucHV0SWR9XCIgY2xhc3M9XCJyb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgaC1mdWxsIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCIke2lucHV0VHlwZX1cIiBpZD1cIiR7aW5wdXRJZH1cIiB2YWx1ZT1cIiR7aW5wdXRWYWx1ZX1cIiBwbGFjZWhvbGRlcj1cIiR7aW5wdXRQbGFjZWhvbGRlcn1cIiBjbGFzcz1cInJvdW5kZWQtZnVsbCBvdXRsaW5lLW5vbmUgYm9yZGVyLW5vbmUgZm9udC1ib2xkXCIgbWlubGVuZ3RoPVwiJHttaW59XCIgbWF4bGVuZ3RoPVwiJHttYXh9XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmRfX3VuaXRuYW1lLXdyYXBwZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNhcmRfX3VuaXQgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+cGl4ZWxzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwiY2FyZF9fbmFtZSB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZFwiPiR7bmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8L2Rpdj5gXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZW5kZXJGb250QmlnQ2FyZCh7XHJcblx0bmFtZSxcclxuXHRjbGFzc05hbWUsXHJcblx0aW5wdXRJZCxcclxuXHRpbnB1dFR5cGUsXHJcblx0aW5wdXRWYWx1ZSxcclxuXHRpbnB1dFBsYWNlaG9sZGVyLFxyXG5cdG1pbiA9IDAsXHJcblx0bWF4ID0gMjAsXHJcblx0dW5pdCA9ICdweCcsXHJcbn0pIHtcclxuXHRyZXR1cm4gYFxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCIke2NsYXNzTmFtZX0gZm9udHNfX2dyb3VwIGNhcmQgY2FyZC0tYmlnIGgtZnVsbFwiIGRhdGEtZ3B0aC1lcnI9XCIke21pbn0ke3VuaXR9ICZoQXJyOyAke21heH0ke3VuaXR9XCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCIke2lucHV0SWR9XCIgY2xhc3M9XCJncmlkIGdhcC0xIGgtZnVsbCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3M9XCJjYXJkX191bml0IGNhcmRfX2ljb25cIj5QWDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImNhcmRfX25hbWUgdXBwZXJjYXNlIGZvbnQtc2VtaWJvbGRcIj4ke25hbWV9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCIke2lucHV0VHlwZX1cIiBpZD1cIiR7aW5wdXRJZH1cIiB2YWx1ZT1cIiR7aW5wdXRWYWx1ZX1cIiBwbGFjZWhvbGRlcj1cIiR7aW5wdXRQbGFjZWhvbGRlcn1cIiBjbGFzcz1cIm91dGxpbmUtbm9uZSBib3JkZXItbm9uZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLW5vbmUgZm9udC1ib2xkXCIgbWlubGVuZ3RoPVwiJHttaW59XCIgbWF4bGVuZ3RoPVwiJHttYXh9XCI+XHJcbiAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPC9kaXY+YFxyXG59XHJcblxyXG4vLyBleHBvcnQgZnVuY3Rpb24gcmVuZGVyRm9udENhcmQoeyBkYXRhLCBjYXJkVHlwZSA9ICdzbWFsbCcsIGluY2x1ZGVGaWVsZHMgPSBbXSB9KSB7XHJcbi8vIFx0Y29uc3QgeyBuYW1lLCBjbGFzc05hbWUsIGlucHV0SWQsIGlucHV0VHlwZSwgaW5wdXRWYWx1ZSwgaW5wdXRQbGFjZWhvbGRlciwgbWluID0gMCwgbWF4ID0gMjQsIHVuaXQgPSAncHgnIH0gPSBkYXRhXHJcblxyXG4vLyBcdGxldCBjYXJkSHRtbFxyXG5cclxuLy8gXHRpZiAoY2FyZFR5cGUgPT09ICdzbWFsbCcpIHtcclxuLy8gXHRcdGNhcmRIdG1sID0gYFxyXG4vLyBcdFx0XHQ8ZGl2IGNsYXNzPVwiJHtjbGFzc05hbWV9IGNhcmQgY2FyZC0tc21hbGxcIiBkYXRhLWdwdGgtZXJyPVwiJHttaW59JHt1bml0fSAmaEFycjsgJHttYXh9JHt1bml0fVwiPlxyXG4vLyBcdFx0XHRcdDxsYWJlbCBmb3I9XCIke2lucHV0SWR9XCIgY2xhc3M9XCJyb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgaC1mdWxsIHctZnVsbFwiPlxyXG4vLyBcdFx0XHRcdFx0JHtcclxuLy8gXHRcdFx0XHRcdFx0aW5jbHVkZUZpZWxkcy5pbmNsdWRlcygnaW5wdXQnKVxyXG4vLyBcdFx0XHRcdFx0XHRcdD8gYDxpbnB1dCB0eXBlPVwiJHtpbnB1dFR5cGV9XCIgaWQ9XCIke2lucHV0SWR9XCIgdmFsdWU9XCIke2lucHV0VmFsdWV9XCIgcGxhY2Vob2xkZXI9XCIke2lucHV0UGxhY2Vob2xkZXJ9XCIgY2xhc3M9XCJyb3VuZGVkLWZ1bGwgb3V0bGluZS1ub25lIGJvcmRlci1ub25lIGZvbnQtYm9sZFwiIG1pbmxlbmd0aD1cIiR7bWlufVwiIG1heGxlbmd0aD1cIiR7bWF4fVwiPmBcclxuLy8gXHRcdFx0XHRcdFx0XHQ6ICcnXHJcbi8vIFx0XHRcdFx0XHR9XHJcblxyXG4vLyBcdFx0XHRcdFx0PGRpdiBjbGFzcz1cImNhcmRfX3VuaXRuYW1lLXdyYXBwZXJcIj5cclxuLy8gXHRcdFx0XHRcdDxwIGNsYXNzPVwiY2FyZF9fdW5pdCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj4ke3VuaXR9PC9wPlxyXG4vLyBcdFx0XHRcdFx0PHAgY2xhc3M9XCJjYXJkX19uYW1lIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+JHtuYW1lfTwvcD5cclxuLy8gXHRcdFx0XHRcdDwvZGl2PlxyXG4vLyBcdFx0XHRcdDwvbGFiZWw+XHJcbi8vIFx0XHRcdDwvZGl2PlxyXG4vLyBcdFx0YFxyXG4vLyBcdH0gZWxzZSBpZiAoY2FyZFR5cGUgPT09ICdiaWcnKSB7XHJcbi8vIFx0XHRjYXJkSHRtbCA9IGBcclxuLy8gXHRcdFx0PGRpdiBjbGFzcz1cIiR7Y2xhc3NOYW1lfSBmb250c19fZ3JvdXAgY2FyZCBjYXJkLS1iaWcgaC1mdWxsXCIgZGF0YS1ncHRoLWVycj1cIiR7bWlufSR7dW5pdH0gJmhBcnI7ICR7bWF4fSR7dW5pdH1cIj5cclxuLy8gXHRcdFx0XHQ8bGFiZWwgZm9yPVwiJHtpbnB1dElkfVwiIGNsYXNzPVwiZ3JpZCBnYXAtMSBoLWZ1bGwgdy1mdWxsXCI+XHJcbi8vIFx0XHRcdFx0XHQ8ZGl2PlxyXG4vLyBcdFx0XHRcdFx0XHQ8cCBjbGFzcz1cImNhcmRfX3VuaXQgY2FyZF9faWNvblwiPiR7dW5pdC50b1VwcGVyQ2FzZSgpfTwvcD5cclxuLy8gXHRcdFx0XHRcdFx0PHAgY2xhc3M9XCJjYXJkX19uYW1lIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+JHtuYW1lfTwvcD5cclxuLy8gXHRcdFx0XHRcdDwvZGl2PlxyXG5cclxuLy8gXHRcdFx0XHRcdCR7XHJcbi8vIFx0XHRcdFx0XHRcdGluY2x1ZGVGaWVsZHMuaW5jbHVkZXMoJ2lucHV0JylcclxuLy8gXHRcdFx0XHRcdFx0XHQ/IGA8aW5wdXQgdHlwZT1cIiR7aW5wdXRUeXBlfVwiIGlkPVwiJHtpbnB1dElkfVwiIHZhbHVlPVwiJHtpbnB1dFZhbHVlfVwiIHBsYWNlaG9sZGVyPVwiJHtpbnB1dFBsYWNlaG9sZGVyfVwiIGNsYXNzPVwib3V0bGluZS1ub25lIGJvcmRlci1ub25lIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItbm9uZSBmb250LWJvbGRcIiBtaW5sZW5ndGg9XCIke21pbn1cIiBtYXhsZW5ndGg9XCIke21heH1cIj5gXHJcbi8vIFx0XHRcdFx0XHRcdFx0OiAnJ1xyXG4vLyBcdFx0XHRcdFx0fVxyXG4vLyBcdFx0XHRcdDwvbGFiZWw+XHJcbi8vIFx0XHRcdDwvZGl2PlxyXG4vLyBcdFx0YFxyXG4vLyBcdH0gZWxzZSB7XHJcbi8vIFx0XHR0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgY2FyZCB0eXBlIHNwZWNpZmllZC4nKVxyXG4vLyBcdH1cclxuXHJcbi8vIFx0cmV0dXJuIGNhcmRIdG1sXHJcbi8vIH1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZW5kZXJCdXR0b24oeyBuYW1lLCBjbGFzc05hbWUsIGlkLCBjb250ZW50LCBkaXNhYmxlZCA9IGZhbHNlIH0pIHtcclxuXHRyZXR1cm4gYFxyXG4gICAgICAgIDxidXR0b24gaWQ9XCIke2lkfVwiIGNsYXNzPVwiYnRuIGJsb2NrIHJlbGF0aXZlIHRleHQtY2VudGVyICR7Y2xhc3NOYW1lfVwiICR7ZGlzYWJsZWQgPyAnZGlzYWJsZWQnIDogJyd9PlxyXG4gICAgICAgICAgICAke2NvbnRlbnR9XHJcbiAgICAgICAgPC9idXR0b24+XHJcblx0YFxyXG59XHJcbiJdLCJuYW1lcyI6WyJnbG9iYWxUaGlzIiwiY2hyb21lIiwicnVudGltZSIsImlkIiwiRXJyb3IiLCJicm93c2VyIiwiT2JqZWN0IiwiZ2V0UHJvdG90eXBlT2YiLCJwcm90b3R5cGUiLCJDSFJPTUVfU0VORF9NRVNTQUdFX0NBTExCQUNLX05PX1JFU1BPTlNFX01FU1NBR0UiLCJ3cmFwQVBJcyIsImV4dGVuc2lvbkFQSXMiLCJhcGlNZXRhZGF0YSIsImtleXMiLCJsZW5ndGgiLCJEZWZhdWx0V2Vha01hcCIsIldlYWtNYXAiLCJjb25zdHJ1Y3RvciIsImNyZWF0ZUl0ZW0iLCJpdGVtcyIsInVuZGVmaW5lZCIsImdldCIsImtleSIsImhhcyIsInNldCIsImlzVGhlbmFibGUiLCJ2YWx1ZSIsInRoZW4iLCJtYWtlQ2FsbGJhY2siLCJwcm9taXNlIiwibWV0YWRhdGEiLCJjYWxsYmFja0FyZ3MiLCJsYXN0RXJyb3IiLCJyZWplY3QiLCJtZXNzYWdlIiwic2luZ2xlQ2FsbGJhY2tBcmciLCJyZXNvbHZlIiwicGx1cmFsaXplQXJndW1lbnRzIiwibnVtQXJncyIsIndyYXBBc3luY0Z1bmN0aW9uIiwibmFtZSIsImFzeW5jRnVuY3Rpb25XcmFwcGVyIiwidGFyZ2V0IiwiYXJncyIsIm1pbkFyZ3MiLCJtYXhBcmdzIiwiUHJvbWlzZSIsImZhbGxiYWNrVG9Ob0NhbGxiYWNrIiwiY2JFcnJvciIsImNvbnNvbGUiLCJ3YXJuIiwibm9DYWxsYmFjayIsIndyYXBNZXRob2QiLCJtZXRob2QiLCJ3cmFwcGVyIiwiUHJveHkiLCJhcHBseSIsInRhcmdldE1ldGhvZCIsInRoaXNPYmoiLCJjYWxsIiwiaGFzT3duUHJvcGVydHkiLCJGdW5jdGlvbiIsImJpbmQiLCJ3cmFwT2JqZWN0Iiwid3JhcHBlcnMiLCJjYWNoZSIsImNyZWF0ZSIsImhhbmRsZXJzIiwicHJveHlUYXJnZXQiLCJwcm9wIiwicmVjZWl2ZXIiLCJkZWZpbmVQcm9wZXJ0eSIsImNvbmZpZ3VyYWJsZSIsImVudW1lcmFibGUiLCJkZXNjIiwiUmVmbGVjdCIsImRlbGV0ZVByb3BlcnR5Iiwid3JhcEV2ZW50Iiwid3JhcHBlck1hcCIsImFkZExpc3RlbmVyIiwibGlzdGVuZXIiLCJoYXNMaXN0ZW5lciIsInJlbW92ZUxpc3RlbmVyIiwib25SZXF1ZXN0RmluaXNoZWRXcmFwcGVycyIsIm9uUmVxdWVzdEZpbmlzaGVkIiwicmVxIiwid3JhcHBlZFJlcSIsImdldENvbnRlbnQiLCJvbk1lc3NhZ2VXcmFwcGVycyIsIm9uTWVzc2FnZSIsInNlbmRlciIsInNlbmRSZXNwb25zZSIsImRpZENhbGxTZW5kUmVzcG9uc2UiLCJ3cmFwcGVkU2VuZFJlc3BvbnNlIiwic2VuZFJlc3BvbnNlUHJvbWlzZSIsInJlc3BvbnNlIiwicmVzdWx0IiwiZXJyIiwiaXNSZXN1bHRUaGVuYWJsZSIsInNlbmRQcm9taXNlZFJlc3VsdCIsIm1zZyIsImVycm9yIiwiX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fIiwiY2F0Y2giLCJ3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjayIsInJlcGx5Iiwid3JhcHBlZFNlbmRNZXNzYWdlIiwiYXBpTmFtZXNwYWNlT2JqIiwid3JhcHBlZENiIiwicHVzaCIsInNlbmRNZXNzYWdlIiwic3RhdGljV3JhcHBlcnMiLCJkZXZ0b29scyIsIm5ldHdvcmsiLCJvbk1lc3NhZ2VFeHRlcm5hbCIsInRhYnMiLCJzZXR0aW5nTWV0YWRhdGEiLCJjbGVhciIsInByaXZhY3kiLCJzZXJ2aWNlcyIsIndlYnNpdGVzIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC4xMjczMDY0Ny5qcy5tYXAifQ==
